////////////////////////////////////////////////////////////////////////////////
// DScript Scripting Language
// Copyright (C) 2003 Bryan "daerid" Ross
//
// Permission to copy, use, modify, sell and distribute this software is
// granted provided this copyright notice appears in all copies. This
// software is provided "as is" without express or implied warranty, and
// with no claim as to its suitability for any purpose.
////////////////////////////////////////////////////////////////////////////////

#ifndef __DSCRIPT_H__
#define __DSCRIPT_H__

////////////////////////////////////////////////////////////////////////////////
// Quite possibly, the most ridiculously redundant include file ever
#include "context.h"
////////////////////////////////////////////////////////////////////////////////

#endif//__DSCRIPT_H__