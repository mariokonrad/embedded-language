/*	see copyright notice in squirrel.h */
#ifndef _SQSTD_SYSTEMLIB_H_
#define _SQSTD_SYSTEMLIB_H_

#ifdef __cplusplus
extern "C" {
#endif

SQUIRREL_API SQInteger sqstd_register_systemlib(HSQUIRRELVM v);

#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif /* _SQSTD_SYSTEMLIB_H_ */
