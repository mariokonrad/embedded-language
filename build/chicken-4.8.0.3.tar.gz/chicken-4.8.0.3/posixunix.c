/* Generated from posixunix.scm by the CHICKEN compiler
   http://www.call-cc.org
   2013-03-12 01:03
   Version 4.8.0.3 (stability/4.8.0) (rev 091c3d9)
   macosx-unix-clang-x86-64 [ 64bit manyargs ptables ]
   compiled 2013-03-12 on aeryn.xorinia.dim (Darwin)
   command line: posixunix.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -explicit-use -no-trace -output-file posixunix.c
   unit: posix
*/

#include "chicken.h"


#include <signal.h>
#include <errno.h>
#include <math.h>

#include <sys/types.h>
#include <sys/stat.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

#define C_curdir(buf)       (getcwd(C_c_string(buf), 1024) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

static C_TLS struct stat C_statbuf;

#define C_stat_type         (C_statbuf.st_mode & S_IFMT)
#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

#ifndef S_IFSOCK
# define S_IFSOCK           0140000
#endif

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

#define C_C_fileno(p)	    C_fix(fileno(C_port_file(p)))

#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#ifndef S_IFLNK
#define S_IFLNK S_IFREG
#endif

#ifndef S_IFREG
#define S_IFREG S_IFREG
#endif

#ifndef S_IFDIR
#define S_IFDIR S_IFREG
#endif

#ifndef S_IFCHR
#define S_IFCHR S_IFREG
#endif

#ifndef S_IFBLK
#define S_IFBLK S_IFREG
#endif

#ifndef S_IFSOCK
#define S_IFSOCK S_IFREG
#endif

#ifndef S_IFIFO
#define S_IFIFO S_IFREG
#endif

static C_TLS int C_wait_status;

#include <unistd.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <dirent.h>
#include <pwd.h>
#include <utime.h>

#if defined(__sun__) && defined(__svr4__)
# include <sys/tty.h>
#endif

#ifdef HAVE_GRP_H
#include <grp.h>
#endif

#include <sys/mman.h>
#include <time.h>

#ifndef O_FSYNC
# define O_FSYNC O_SYNC
#endif

#ifndef PIPE_BUF
# ifdef __CYGWIN__
#  define PIPE_BUF       _POSIX_PIPE_BUF
# else
#  define PIPE_BUF 1024
# endif
#endif

#ifndef O_BINARY
# define O_BINARY        0
#endif
#ifndef O_TEXT
# define O_TEXT          0
#endif

#ifndef ARG_MAX
# define ARG_MAX 256
#endif

#ifndef MAP_FILE
# define MAP_FILE    0
#endif

#ifndef MAP_ANON
# define MAP_ANON    0
#endif

#if defined(HAVE_CRT_EXTERNS_H)
# include <crt_externs.h>
# define C_getenventry(i)       ((*_NSGetEnviron())[ i ])
#elif defined(C_MACOSX)
# define C_getenventry(i)       NULL
#else
extern char **environ;
# define C_getenventry(i)       (environ[ i ])
#endif

#ifndef ENV_MAX
# define ENV_MAX        1024
#endif

#ifndef FILENAME_MAX
# define FILENAME_MAX          1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct utsname C_utsname;
static C_TLS struct flock C_flock;
static C_TLS DIR *temphandle;
static C_TLS struct passwd *C_user;
#ifdef HAVE_GRP_H
static C_TLS struct group *C_group;
#else
static C_TLS struct {
  char *gr_name, gr_passwd;
  int gr_gid;
  char *gr_mem[ 1 ];
} C_group = { "", "", 0, { "" } };
#endif
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS fd_set C_fd_sets[ 2 ];
static C_TLS struct timeval C_timeval;
static C_TLS char C_hostbuf[ 256 ];
static C_TLS struct stat C_statbuf;

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#define C_fchdir(fd)        C_fix(fchdir(C_unfix(fd)))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

#define C_opendir(x,h)      C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)       (closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)      C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)    (strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(pclose(C_port_file(p)))

#define C_fork              fork
#define C_waitpid(id, o)    C_fix(waitpid(C_unfix(id), &C_wait_status, C_unfix(o)))
#define C_getppid           getppid
#define C_kill(id, s)       C_fix(kill(C_unfix(id), C_unfix(s)))
#define C_getuid            getuid
#define C_getgid            getgid
#define C_geteuid           geteuid
#define C_getegid           getegid
#define C_chown(fn, u, g)   C_fix(chown(C_data_pointer(fn), C_unfix(u), C_unfix(g)))
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_setuid(id)        C_fix(setuid(C_unfix(id)))
#define C_setgid(id)        C_fix(setgid(C_unfix(id)))
#define C_seteuid(id)       C_fix(seteuid(C_unfix(id)))
#define C_setegid(id)       C_fix(setegid(C_unfix(id)))
#define C_setsid(dummy)     C_fix(setsid())
#define C_setpgid(x, y)     C_fix(setpgid(C_unfix(x), C_unfix(y)))
#define C_getpgid(x)        C_fix(getpgid(C_unfix(x)))
#define C_symlink(o, n)     C_fix(symlink(C_data_pointer(o), C_data_pointer(n)))
#define C_do_readlink(f, b)    C_fix(readlink(C_data_pointer(f), C_data_pointer(b), FILENAME_MAX))
#define C_getpwnam(n)       C_mk_bool((C_user = getpwnam((char *)C_data_pointer(n))) != NULL)
#define C_getpwuid(u)       C_mk_bool((C_user = getpwuid(C_unfix(u))) != NULL)
#ifdef HAVE_GRP_H
#define C_getgrnam(n)       C_mk_bool((C_group = getgrnam((char *)C_data_pointer(n))) != NULL)
#define C_getgrgid(u)       C_mk_bool((C_group = getgrgid(C_unfix(u))) != NULL)
#else
#define C_getgrnam(n)       C_SCHEME_FALSE
#define C_getgrgid(n)       C_SCHEME_FALSE
#endif
#define C_pipe(d)           C_fix(pipe(C_pipefds))
#define C_truncate(f, n)    C_fix(truncate((char *)C_data_pointer(f), C_num_to_int(n)))
#define C_ftruncate(f, n)   C_fix(ftruncate(C_unfix(f), C_num_to_int(n)))
#define C_uname             C_fix(uname(&C_utsname))
#define C_alarm             alarm
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_test_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_close(fd)         C_fix(close(C_unfix(fd)))
#define C_sleep             sleep
#define C_umask(m)          C_fix(umask(C_unfix(m)))

#define C_lstat(fn)         C_fix(lstat((char *)C_data_pointer(fn), &C_statbuf))

#ifdef C_GNU_ENV
# define C_unsetenv(s)      (unsetenv((char *)C_data_pointer(s)), C_SCHEME_TRUE)
# define C_setenv(x, y)     C_fix(setenv((char *)C_data_pointer(x), (char *)C_data_pointer(y), 1))
#else
# define C_unsetenv(s)      C_fix(putenv((char *)C_data_pointer(s)))
static C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}
#endif

static void C_fcall C_set_arg_string(char **where, int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
    /* Can't barf() here, so the NUL byte check happens in Scheme */
  }
  else ptr = NULL;
  where[ i ] = ptr;
}

static void C_fcall C_free_arg_string(char **where) {
  while((*where) != NULL) C_free(*(where++));
}

static void C_set_timeval(C_word num, struct timeval *tm)
{
  if((num & C_FIXNUM_BIT) != 0) {
    tm->tv_sec = C_unfix(num);
    tm->tv_usec = 0;
  }
  else {
    double i;
    tm->tv_usec = (int)(modf(C_flonum_magnitude(num), &i) * 1000000);
    tm->tv_sec = (int)i;
  }
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_free_exec_args()		C_free_arg_string(C_exec_args)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)
#define C_free_exec_env()		C_free_arg_string(C_exec_env)

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))
#define C_execve(f)         C_fix(execve(C_data_pointer(f), C_exec_args, C_exec_env))

#if defined(__FreeBSD__) || defined(C_MACOSX) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sgi__) || defined(sgi) || defined(__DragonFly__) || defined(__SUNPRO_C)
static C_TLS int C_uw;
# define C_WIFEXITED(n)      (C_uw = C_unfix(n), C_mk_bool(WIFEXITED(C_uw)))
# define C_WIFSIGNALED(n)    (C_uw = C_unfix(n), C_mk_bool(WIFSIGNALED(C_uw)))
# define C_WIFSTOPPED(n)     (C_uw = C_unfix(n), C_mk_bool(WIFSTOPPED(C_uw)))
# define C_WEXITSTATUS(n)    (C_uw = C_unfix(n), C_fix(WEXITSTATUS(C_uw)))
# define C_WTERMSIG(n)       (C_uw = C_unfix(n), C_fix(WTERMSIG(C_uw)))
# define C_WSTOPSIG(n)       (C_uw = C_unfix(n), C_fix(WSTOPSIG(C_uw)))
#else
# define C_WIFEXITED(n)      C_mk_bool(WIFEXITED(C_unfix(n)))
# define C_WIFSIGNALED(n)    C_mk_bool(WIFSIGNALED(C_unfix(n)))
# define C_WIFSTOPPED(n)     C_mk_bool(WIFSTOPPED(C_unfix(n)))
# define C_WEXITSTATUS(n)    C_fix(WEXITSTATUS(C_unfix(n)))
# define C_WTERMSIG(n)       C_fix(WTERMSIG(C_unfix(n)))
# define C_WSTOPSIG(n)       C_fix(WSTOPSIG(C_unfix(n)))
#endif

#ifdef __CYGWIN__
# define C_mkfifo(fn, m)    C_fix(-1);
#else
# define C_mkfifo(fn, m)    C_fix(mkfifo((char *)C_data_pointer(fn), C_unfix(m)))
#endif

#define C_flock_setup(t, s, n) (C_flock.l_type = C_unfix(t), C_flock.l_start = C_num_to_int(s), C_flock.l_whence = SEEK_SET, C_flock.l_len = C_num_to_int(n), C_SCHEME_UNDEFINED)
#define C_flock_test(p)     (fcntl(fileno(C_port_file(p)), F_GETLK, &C_flock) >= 0 ? (C_flock.l_type == F_UNLCK ? C_fix(0) : C_fix(C_flock.l_pid)) : C_SCHEME_FALSE)
#define C_flock_lock(p)     C_fix(fcntl(fileno(C_port_file(p)), F_SETLK, &C_flock))
#define C_flock_lockw(p)    C_fix(fcntl(fileno(C_port_file(p)), F_SETLKW, &C_flock))

static C_TLS sigset_t C_sigset;
#define C_sigemptyset(d)    (sigemptyset(&C_sigset), C_SCHEME_UNDEFINED)
#define C_sigaddset(s)      (sigaddset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigdelset(s)      (sigdelset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigismember(s)    C_mk_bool(sigismember(&C_sigset, C_unfix(s)))
#define C_sigprocmask_set(d)        C_fix(sigprocmask(SIG_SETMASK, &C_sigset, NULL))
#define C_sigprocmask_block(d)      C_fix(sigprocmask(SIG_BLOCK, &C_sigset, NULL))
#define C_sigprocmask_unblock(d)    C_fix(sigprocmask(SIG_UNBLOCK, &C_sigset, NULL))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mkstemp(C_c_string(t)))

/* It is assumed that 'int' is-a 'long' */
#define C_ftell(p)          C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)    C_mk_nbool(fseek(C_port_file(p), C_num_to_int(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_zero_fd_set(i)      FD_ZERO(&C_fd_sets[ i ])
#define C_set_fd_set(i, fd)   FD_SET(fd, &C_fd_sets[ i ])
#define C_test_fd_set(i, fd)  FD_ISSET(fd, &C_fd_sets[ i ])
#define C_C_select(m)         C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, NULL))
#define C_C_select_t(m, t)    (C_set_timeval(t, &C_timeval), \
			       C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, &C_timeval)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#if defined(__SVR4) || defined(C_MACOSX)
/* Seen here: http://lists.samba.org/archive/samba-technical/2002-November/025571.html */

static time_t C_timegm(struct tm *t)
{
  time_t tl, tb;
  struct tm *tg;

  tl = mktime (t);
  if (tl == -1)
    {
      t->tm_hour--;
      tl = mktime (t);
      if (tl == -1)
        return -1; /* can't deal with output from strptime */
      tl += 3600;
    }
  tg = gmtime (&tl);
  tg->tm_isdst = 0;
  tb = mktime (tg);
  if (tb == -1)
    {
      tg->tm_hour--;
      tb = mktime (tg);
      if (tb == -1)
        return -1; /* can't deal with output from gmtime */
      tb += 3600;
    }
  return (tl - (tb - tl));
}
#else
#define C_timegm timegm
#endif

#define cpy_tmvec_to_tmstc08(ptm, v) \
    (memset((ptm), 0, sizeof(struct tm)), \
    (ptm)->tm_sec = C_unfix(C_block_item((v), 0)), \
    (ptm)->tm_min = C_unfix(C_block_item((v), 1)), \
    (ptm)->tm_hour = C_unfix(C_block_item((v), 2)), \
    (ptm)->tm_mday = C_unfix(C_block_item((v), 3)), \
    (ptm)->tm_mon = C_unfix(C_block_item((v), 4)), \
    (ptm)->tm_year = C_unfix(C_block_item((v), 5)), \
    (ptm)->tm_wday = C_unfix(C_block_item((v), 6)), \
    (ptm)->tm_yday = C_unfix(C_block_item((v), 7)), \
    (ptm)->tm_isdst = (C_block_item((v), 8) != C_SCHEME_FALSE))

#define cpy_tmvec_to_tmstc9(ptm, v) \
    (((struct tm *)ptm)->tm_gmtoff = -C_unfix(C_block_item((v), 9)))

#define cpy_tmstc08_to_tmvec(v, ptm) \
    (C_set_block_item((v), 0, C_fix(((struct tm *)ptm)->tm_sec)), \
    C_set_block_item((v), 1, C_fix((ptm)->tm_min)), \
    C_set_block_item((v), 2, C_fix((ptm)->tm_hour)), \
    C_set_block_item((v), 3, C_fix((ptm)->tm_mday)), \
    C_set_block_item((v), 4, C_fix((ptm)->tm_mon)), \
    C_set_block_item((v), 5, C_fix((ptm)->tm_year)), \
    C_set_block_item((v), 6, C_fix((ptm)->tm_wday)), \
    C_set_block_item((v), 7, C_fix((ptm)->tm_yday)), \
    C_set_block_item((v), 8, ((ptm)->tm_isdst ? C_SCHEME_TRUE : C_SCHEME_FALSE)))

#define cpy_tmstc9_to_tmvec(v, ptm) \
    (C_set_block_item((v), 9, C_fix(-(ptm)->tm_gmtoff)))

#define C_tm_set_08(v)  cpy_tmvec_to_tmstc08( &C_tm, (v) )
#define C_tm_set_9(v)   cpy_tmvec_to_tmstc9( &C_tm, (v) )

#define C_tm_get_08(v)  cpy_tmstc08_to_tmvec( (v), &C_tm )
#define C_tm_get_9(v)   cpy_tmstc9_to_tmvec( (v), &C_tm )

#if !defined(C_GNU_ENV) || defined(__CYGWIN__) || defined(__uClinux__)

static struct tm *
C_tm_set( C_word v )
{
  C_tm_set_08( v );
  return &C_tm;
}

static C_word
C_tm_get( C_word v )
{
  C_tm_get_08( v );
  return v;
}

#else

static struct tm *
C_tm_set( C_word v )
{
  C_tm_set_08( v );
  C_tm_set_9( v );
  return &C_tm;
}

static C_word
C_tm_get( C_word v )
{
  C_tm_get_08( v );
  C_tm_get_9( v );
  return v;
}

#endif

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_a_mktime(ptr, c, v)  C_flonum(ptr, mktime(C_tm_set(v)))
#define C_a_timegm(ptr, c, v)  C_flonum(ptr, C_timegm(C_tm_set(v)))

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#ifdef __linux__
extern char *strptime(const char *s, const char *format, struct tm *tm);
extern pid_t getpgid(pid_t pid);
#endif

#define C_strptime(s, f, v) \
        (strptime(C_c_string(s), C_c_string(f), &C_tm) ? C_tm_get(v) : C_SCHEME_FALSE)

static gid_t *C_groups = NULL;

#define C_get_gid(n)      C_fix(C_groups[ C_unfix(n) ])
#define C_set_gid(n, id)  (C_groups[ C_unfix(n) ] = C_unfix(id), C_SCHEME_UNDEFINED)
#define C_set_groups(n)   C_fix(setgroups(C_unfix(n), C_groups))

#ifdef TIOCGWINSZ
static int get_tty_size(int p, int *rows, int *cols)
{
 struct winsize tty_size;
 int r;

 memset(&tty_size, 0, sizeof tty_size);

 r = ioctl(p, TIOCGWINSZ, &tty_size);
 if (r == 0) {
    *rows = tty_size.ws_row;
    *cols = tty_size.ws_col;
 }
 return r;
}
#else
static int get_tty_size(int p, int *rows, int *cols)
{
 *rows = *cols = 0;
 return -1;
}
#endif

static int set_file_mtime(char *filename, C_word tm)
{
  struct utimbuf tb;

  tb.actime = tb.modtime = C_num_to_int(tm);
  return utime(filename, &tb);
}

static C_word C_i_fifo_p(C_word name) 
{
  struct stat buf;
  int res;

  res = stat(C_c_string(name), &buf);

  if(res != 0) {
#ifdef __CYGWIN__
    return C_SCHEME_FALSE;
#else
    if(errno == ENOENT) return C_fix(0);
    else return C_fix(res);
#endif
  }

  if((buf.st_mode & S_IFMT) == S_IFIFO) return C_SCHEME_TRUE;
  else return C_SCHEME_FALSE;
}


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_irregex_toplevel)
C_externimport void C_ccall C_irregex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[462];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,14),40,102,95,50,54,48,56,32,97,54,52,54,55,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,41),40,112,111,115,105,120,45,101,114,114,111,114,32,116,121,112,101,54,57,32,108,111,99,55,48,32,109,115,103,55,49,32,46,32,97,114,103,115,55,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,115,116,97,116,32,102,105,108,101,56,52,32,108,105,110,107,56,53,32,101,114,114,56,54,32,108,111,99,56,55,41,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,115,116,97,116,32,102,57,57,32,46,32,116,109,112,57,56,49,48,48,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,97,99,99,101,115,115,45,116,105,109,101,32,102,49,50,53,41,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,99,104,97,110,103,101,45,116,105,109,101,32,102,49,50,56,41,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,111,119,110,101,114,32,102,49,51,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,101,114,109,105,115,115,105,111,110,115,32,102,49,51,52,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,16),40,102,105,108,101,45,115,105,122,101,32,102,49,51,55,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,116,121,112,101,32,102,105,108,101,49,52,53,32,46,32,116,109,112,49,52,52,49,52,54,41,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,23),40,114,101,103,117,108,97,114,45,102,105,108,101,63,32,102,105,108,101,49,54,52,41,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,24),40,115,121,109,98,111,108,105,99,45,108,105,110,107,63,32,102,105,108,101,49,54,54,41};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,23),40,98,108,111,99,107,45,100,101,118,105,99,101,63,32,102,105,108,101,49,54,56,41,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,27),40,99,104,97,114,97,99,116,101,114,45,100,101,118,105,99,101,63,32,102,105,108,101,49,55,48,41,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,16),40,102,95,50,56,52,54,32,102,105,108,101,49,55,50,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,17),40,115,111,99,107,101,116,63,32,102,105,108,101,49,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,20),40,100,105,114,101,99,116,111,114,121,63,32,102,105,108,101,49,55,54,41,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,25),40,109,111,100,101,32,105,110,112,49,56,50,32,109,49,56,51,32,108,111,99,49,56,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,32),40,99,104,101,99,107,32,108,111,99,49,57,52,32,102,100,49,57,53,32,105,110,112,49,57,54,32,114,49,57,55,41};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,102,105,108,101,42,32,102,100,50,48,48,32,46,32,109,50,48,49,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,102,105,108,101,42,32,102,100,50,48,51,32,46,32,109,50,48,52,41};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,22),40,112,111,114,116,45,62,102,105,108,101,110,111,32,112,111,114,116,50,49,48,41,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,34),40,100,117,112,108,105,99,97,116,101,45,102,105,108,101,110,111,32,111,108,100,50,49,56,32,46,32,110,101,119,50,49,57,41,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,31),40,99,117,114,114,101,110,116,45,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,50,51,48,50,51,49,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,14),40,114,109,100,105,114,32,100,105,114,50,53,56,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,13),40,102,95,51,48,56,51,32,102,50,55,52,41,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,26),40,102,111,114,45,101,97,99,104,45,108,111,111,112,50,54,52,32,103,50,55,49,50,56,49,41,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,38),40,100,101,108,101,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,50,53,48,32,46,32,116,109,112,50,52,57,50,53,49,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,23),40,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,50,57,51,50,57,52,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,8),40,102,95,51,50,56,49,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,13),40,102,95,51,51,49,54,32,109,51,53,55,41,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,102,110,115,51,52,57,41,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,47),40,102,95,51,50,56,54,32,100,105,114,51,51,50,51,51,51,51,51,56,32,102,105,108,51,51,52,51,51,53,51,51,57,32,101,120,116,51,51,54,51,51,55,51,52,48,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,20),40,99,111,110,99,45,108,111,111,112,32,112,97,116,104,115,51,51,48,41,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,17),40,103,108,111,98,32,46,32,112,97,116,104,115,51,50,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,8),40,102,95,51,52,51,50,41};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,8),40,102,95,51,52,51,55,41};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,8),40,102,95,51,52,53,55,41};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,102,115,51,56,54,32,114,51,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,13),40,102,95,51,53,49,48,32,120,51,56,52,41,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,15),40,102,95,51,53,51,48,32,46,32,95,51,55,56,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,15),40,102,95,51,53,50,49,32,46,32,95,51,55,55,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,8),40,102,95,51,53,53,53,41};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,8),40,102,95,51,53,53,56,41};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,8),40,102,95,51,53,54,49,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,8),40,102,95,51,53,54,52,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,18),40,102,95,51,53,54,57,32,120,52,50,48,32,121,52,50,49,41,0,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,8),40,102,95,51,53,54,55,41};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,15),40,102,95,51,53,55,54,32,46,32,95,52,49,56,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,8),40,102,95,51,53,55,52,41};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,31),40,102,105,110,100,45,102,105,108,101,115,32,100,105,114,52,49,53,32,46,32,116,109,112,52,49,52,52,49,54,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,32),40,99,104,101,99,107,45,116,105,109,101,45,118,101,99,116,111,114,32,108,111,99,52,52,52,32,116,109,52,52,53,41};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,33),40,115,101,99,111,110,100,115,45,62,108,111,99,97,108,45,116,105,109,101,32,46,32,116,109,112,52,53,50,52,53,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,31),40,115,101,99,111,110,100,115,45,62,117,116,99,45,116,105,109,101,32,46,32,116,109,112,52,54,53,52,54,54,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,16),40,102,95,51,54,52,51,32,97,52,55,53,52,55,56,41};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,29),40,115,101,99,111,110,100,115,45,62,115,116,114,105,110,103,32,46,32,116,109,112,52,56,52,52,56,53,41,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,27),40,108,111,99,97,108,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,52,57,52,41,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,16),40,102,95,51,55,48,50,32,97,53,48,48,53,48,51,41};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,24),40,102,95,51,55,48,56,32,97,53,48,54,53,48,57,32,97,53,48,53,53,49,48,41};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,26),40,102,95,51,55,49,52,32,116,109,53,49,55,32,46,32,116,109,112,53,49,54,53,49,56,41,0,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,36),40,115,101,116,45,115,105,103,110,97,108,45,104,97,110,100,108,101,114,33,32,115,105,103,53,51,49,32,112,114,111,99,53,51,50,41,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,20),40,99,117,114,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,8),40,102,95,51,56,48,52,41};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,34),40,102,95,51,56,48,57,32,101,112,105,100,53,53,54,32,101,110,111,114,109,53,53,55,32,101,99,111,100,101,53,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,24),40,112,114,111,99,101,115,115,45,119,97,105,116,32,46,32,97,114,103,115,53,52,49,41};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,102,105,108,101,45,110,111,110,98,108,111,99,107,105,110,103,33,32,97,54,48,49,54,48,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,108,101,45,115,101,108,101,99,116,45,111,110,101,32,97,54,48,54,54,48,57,41,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,32),40,102,95,51,56,57,55,32,97,54,53,48,54,53,51,32,97,54,52,57,54,53,52,32,97,54,52,56,54,53,53,41};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,99,111,110,116,114,111,108,32,102,100,54,54,49,32,99,109,100,54,54,50,32,46,32,116,109,112,54,54,48,54,54,51,41,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,42),40,102,105,108,101,45,111,112,101,110,32,102,105,108,101,110,97,109,101,54,55,52,32,102,108,97,103,115,54,55,53,32,46,32,109,111,100,101,54,55,54,41,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,18),40,102,105,108,101,45,99,108,111,115,101,32,102,100,54,56,52,41,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,37),40,102,105,108,101,45,114,101,97,100,32,102,100,54,56,55,32,115,105,122,101,54,56,56,32,46,32,98,117,102,102,101,114,54,56,57,41,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,38),40,102,105,108,101,45,119,114,105,116,101,32,102,100,54,57,56,32,98,117,102,102,101,114,54,57,57,32,46,32,115,105,122,101,55,48,48,41,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,109,107,115,116,101,109,112,32,116,101,109,112,108,97,116,101,55,48,57,41,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,16),40,102,95,52,48,56,49,32,97,55,49,57,55,50,50,41};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,24),40,102,95,52,48,56,54,32,97,55,50,52,55,50,55,32,97,55,50,51,55,50,56,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,24),40,102,95,52,48,57,52,32,97,55,51,48,55,51,51,32,97,55,50,57,55,51,52,41};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,14),40,102,95,52,49,55,49,32,102,100,56,51,57,41,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,26),40,102,111,114,45,101,97,99,104,45,108,111,111,112,56,50,57,32,103,56,51,54,56,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,14),40,102,95,52,50,49,54,32,102,100,56,49,56,41,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,26),40,102,111,114,45,101,97,99,104,45,108,111,111,112,56,48,56,32,103,56,49,53,56,50,48,41,0,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,14),40,102,95,52,50,55,50,32,102,100,55,56,55,41,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,26),40,102,111,114,45,101,97,99,104,45,108,111,111,112,55,55,55,32,103,55,56,52,55,57,49,41,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,14),40,102,95,52,51,49,53,32,102,100,55,53,57,41,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,26),40,102,111,114,45,101,97,99,104,45,108,111,111,112,55,52,57,32,103,55,53,54,55,54,51,41,0,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,42),40,102,105,108,101,45,115,101,108,101,99,116,32,102,100,115,114,55,51,53,32,102,100,115,119,55,51,54,32,46,32,116,105,109,101,111,117,116,55,51,55,41,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,47),40,115,101,116,45,102,105,108,101,45,112,111,115,105,116,105,111,110,33,32,112,111,114,116,56,53,52,32,112,111,115,56,53,53,32,46,32,119,104,101,110,99,101,56,53,54,41,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,23),40,102,95,52,52,52,53,32,108,111,99,56,57,52,32,110,97,109,101,56,57,53,41,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,100,105,114,56,57,48,41,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,8),40,102,95,52,52,55,50,41};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,48),40,102,95,52,52,55,55,32,100,105,114,56,57,56,56,57,57,57,48,52,32,102,105,108,101,57,48,48,57,48,49,57,48,53,32,101,120,116,57,48,50,57,48,51,57,48,54,41};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,23),40,102,95,52,52,56,53,32,108,111,99,57,49,50,32,110,97,109,101,57,49,51,41,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,38),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,56,55,56,32,46,32,116,109,112,56,55,55,56,55,57,41,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,26),40,99,104,97,110,103,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,57,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,25),40,99,104,97,110,103,101,45,100,105,114,101,99,116,111,114,121,42,32,102,100,57,50,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,108,111,99,57,51,48,32,99,109,100,57,51,49,32,105,110,112,57,51,50,32,114,57,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,57,51,54,32,46,32,109,57,51,55,41,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,57,52,53,32,46,32,109,57,52,54,41};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,26),40,99,108,111,115,101,45,105,110,112,117,116,45,112,105,112,101,32,112,111,114,116,57,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,27),40,99,108,111,115,101,45,111,117,116,112,117,116,45,112,105,112,101,32,112,111,114,116,57,53,56,41,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,8),40,102,95,52,54,57,51,41};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,21),40,102,95,52,54,57,56,32,46,32,114,101,115,117,108,116,115,57,55,51,41,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,47),40,99,97,108,108,45,119,105,116,104,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,57,54,57,32,112,114,111,99,57,55,48,32,46,32,109,111,100,101,57,55,49,41,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,8),40,102,95,52,55,49,53,41};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,21),40,102,95,52,55,50,48,32,46,32,114,101,115,117,108,116,115,57,56,48,41,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,48),40,99,97,108,108,45,119,105,116,104,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,57,55,54,32,112,114,111,99,57,55,55,32,46,32,109,111,100,101,57,55,56,41};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,8),40,102,95,52,55,51,55,41};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,21),40,102,95,52,55,52,55,32,46,32,114,101,115,117,108,116,115,57,57,53,41,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,8),40,102,95,52,55,52,50,41};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,8),40,102,95,52,55,53,53,41};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,48),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,112,105,112,101,32,99,109,100,57,56,51,32,116,104,117,110,107,57,56,52,32,46,32,109,111,100,101,57,56,53,41};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,8),40,102,95,52,55,54,57,41};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,22),40,102,95,52,55,55,57,32,46,32,114,101,115,117,108,116,115,49,48,49,50,41,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,8),40,102,95,52,55,55,52,41};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,8),40,102,95,52,55,56,55,41};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,50),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,112,105,112,101,32,99,109,100,49,48,48,48,32,116,104,117,110,107,49,48,48,49,32,46,32,109,111,100,101,49,48,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,13),40,99,114,101,97,116,101,45,112,105,112,101,41,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,14),40,102,95,52,56,52,50,32,115,49,48,53,56,41,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,48,52,56,32,103,49,48,53,53,49,48,54,49,41,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,27),40,115,101,116,45,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,115,49,48,52,53,41,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,115,105,103,115,49,48,55,48,32,109,97,115,107,49,48,55,49,41};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,13),40,115,105,103,110,97,108,45,109,97,115,107,41,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,24),40,115,105,103,110,97,108,45,109,97,115,107,101,100,63,32,115,105,103,49,48,55,53,41};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,22),40,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,49,48,55,56,41,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,24),40,115,105,103,110,97,108,45,117,110,109,97,115,107,33,32,115,105,103,49,48,56,50,41};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,20),40,115,121,115,116,101,109,45,105,110,102,111,114,109,97,116,105,111,110,41,0,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,41),40,117,115,101,114,45,105,110,102,111,114,109,97,116,105,111,110,32,117,115,101,114,49,49,49,52,32,46,32,116,109,112,49,49,49,51,49,49,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,19),40,99,117,114,114,101,110,116,45,117,115,101,114,45,110,97,109,101,41,0,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,29),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,117,115,101,114,45,110,97,109,101,41,0,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,49,53,51,41,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,43),40,103,114,111,117,112,45,105,110,102,111,114,109,97,116,105,111,110,32,103,114,111,117,112,49,49,52,48,32,46,32,116,109,112,49,49,51,57,49,49,52,49,41,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,49,55,50,41,0,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,12),40,103,101,116,45,103,114,111,117,112,115,41,0,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,26),40,100,111,108,111,111,112,49,49,55,57,32,108,115,116,49,49,56,49,32,105,49,49,56,50,41,0,0,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,22),40,115,101,116,45,103,114,111,117,112,115,33,32,108,115,116,48,49,49,55,56,41,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,28),40,102,95,53,50,53,54,32,97,49,49,57,50,49,49,57,54,32,97,49,49,57,49,49,49,57,55,41,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,35),40,105,110,105,116,105,97,108,105,122,101,45,103,114,111,117,112,115,32,117,115,101,114,49,49,57,57,32,105,100,49,50,48,48,41,0,0,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,34),40,99,104,97,110,103,101,45,102,105,108,101,45,109,111,100,101,32,102,110,97,109,101,49,50,52,52,32,109,49,50,52,53,41,0,0,0,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,42),40,99,104,97,110,103,101,45,102,105,108,101,45,111,119,110,101,114,32,102,110,49,50,52,57,32,117,105,100,49,50,53,48,32,103,105,100,49,50,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,36),40,99,104,101,99,107,32,102,105,108,101,110,97,109,101,49,50,53,54,32,97,99,99,49,50,53,55,32,108,111,99,49,50,53,56,41,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,32),40,102,105,108,101,45,114,101,97,100,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,49,50,54,50,41};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,33),40,102,105,108,101,45,119,114,105,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,49,50,54,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,35),40,102,105,108,101,45,101,120,101,99,117,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,49,50,54,52,41,0,0,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,16),40,99,114,101,97,116,101,45,115,101,115,115,105,111,110,41};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,38),40,99,114,101,97,116,101,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,111,108,100,49,50,56,52,32,110,101,119,49,50,56,53,41,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,44),40,114,101,97,100,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,102,110,97,109,101,49,50,57,53,32,46,32,116,109,112,49,50,57,52,49,50,57,54,41,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,28),40,102,95,53,53,49,55,32,97,49,51,48,57,49,51,49,52,32,97,49,51,48,56,49,51,49,53,41,0,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,27),40,102,105,108,101,45,108,105,110,107,32,111,108,100,49,51,49,56,32,110,101,119,49,51,49,57,41,0,0,0,0,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,8),40,102,95,53,53,56,52,41};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,8),40,102,95,53,54,49,49,41};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,8),40,102,95,53,54,49,56,41};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,8),40,102,95,53,55,49,57,41};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,8),40,102,95,53,55,51,48,41};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,8),40,102,95,53,55,52,49,41};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,8),40,102,95,53,55,54,49,41};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,28),40,108,111,111,112,32,110,49,51,57,53,32,109,49,51,57,54,32,115,116,97,114,116,49,51,57,55,41,0,0,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,42),40,102,95,53,55,54,57,32,112,111,114,116,49,51,57,48,32,110,49,51,57,49,32,100,101,115,116,49,51,57,50,32,115,116,97,114,116,49,51,57,51,41,0,0,0,0,0,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,24),40,102,95,53,56,52,52,32,99,117,114,49,52,49,53,32,112,116,114,49,52,49,54,41};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,8),40,102,95,53,57,49,48,41};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,43),40,102,95,53,57,49,53,32,100,101,115,116,49,52,51,53,49,52,51,54,49,52,51,57,32,99,111,110,116,63,49,52,51,55,49,52,51,56,49,52,52,48,41,0,0,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,115,116,114,49,52,49,51,41,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,27),40,102,95,53,56,51,54,32,112,111,114,116,49,52,49,48,32,108,105,109,105,116,49,52,49,49,41,0,0,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,17),40,102,95,53,57,51,53,32,112,111,114,116,49,52,52,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,62),40,35,35,115,121,115,35,99,117,115,116,111,109,45,105,110,112,117,116,45,112,111,114,116,32,108,111,99,49,51,50,56,32,110,97,109,49,51,50,57,32,102,100,49,51,51,48,32,46,32,116,109,112,49,51,50,55,49,51,51,49,41,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,22),40,112,111,107,101,32,115,116,114,49,52,55,53,32,108,101,110,49,52,55,54,41,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,16),40,102,95,54,48,57,56,32,115,116,114,49,53,48,57,41};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,8),40,102,95,54,49,48,51,41};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,8),40,102,95,54,49,50,51,41};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,16),40,102,95,54,49,51,48,32,115,116,114,49,52,57,50,41};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,32),40,108,111,111,112,32,114,101,109,49,52,57,55,32,115,116,97,114,116,49,52,57,56,32,108,101,110,49,52,57,57,41};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,16),40,102,95,54,49,52,51,32,115,116,114,49,52,57,53,41};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,63),40,35,35,115,121,115,35,99,117,115,116,111,109,45,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,49,52,53,55,32,110,97,109,49,52,53,56,32,102,100,49,52,53,57,32,46,32,116,109,112,49,52,53,54,49,52,54,48,41,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,33),40,102,105,108,101,45,116,114,117,110,99,97,116,101,32,102,110,97,109,101,49,53,49,55,32,111,102,102,49,53,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,32,112,111,114,116,49,53,50,53,32,97,114,103,115,49,53,50,54,32,108,111,99,49,53,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,30),40,101,114,114,32,109,115,103,49,53,52,50,32,108,111,99,107,49,53,52,51,32,108,111,99,49,53,52,52,41,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,108,111,99,107,32,112,111,114,116,49,53,52,53,32,46,32,97,114,103,115,49,53,52,54,41,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,40),40,102,105,108,101,45,108,111,99,107,47,98,108,111,99,107,105,110,103,32,112,111,114,116,49,53,52,56,32,46,32,97,114,103,115,49,53,52,57,41};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,14),40,102,95,54,51,57,56,32,99,49,53,54,49,41,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,36),40,102,105,108,101,45,116,101,115,116,45,108,111,99,107,32,112,111,114,116,49,53,53,49,32,46,32,97,114,103,115,49,53,53,50,41,0,0,0,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,117,110,108,111,99,107,32,108,111,99,107,49,53,54,56,41,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,34),40,99,114,101,97,116,101,45,102,105,102,111,32,102,110,97,109,101,49,53,55,50,32,46,32,109,111,100,101,49,53,55,51,41,0,0,0,0,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,20),40,102,105,102,111,63,32,102,105,108,101,110,97,109,101,49,53,55,56,41,0,0,0,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,24),40,115,101,116,101,110,118,32,118,97,114,49,53,56,54,32,118,97,108,49,53,56,55,41};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,18),40,117,110,115,101,116,101,110,118,32,118,97,114,49,53,57,50,41,0,0,0,0,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,18),40,102,95,54,53,52,49,32,97,49,53,57,55,49,54,48,48,41,0,0,0,0,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,12),40,115,99,97,110,32,106,49,54,48,54,41,0,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,54,48,51,41,0,0,0,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,27),40,103,101,116,45,101,110,118,105,114,111,110,109,101,110,116,45,118,97,114,105,97,98,108,101,115,41,0,0,0,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,68),40,102,95,54,54,49,55,32,97,49,54,50,53,49,54,50,57,32,97,49,54,50,52,49,54,51,48,32,97,49,54,50,51,49,54,51,49,32,97,49,54,50,50,49,54,51,50,32,97,49,54,50,49,49,54,51,51,32,97,49,54,50,48,49,54,51,52,41,0,0,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,72),40,109,97,112,45,102,105,108,101,45,116,111,45,109,101,109,111,114,121,32,97,100,100,114,49,54,51,55,32,108,101,110,49,54,51,56,32,112,114,111,116,49,54,51,57,32,102,108,97,103,49,54,52,48,32,102,100,49,54,52,49,32,46,32,111,102,102,49,54,52,50,41};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,28),40,102,95,54,54,56,51,32,97,49,54,53,50,49,54,53,54,32,97,49,54,53,49,49,54,53,55,41,0,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,43),40,117,110,109,97,112,45,102,105,108,101,45,102,114,111,109,45,109,101,109,111,114,121,32,109,109,97,112,49,54,53,57,32,46,32,108,101,110,49,54,54,48,41,0,0,0,0,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,37),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,45,112,111,105,110,116,101,114,32,109,109,97,112,49,54,54,52,41,0,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,27),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,63,32,120,49,54,54,55,41,0,0,0,0,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,18),40,102,95,54,55,52,48,32,97,49,54,55,49,49,54,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,28),40,102,95,54,55,52,54,32,97,49,54,55,55,49,54,56,48,32,97,49,54,55,54,49,54,56,49,41,0,0,0,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,35),40,116,105,109,101,45,62,115,116,114,105,110,103,32,116,109,49,54,56,56,32,46,32,116,109,112,49,54,56,55,49,54,56,57,41,0,0,0,0,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,38),40,102,95,54,56,48,48,32,97,49,55,48,53,49,55,48,56,32,97,49,55,48,52,49,55,48,57,32,97,49,55,48,51,49,55,49,48,41,0,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,36),40,115,116,114,105,110,103,45,62,116,105,109,101,32,116,105,109,49,55,49,54,32,46,32,116,109,112,49,55,49,53,49,55,49,55,41,0,0,0,0};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,26),40,117,116,99,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,49,55,50,54,41,0,0,0,0,0,0};
static C_char C_TLS li203[] C_aligned={C_lihdr(0,0,29),40,108,111,99,97,108,45,116,105,109,101,122,111,110,101,45,97,98,98,114,101,118,105,97,116,105,111,110,41,0,0,0};
static C_char C_TLS li204[] C_aligned={C_lihdr(0,0,18),40,102,95,54,56,53,52,32,97,49,55,51,53,49,55,51,56,41,0,0,0,0,0,0};
static C_char C_TLS li205[] C_aligned={C_lihdr(0,0,18),40,95,101,120,105,116,32,46,32,99,111,100,101,49,55,51,57,41,0,0,0,0,0,0};
static C_char C_TLS li206[] C_aligned={C_lihdr(0,0,22),40,115,101,116,45,97,108,97,114,109,33,32,97,49,55,52,49,49,55,52,52,41,0,0};
static C_char C_TLS li207[] C_aligned={C_lihdr(0,0,50),40,115,101,116,45,98,117,102,102,101,114,105,110,103,45,109,111,100,101,33,32,112,111,114,116,49,55,52,54,32,109,111,100,101,49,55,52,55,32,46,32,115,105,122,101,49,55,52,56,41,0,0,0,0,0,0};
static C_char C_TLS li208[] C_aligned={C_lihdr(0,0,25),40,116,101,114,109,105,110,97,108,45,112,111,114,116,63,32,112,111,114,116,49,55,53,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li209[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,116,101,114,109,105,110,97,108,45,99,104,101,99,107,32,99,97,108,108,101,114,49,55,54,52,32,112,111,114,116,49,55,54,53,41,0,0,0,0,0,0};
static C_char C_TLS li210[] C_aligned={C_lihdr(0,0,18),40,102,95,54,57,55,54,32,97,49,55,55,48,49,55,55,51,41,0,0,0,0,0,0};
static C_char C_TLS li211[] C_aligned={C_lihdr(0,0,24),40,116,101,114,109,105,110,97,108,45,110,97,109,101,32,112,111,114,116,49,55,55,53,41};
static C_char C_TLS li212[] C_aligned={C_lihdr(0,0,38),40,102,95,54,57,57,53,32,97,49,55,56,49,49,55,56,52,32,97,49,55,56,48,49,55,56,53,32,97,49,55,55,57,49,55,56,54,41,0,0};
static C_char C_TLS li213[] C_aligned={C_lihdr(0,0,24),40,116,101,114,109,105,110,97,108,45,115,105,122,101,32,112,111,114,116,49,55,56,55,41};
static C_char C_TLS li214[] C_aligned={C_lihdr(0,0,8),40,102,95,55,48,51,52,41};
static C_char C_TLS li215[] C_aligned={C_lihdr(0,0,15),40,103,101,116,45,104,111,115,116,45,110,97,109,101,41,0};
static C_char C_TLS li216[] C_aligned={C_lihdr(0,0,8),40,102,95,55,48,53,49,41};
static C_char C_TLS li217[] C_aligned={C_lihdr(0,0,18),40,102,95,55,48,55,56,32,97,49,56,50,48,49,56,50,51,41,0,0,0,0,0,0};
static C_char C_TLS li218[] C_aligned={C_lihdr(0,0,26),40,112,114,111,99,101,115,115,45,102,111,114,107,32,46,32,116,104,117,110,107,49,56,49,48,41,0,0,0,0,0,0};
static C_char C_TLS li219[] C_aligned={C_lihdr(0,0,38),40,102,95,55,48,57,51,32,97,49,56,51,51,49,56,51,55,32,97,49,56,51,50,49,56,51,56,32,97,49,56,51,49,49,56,51,57,41,0,0};
static C_char C_TLS li220[] C_aligned={C_lihdr(0,0,8),40,102,95,55,49,49,49,41};
static C_char C_TLS li221[] C_aligned={C_lihdr(0,0,38),40,102,95,55,49,49,51,32,97,49,56,52,53,49,56,52,57,32,97,49,56,52,52,49,56,53,48,32,97,49,56,52,51,49,56,53,49,41,0,0};
static C_char C_TLS li222[] C_aligned={C_lihdr(0,0,8),40,102,95,55,49,51,49,41};
static C_char C_TLS li223[] C_aligned={C_lihdr(0,0,25),40,100,111,108,111,111,112,49,56,55,55,32,101,108,49,56,55,57,32,105,49,56,56,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li224[] C_aligned={C_lihdr(0,0,25),40,100,111,108,111,111,112,49,56,55,51,32,97,108,49,56,55,53,32,105,49,56,55,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li225[] C_aligned={C_lihdr(0,0,44),40,112,114,111,99,101,115,115,45,101,120,101,99,117,116,101,32,102,105,108,101,110,97,109,101,49,56,54,48,32,46,32,116,109,112,49,56,53,57,49,56,54,49,41,0,0,0,0};
static C_char C_TLS li226[] C_aligned={C_lihdr(0,0,8),40,102,95,55,50,56,54,41};
static C_char C_TLS li227[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,49,57,48,48,32,110,111,104,97,110,103,49,57,48,49,41,0};
static C_char C_TLS li228[] C_aligned={C_lihdr(0,0,19),40,112,97,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0,0};
static C_char C_TLS li229[] C_aligned={C_lihdr(0,0,17),40,115,108,101,101,112,32,97,49,57,49,50,49,57,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li230[] C_aligned={C_lihdr(0,0,33),40,112,114,111,99,101,115,115,45,115,105,103,110,97,108,32,105,100,49,57,49,55,32,46,32,115,105,103,49,57,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li231[] C_aligned={C_lihdr(0,0,21),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,41,0,0,0};
static C_char C_TLS li232[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,45,97,114,103,117,109,101,110,116,115,32,99,109,100,108,105,110,49,57,50,56,41,0,0,0,0,0,0};
static C_char C_TLS li233[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,45,114,117,110,32,102,49,57,51,48,32,46,32,97,114,103,115,49,57,51,49,41,0,0};
static C_char C_TLS li234[] C_aligned={C_lihdr(0,0,33),40,102,95,55,51,57,49,32,108,111,99,49,57,51,57,32,102,100,49,57,52,48,32,115,116,100,102,100,49,57,52,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li235[] C_aligned={C_lihdr(0,0,8),40,102,95,55,52,49,57,41};
static C_char C_TLS li236[] C_aligned={C_lihdr(0,0,30),40,102,95,55,52,50,52,32,95,49,57,53,52,32,102,108,103,49,57,53,53,32,99,111,100,49,57,53,54,41,0,0};
static C_char C_TLS li237[] C_aligned={C_lihdr(0,0,8),40,102,95,55,52,48,53,41};
static C_char C_TLS li238[] C_aligned={C_lihdr(0,0,61),40,102,95,55,52,48,51,32,108,111,99,49,57,52,55,32,112,105,100,49,57,52,56,32,99,108,115,118,101,99,49,57,52,57,32,105,100,120,49,57,53,48,32,105,100,120,97,49,57,53,49,32,105,100,120,98,49,57,53,50,41,0,0,0};
static C_char C_TLS li239[] C_aligned={C_lihdr(0,0,8),40,102,95,55,52,52,53,41};
static C_char C_TLS li240[] C_aligned={C_lihdr(0,0,20),40,102,95,55,52,53,48,32,105,49,57,54,49,32,111,49,57,54,50,41,0,0,0,0};
static C_char C_TLS li241[] C_aligned={C_lihdr(0,0,25),40,102,95,55,52,51,55,32,108,111,99,49,57,53,56,32,112,111,114,116,49,57,53,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li242[] C_aligned={C_lihdr(0,0,41),40,102,95,55,52,53,52,32,108,111,99,49,57,54,51,32,112,105,112,101,49,57,54,52,32,112,111,114,116,49,57,54,53,32,102,100,49,57,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li243[] C_aligned={C_lihdr(0,0,44),40,102,95,55,52,54,51,32,108,111,99,49,57,55,49,32,112,105,112,101,49,57,55,50,32,112,111,114,116,49,57,55,51,32,115,116,100,102,100,49,57,55,52,41,0,0,0,0};
static C_char C_TLS li244[] C_aligned={C_lihdr(0,0,17),40,102,95,55,52,55,53,32,112,105,112,101,49,57,56,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li245[] C_aligned={C_lihdr(0,0,8),40,102,95,55,53,48,54,41};
static C_char C_TLS li246[] C_aligned={C_lihdr(0,0,75),40,115,112,97,119,110,32,108,111,99,49,57,56,52,32,99,109,100,49,57,56,53,32,97,114,103,115,49,57,56,54,32,101,110,118,49,57,56,55,32,115,116,100,111,117,116,102,49,57,56,56,32,115,116,100,105,110,102,49,57,56,57,32,115,116,100,101,114,114,102,49,57,57,48,41,0,0,0,0,0};
static C_char C_TLS li247[] C_aligned={C_lihdr(0,0,73),40,102,95,55,53,50,51,32,108,111,99,49,57,57,55,32,112,105,100,49,57,57,56,32,99,109,100,49,57,57,57,32,112,105,112,101,50,48,48,48,32,115,116,100,102,50,48,48,49,32,115,116,100,102,100,50,48,48,50,32,111,110,45,99,108,111,115,101,50,48,48,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li248[] C_aligned={C_lihdr(0,0,73),40,102,95,55,53,51,51,32,108,111,99,50,48,48,53,32,112,105,100,50,48,48,54,32,99,109,100,50,48,48,55,32,112,105,112,101,50,48,48,56,32,115,116,100,102,50,48,48,57,32,115,116,100,102,100,50,48,49,48,32,111,110,45,99,108,111,115,101,50,48,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li249[] C_aligned={C_lihdr(0,0,8),40,102,95,55,53,52,57,41};
static C_char C_TLS li250[] C_aligned={C_lihdr(0,0,51),40,102,95,55,53,53,52,32,105,110,112,105,112,101,50,48,50,48,32,111,117,116,112,105,112,101,50,48,50,49,32,101,114,114,112,105,112,101,50,48,50,50,32,112,105,100,50,48,50,51,41,0,0,0,0,0};
static C_char C_TLS li251[] C_aligned={C_lihdr(0,0,83),40,35,35,115,121,115,35,112,114,111,99,101,115,115,32,108,111,99,50,48,49,51,32,99,109,100,50,48,49,52,32,97,114,103,115,50,48,49,53,32,101,110,118,50,48,49,54,32,115,116,100,111,117,116,102,50,48,49,55,32,115,116,100,105,110,102,50,48,49,56,32,115,116,100,101,114,114,102,50,48,49,57,41,0,0,0,0,0};
static C_char C_TLS li252[] C_aligned={C_lihdr(0,0,22),40,102,95,55,53,57,52,32,103,50,48,53,49,50,48,53,50,50,48,53,51,41,0,0};
static C_char C_TLS li253[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,108,111,111,112,50,48,51,56,32,103,50,48,52,53,50,48,53,55,41,0,0,0};
static C_char C_TLS li254[] C_aligned={C_lihdr(0,0,16),40,102,95,55,53,57,48,32,108,115,116,50,48,51,53,41};
static C_char C_TLS li255[] C_aligned={C_lihdr(0,0,8),40,102,95,55,54,51,50,41};
static C_char C_TLS li256[] C_aligned={C_lihdr(0,0,56),40,102,95,55,53,56,56,32,108,111,99,50,48,50,56,32,101,114,114,63,50,48,50,57,32,99,109,100,50,48,51,48,32,97,114,103,115,50,48,51,49,32,101,110,118,50,48,51,50,32,107,50,48,51,51,41};
static C_char C_TLS li257[] C_aligned={C_lihdr(0,0,32),40,102,95,55,54,54,54,32,105,50,48,56,51,32,111,50,48,56,52,32,112,50,48,56,53,32,101,50,48,56,54,41};
static C_char C_TLS li258[] C_aligned={C_lihdr(0,0,31),40,112,114,111,99,101,115,115,32,99,109,100,50,48,55,49,32,46,32,116,109,112,50,48,55,48,50,48,55,50,41,0};
static C_char C_TLS li259[] C_aligned={C_lihdr(0,0,32),40,112,114,111,99,101,115,115,42,32,99,109,100,50,48,57,50,32,46,32,116,109,112,50,48,57,49,50,48,57,51,41};
static C_char C_TLS li260[] C_aligned={C_lihdr(0,0,18),40,102,95,55,55,51,52,32,97,50,49,48,55,50,49,49,49,41,0,0,0,0,0,0};
static C_char C_TLS li261[] C_aligned={C_lihdr(0,0,29),40,115,101,116,45,114,111,111,116,45,100,105,114,101,99,116,111,114,121,33,32,100,105,114,50,49,49,51,41,0,0,0};
static C_char C_TLS li262[] C_aligned={C_lihdr(0,0,16),40,102,95,55,55,54,55,32,112,105,100,49,50,55,51,41};
static C_char C_TLS li263[] C_aligned={C_lihdr(0,0,25),40,102,95,55,55,56,50,32,112,105,100,49,50,55,56,32,112,103,105,100,49,50,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li264[] C_aligned={C_lihdr(0,0,8),40,102,95,55,56,48,49,41};
static C_char C_TLS li265[] C_aligned={C_lihdr(0,0,15),40,102,95,55,56,48,52,32,105,100,49,49,48,54,41,0};
static C_char C_TLS li266[] C_aligned={C_lihdr(0,0,8),40,102,95,55,56,49,56,41};
static C_char C_TLS li267[] C_aligned={C_lihdr(0,0,15),40,102,95,55,56,50,49,32,105,100,49,49,48,49,41,0};
static C_char C_TLS li268[] C_aligned={C_lihdr(0,0,8),40,102,95,55,56,51,53,41};
static C_char C_TLS li269[] C_aligned={C_lihdr(0,0,15),40,102,95,55,56,51,56,32,105,100,49,48,57,54,41,0};
static C_char C_TLS li270[] C_aligned={C_lihdr(0,0,8),40,102,95,55,56,53,50,41};
static C_char C_TLS li271[] C_aligned={C_lihdr(0,0,15),40,102,95,55,56,53,53,32,105,100,49,48,57,49,41,0};
static C_char C_TLS li272[] C_aligned={C_lihdr(0,0,16),40,102,95,55,56,54,57,32,112,111,114,116,56,54,54,41};
static C_char C_TLS li273[] C_aligned={C_lihdr(0,0,15),40,102,95,55,57,48,54,32,115,105,103,53,51,55,41,0};
static C_char C_TLS li274[] C_aligned={C_lihdr(0,0,20),40,102,95,55,57,49,52,32,46,32,116,109,112,52,51,49,52,51,50,41,0,0,0,0};
static C_char C_TLS li275[] C_aligned={C_lihdr(0,0,14),40,102,95,55,57,51,52,32,117,109,52,52,49,41,0,0};
static C_char C_TLS li276[] C_aligned={C_lihdr(0,0,13),40,102,95,55,57,51,57,32,102,49,48,56,41,0,0,0};
static C_char C_TLS li277[] C_aligned={C_lihdr(0,0,24),40,102,95,55,57,52,56,32,97,49,49,54,49,50,48,32,97,49,49,53,49,50,49,41};
static C_char C_TLS li278[] C_aligned={C_lihdr(0,0,18),40,102,95,55,57,52,52,32,102,49,49,48,32,116,49,49,49,41,0,0,0,0,0,0};
static C_char C_TLS li279[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k7737 */
static C_word C_fcall stub2108(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2108(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_r=C_fix((C_word)chroot(t0));
return C_r;}

/* from k7314 */
static C_word C_fcall stub1913(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1913(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_sleep(t0));
return C_r;}

/* from parent-process-id in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static C_word C_fcall stub1909(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1909(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getppid());
return C_r;}

/* from f_7131 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static C_word C_fcall stub1853(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1853(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_env();
return C_r;}

/* from k7123 */
static C_word C_fcall stub1846(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1846(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from f_7111 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static C_word C_fcall stub1841(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1841(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k7103 */
static C_word C_fcall stub1834(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1834(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k7081 */
static C_word C_fcall stub1821(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1821(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from f_7051 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static C_word C_fcall stub1808(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1808(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_fork());
return C_r;}

#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1801(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1801(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
if(gethostname(C_hostbuf, 256) == -1) C_return(NULL);else C_return(C_hostbuf);
C_ret:
#undef return

return C_r;}

/* from k7004 */
static C_word C_fcall stub1782(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1782(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int *t1=(int *)C_c_pointer_nn(C_a1);
int *t2=(int *)C_c_pointer_nn(C_a2);
C_r=C_fix((C_word)get_tty_size(t0,t1,t2));
return C_r;}

/* from k6983 */
static C_word C_fcall stub1771(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1771(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)ttyname(t0));
return C_r;}

/* from k6876 */
static C_word C_fcall stub1742(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1742(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_alarm(t0));
return C_r;}

/* from k6857 */
static C_word C_fcall stub1736(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1736(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1730(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1730(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;

#if !defined(__CYGWIN__) && !defined(__SVR4) && !defined(__uClinux__) && !defined(__hpux__)
time_t clock = time(NULL);struct tm *ltm = C_localtime(&clock);char *z = ltm ? (char *)ltm->tm_zone : 0;
#else
char *z = (daylight ? tzname[1] : tzname[0]);
#endif
C_return(z);
C_ret:
#undef return

return C_r;}

/* from f_6800 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static C_word C_fcall stub1706(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1706(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_word t2=(C_word )(C_a2);
C_r=((C_word)C_strptime(t0,t1,t2));
return C_r;}

/* from f_6746 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static C_word C_fcall stub1678(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1678(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from f_6740 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static C_word C_fcall stub1672(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1672(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k6690 */
static C_word C_fcall stub1653(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1653(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
C_r=C_fix((C_word)munmap(t0,t1));
return C_r;}

/* from k6636 */
static C_word C_fcall stub1626(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub1626(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
int t5=(int )C_num_to_int(C_a5);
C_r=C_mpointer_or_false(&C_a,(void*)mmap(t0,t1,t2,t3,t4,t5));
return C_r;}

/* from k6548 */
static C_word C_fcall stub1598(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1598(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k5524 in k5520 */
static C_word C_fcall stub1310(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1310(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
C_r=C_fix((C_word)link(t0,t1));
return C_r;}

/* from k5263 */
static C_word C_fcall stub1193(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1193(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)initgroups(t0,t1));
return C_r;}

#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub1163(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1163(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
if(C_groups != NULL) C_free(C_groups);C_groups = (gid_t *)C_malloc(sizeof(gid_t) * n);if(C_groups == NULL) C_return(0);else C_return(1);
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1158(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1158(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
C_return(getgroups(n, C_groups));
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1130(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1130(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
C_return(C_group->gr_mem[ i ]);
C_ret:
#undef return

return C_r;}

/* from f_7801 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static C_word C_fcall stub1104(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1104(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getegid());
return C_r;}

/* from f_7818 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static C_word C_fcall stub1099(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1099(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getgid());
return C_r;}

/* from f_7835 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static C_word C_fcall stub1094(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1094(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_geteuid());
return C_r;}

/* from f_7852 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static C_word C_fcall stub1089(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1089(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getuid());
return C_r;}

/* from k4100 */
static C_word C_fcall stub731(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub731(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mk_bool(C_test_fd_set(t0,t1));
return C_r;}

/* from k4092 */
static C_word C_fcall stub725(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub725(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_set_fd_set(t0,t1);
return C_r;}

/* from k4084 */
static C_word C_fcall stub720(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub720(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_zero_fd_set(t0);
return C_r;}

/* from k3906 */
static C_word C_fcall stub651(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub651(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
long t2=(long )C_num_to_long(C_a2);
C_r=C_fix((C_word)fcntl(t0,t1,t2));
return C_r;}

#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub607(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub607(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;struct timeval tm;FD_ZERO(&in);FD_SET(fd, &in);tm.tv_sec = tm.tv_usec = 0;if(select(fd + 1, &in, NULL, NULL, &tm) == -1) C_return(-1);else C_return(FD_ISSET(fd, &in) ? 1 : 0);
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub602(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub602(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) C_return(0);C_return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from f_3708 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static C_word C_fcall stub507(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub507(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from f_3702 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static C_word C_fcall stub501(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub501(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k3650 */
static C_word C_fcall stub476(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub476(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k7951 */
static C_word C_fcall stub117(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub117(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_fix((C_word)set_file_mtime(t0,t1));
return C_r;}

/* from k2615 */
static C_word C_fcall stub65(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub65(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(f_4464)
static void C_ccall f_4464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6955)
static void C_fcall f_6955(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4498)
static void C_ccall f_4498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6959)
static void C_ccall f_6959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7131)
static void C_ccall f_7131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7133)
static void C_ccall f_7133(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7133)
static void C_ccall f_7133r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6942)
static void C_ccall f_6942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6944)
static void C_ccall f_6944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4364)
static void C_ccall f_4364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7121)
static void C_ccall f_7121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6938)
static void C_ccall f_6938(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4376)
static void C_ccall f_4376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5332)
static void C_ccall f_5332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6995)
static void C_ccall f_6995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6568)
static void C_fcall f_6568(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6560)
static void C_ccall f_6560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6989)
static void C_ccall f_6989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6985)
static void C_ccall f_6985(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4327)
static void C_fcall f_4327(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6556)
static void C_fcall f_6556(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6550)
static void C_ccall f_6550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6249)
static void C_ccall f_6249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6976)
static void C_ccall f_6976(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4336)
static void C_ccall f_4336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6541)
static void C_ccall f_6541(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6274)
static void C_ccall f_6274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6271)
static void C_ccall f_6271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6539)
static void C_ccall f_6539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6532)
static void C_ccall f_6532(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6530)
static void C_ccall f_6530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4595)
static void C_ccall f_4595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2835)
static void C_ccall f_2835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4354)
static void C_ccall f_4354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4354)
static void C_ccall f_4354r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4358)
static void C_fcall f_4358(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6259)
static void C_fcall f_6259(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4568)
static void C_fcall f_4568(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6593)
static void C_ccall f_6593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6590)
static void C_ccall f_6590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6285)
static void C_fcall f_6285(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6584)
static void C_ccall f_6584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4580)
static void C_ccall f_4580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3108)
static void C_fcall f_3108(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6265)
static void C_ccall f_6265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4315)
static void C_ccall f_4315(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6297)
static void C_ccall f_6297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4541)
static void C_ccall f_4541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4515)
static void C_ccall f_4515(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6527)
static void C_ccall f_6527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5001)
static void C_fcall f_5001(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5509)
static void C_ccall f_5509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5500)
static void C_ccall f_5500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2844)
static void C_ccall f_2844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5018)
static void C_ccall f_5018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5015)
static void C_ccall f_5015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6516)
static void C_ccall f_6516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6518)
static void C_ccall f_6518(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2855)
static void C_ccall f_2855(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2853)
static void C_ccall f_2853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4535)
static void C_ccall f_4535(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_ccall f_2862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5075)
static void C_ccall f_5075(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5075)
static void C_ccall f_5075r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3192)
static void C_fcall f_3192(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2876)
static void C_fcall f_2876(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5040)
static void C_ccall f_5040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5052)
static void C_ccall f_5052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5050)
static void C_ccall f_5050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3172)
static void C_fcall f_3172(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5059)
static void C_ccall f_5059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2817)
static void C_ccall f_2817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_ccall f_5021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5024)
static void C_ccall f_5024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3201)
static void C_ccall f_3201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3151)
static void C_ccall f_3151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3153)
static void C_ccall f_3153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7093)
static void C_ccall f_7093(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5082)
static void C_fcall f_5082(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5096)
static void C_ccall f_5096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5093)
static void C_ccall f_5093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5099)
static void C_ccall f_5099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3231)
static void C_ccall f_3231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5557)
static void C_ccall f_5557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5559)
static void C_ccall f_5559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5559)
static void C_ccall f_5559r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_3186)
static void C_fcall f_3186(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5291)
static void C_ccall f_5291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3182)
static void C_ccall f_3182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5062)
static void C_ccall f_5062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5724)
static void C_ccall f_5724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5722)
static void C_ccall f_5722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5730)
static void C_ccall f_5730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3938)
static void C_ccall f_3938(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3938)
static void C_ccall f_3938r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5715)
static void C_ccall f_5715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3141)
static void C_ccall f_3141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5719)
static void C_ccall f_5719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5717)
static void C_ccall f_5717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3281)
static void C_ccall f_3281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3286)
static void C_ccall f_3286(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3289)
static void C_ccall f_3289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5769)
static void C_ccall f_5769(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5761)
static void C_ccall f_5761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5032)
static void C_ccall f_5032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5764)
static void C_ccall f_5764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5776)
static void C_fcall f_5776(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5778)
static void C_fcall f_5778(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3261)
static void C_ccall f_3261(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3261)
static void C_ccall f_3261r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3267)
static void C_fcall f_3267(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3953)
static void C_ccall f_3953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5749)
static void C_ccall f_5749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5741)
static void C_ccall f_5741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2706)
static void C_ccall f_2706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2702)
static void C_ccall f_2702(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3984)
static void C_ccall f_3984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3984)
static void C_ccall f_3984r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7746)
static void C_ccall f_7746(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5539)
static void C_ccall f_5539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2712)
static void C_ccall f_2712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6415)
static void C_ccall f_6415(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7739)
static void C_ccall f_7739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3908)
static void C_ccall f_3908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3908)
static void C_ccall f_3908r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7734)
static void C_ccall f_7734(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7767)
static void C_ccall f_7767(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5517)
static void C_ccall f_5517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7762)
static void C_ccall f_7762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3487)
static void C_ccall f_3487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5526)
static void C_ccall f_5526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5522)
static void C_ccall f_5522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3968)
static void C_ccall f_3968(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3942)
static void C_fcall f_3942(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5579)
static void C_ccall f_5579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6766)
static void C_ccall f_6766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3466)
static void C_ccall f_3466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7782)
static void C_ccall f_7782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2600)
static void C_ccall f_2600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2602)
static void C_ccall f_2602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5583)
static void C_ccall f_5583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7777)
static void C_ccall f_7777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5587)
static void C_ccall f_5587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5584)
static void C_ccall f_5584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6759)
static void C_ccall f_6759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6752)
static void C_ccall f_6752(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6752)
static void C_ccall f_6752r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3475)
static void C_ccall f_3475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7772)
static void C_ccall f_7772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6446)
static void C_fcall f_6446(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2608)
static void C_ccall f_2608(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6746)
static void C_ccall f_6746(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3443)
static void C_ccall f_3443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2606)
static void C_ccall f_2606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3446)
static void C_ccall f_3446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6740)
static void C_ccall f_6740(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3449)
static void C_ccall f_3449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2621)
static void C_ccall f_2621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2617)
static void C_ccall f_2617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2617)
static void C_ccall f_2617r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6734)
static void C_ccall f_6734(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3457)
static void C_ccall f_3457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7795)
static void C_ccall f_7795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2596)
static void C_ccall f_2596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2627)
static void C_ccall f_2627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3421)
static void C_ccall f_3421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3994)
static void C_ccall f_3994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7403)
static void C_ccall f_7403(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_2637)
static void C_ccall f_2637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2633)
static void C_fcall f_2633(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7405)
static void C_ccall f_7405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3432)
static void C_ccall f_3432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3437)
static void C_ccall f_3437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6483)
static void C_ccall f_6483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6461)
static void C_ccall f_6461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3409)
static void C_ccall f_3409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6476)
static void C_ccall f_6476(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2742)
static void C_ccall f_2742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6775)
static void C_ccall f_6775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3412)
static void C_ccall f_3412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6777)
static void C_ccall f_6777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6464)
static void C_ccall f_6464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4108)
static void C_ccall f_4108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4106)
static void C_fcall f_4106(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4102)
static void C_ccall f_4102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4102)
static void C_ccall f_4102r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7419)
static void C_ccall f_7419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2669)
static void C_ccall f_2669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4115)
static void C_ccall f_4115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2726)
static void C_ccall f_2726(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2726)
static void C_ccall f_2726r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2724)
static void C_ccall f_2724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2720)
static void C_ccall f_2720(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2681)
static void C_ccall f_2681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7424)
static void C_ccall f_7424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2696)
static void C_ccall f_2696(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2694)
static void C_ccall f_2694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7450)
static void C_ccall f_7450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7454)
static void C_ccall f_7454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6725)
static void C_ccall f_6725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7487)
static void C_fcall f_7487(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6713)
static void C_ccall f_6713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7437)
static void C_ccall f_7437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6701)
static void C_fcall f_6701(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4171)
static void C_ccall f_4171(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5397)
static void C_ccall f_5397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4177)
static void C_ccall f_4177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7463)
static void C_ccall f_7463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7462)
static void C_ccall f_7462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4188)
static void C_fcall f_4188(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5271)
static void C_ccall f_5271(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4186)
static void C_ccall f_4186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7493)
static void C_ccall f_7493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6440)
static void C_ccall f_6440(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6440)
static void C_ccall f_6440r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7495)
static void C_ccall f_7495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7491)
static void C_ccall f_7491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4197)
static void C_ccall f_4197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5285)
static void C_ccall f_5285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4120)
static void C_ccall f_4120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4122)
static void C_fcall f_4122(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7475)
static void C_ccall f_7475(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7471)
static void C_ccall f_7471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5390)
static void C_ccall f_5390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4908)
static void C_ccall f_4908(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5915)
static void C_ccall f_5915(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5910)
static void C_ccall f_5910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5213)
static void C_fcall f_5213(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4914)
static void C_ccall f_4914(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5924)
static void C_ccall f_5924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5228)
static void C_ccall f_5228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5208)
static void C_ccall f_5208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7445)
static void C_ccall f_7445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5204)
static void C_ccall f_5204(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5256)
static void C_ccall f_5256(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5261)
static void C_ccall f_5261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4968)
static void C_ccall f_4968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5935)
static void C_ccall f_5935(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6665)
static void C_ccall f_6665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4973)
static void C_ccall f_4973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5943)
static void C_ccall f_5943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4988)
static void C_ccall f_4988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6653)
static void C_ccall f_6653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4984)
static void C_ccall f_4984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6651)
static void C_ccall f_6651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4980)
static void C_ccall f_4980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6649)
static void C_ccall f_6649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6645)
static void C_ccall f_6645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6647)
static void C_fcall f_6647(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6641)
static void C_ccall f_6641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_6641)
static void C_ccall f_6641r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4994)
static void C_ccall f_4994(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4994)
static void C_ccall f_4994r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7533)
static void C_ccall f_7533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_4293)
static void C_ccall f_4293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7549)
static void C_ccall f_7549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7563)
static void C_ccall f_7563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4930)
static void C_ccall f_4930(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7536)
static void C_ccall f_7536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4272)
static void C_ccall f_4272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7554)
static void C_ccall f_7554(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6695)
static void C_ccall f_6695(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6695)
static void C_ccall f_6695r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7569)
static void C_ccall f_7569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7566)
static void C_ccall f_7566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2939)
static void C_ccall f_2939(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2939)
static void C_ccall f_2939r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4284)
static void C_fcall f_4284(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6683)
static void C_ccall f_6683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4956)
static void C_ccall f_4956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4959)
static void C_ccall f_4959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4950)
static void C_ccall f_4950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3002)
static void C_fcall f_3002(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7572)
static void C_ccall f_7572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7575)
static void C_ccall f_7575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7588)
static void C_ccall f_7588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7578)
static void C_ccall f_7578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4231)
static void C_ccall f_4231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4233)
static void C_fcall f_4233(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7590)
static void C_ccall f_7590(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7594)
static void C_ccall f_7594(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4242)
static void C_ccall f_4242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7543)
static void C_ccall f_7543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_4216)
static void C_ccall f_4216(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4222)
static void C_ccall f_4222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2952)
static void C_ccall f_2952(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2950)
static void C_ccall f_2950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5408)
static void C_ccall f_5408(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5400)
static void C_ccall f_5400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5402)
static void C_ccall f_5402(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6617)
static void C_ccall f_6617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3083)
static void C_ccall f_3083(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3082)
static void C_ccall f_3082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7509)
static void C_ccall f_7509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7914)
static void C_ccall f_7914(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7914)
static void C_ccall f_7914r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4033)
static void C_ccall f_4033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7522)
static void C_ccall f_7522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7523)
static void C_ccall f_7523(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_2912)
static void C_fcall f_2912(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7526)
static void C_ccall f_7526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3092)
static void C_ccall f_3092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7906)
static void C_ccall f_7906(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7513)
static void C_ccall f_7513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7511)
static void C_ccall f_7511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7934)
static void C_ccall f_7934(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4094)
static void C_ccall f_4094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7519)
static void C_ccall f_7519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5494)
static void C_ccall f_5494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7939)
static void C_ccall f_7939(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7953)
static void C_ccall f_7953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3059)
static void C_fcall f_3059(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7942)
static void C_ccall f_7942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7944)
static void C_ccall f_7944(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4081)
static void C_ccall f_4081(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4086)
static void C_ccall f_4086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7974)
static void C_ccall f_7974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7948)
static void C_ccall f_7948(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5457)
static void C_ccall f_5457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7501)
static void C_ccall f_7501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7504)
static void C_ccall f_7504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7506)
static void C_ccall f_7506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7962)
static void C_ccall f_7962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5460)
static void C_ccall f_5460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5463)
static void C_ccall f_5463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5466)
static void C_ccall f_5466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5469)
static void C_ccall f_5469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2996)
static void C_ccall f_2996(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2996)
static void C_ccall f_2996r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5611)
static void C_ccall f_5611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5618)
static void C_ccall f_5618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5629)
static void C_ccall f_5629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5679)
static void C_ccall f_5679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4021)
static void C_ccall f_4021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4021)
static void C_ccall f_4021r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5601)
static void C_ccall f_5601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4027)
static void C_ccall f_4027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4029)
static void C_fcall f_4029(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4720)
static void C_ccall f_4720(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4720)
static void C_ccall f_4720r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4723)
static void C_ccall f_4723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4732)
static void C_ccall f_4732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4737)
static void C_ccall f_4737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4869)
static void C_ccall f_4869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4860)
static void C_fcall f_4860(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3847)
static void C_ccall f_3847(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3854)
static void C_ccall f_3854(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4837)
static void C_ccall f_4837(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4842)
static void C_ccall f_4842(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4848)
static void C_ccall f_4848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5649)
static void C_ccall f_5649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5647)
static void C_ccall f_5647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7212)
static void C_ccall f_7212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5436)
static void C_ccall f_5436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5438)
static void C_ccall f_5438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3809)
static void C_ccall f_3809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5414)
static void C_ccall f_5414(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6111)
static void C_ccall f_6111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5424)
static void C_ccall f_5424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4886)
static void C_fcall f_4886(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5420)
static void C_ccall f_5420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6103)
static void C_ccall f_6103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4880)
static void C_ccall f_4880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5429)
static void C_ccall f_5429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5686)
static void C_ccall f_5686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5681)
static void C_ccall f_5681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3493)
static void C_ccall f_3493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5470)
static void C_ccall f_5470(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5470)
static void C_ccall f_5470r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6167)
static void C_ccall f_6167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5480)
static void C_ccall f_5480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6859)
static void C_ccall f_6859(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6859)
static void C_ccall f_6859r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4742)
static void C_ccall f_4742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6854)
static void C_ccall f_6854(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4747)
static void C_ccall f_4747(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4747)
static void C_ccall f_4747r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6158)
static void C_fcall f_6158(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6846)
static void C_ccall f_6846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6841)
static void C_ccall f_6841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4750)
static void C_ccall f_4750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6142)
static void C_ccall f_6142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6143)
static void C_ccall f_6143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6835)
static void C_ccall f_6835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4764)
static void C_ccall f_4764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7317)
static void C_ccall f_7317(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7317)
static void C_ccall f_7317r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4769)
static void C_ccall f_4769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6831)
static void C_ccall f_6831(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7612)
static void C_ccall f_7612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7310)
static void C_ccall f_7310(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6130)
static void C_ccall f_6130(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4774)
static void C_ccall f_4774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4779)
static void C_ccall f_4779(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4779)
static void C_ccall f_4779r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7286)
static void C_ccall f_7286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7603)
static void C_fcall f_7603(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4701)
static void C_ccall f_4701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6896)
static void C_fcall f_6896(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4706)
static void C_ccall f_4706(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4706)
static void C_ccall f_4706r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7270)
static void C_ccall f_7270(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3897)
static void C_ccall f_3897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6885)
static void C_fcall f_6885(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6883)
static void C_ccall f_6883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4710)
static void C_ccall f_4710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6888)
static void C_ccall f_6888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6872)
static void C_ccall f_6872(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6879)
static void C_ccall f_6879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6879)
static void C_ccall f_6879r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7306)
static void C_ccall f_7306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7230)
static void C_ccall f_7230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5114)
static void C_ccall f_5114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7627)
static void C_ccall f_7627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7625)
static void C_ccall f_7625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7321)
static void C_fcall f_7321(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7399)
static void C_ccall f_7399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7695)
static void C_ccall f_7695(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7695)
static void C_ccall f_7695r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7391)
static void C_ccall f_7391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7349)
static void C_ccall f_7349(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6802)
static void C_ccall f_6802(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6802)
static void C_ccall f_6802r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6800)
static void C_ccall f_6800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7340)
static void C_ccall f_7340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6123)
static void C_ccall f_6123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7344)
static void C_ccall f_7344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5105)
static void C_ccall f_5105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6817)
static void C_ccall f_6817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5101)
static void C_fcall f_5101(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4787)
static void C_ccall f_4787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4782)
static void C_ccall f_4782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5153)
static void C_ccall f_5153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5151)
static void C_ccall f_5151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5155)
static void C_ccall f_5155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4796)
static void C_ccall f_4796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4792)
static void C_ccall f_4792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7361)
static void C_ccall f_7361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5160)
static void C_fcall f_5160(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7651)
static void C_ccall f_7651(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7651)
static void C_ccall f_7651r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7649)
static void C_ccall f_7649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7645)
static void C_ccall f_7645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7382)
static void C_ccall f_7382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7379)
static void C_ccall f_7379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7632)
static void C_ccall f_7632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5199)
static void C_ccall f_5199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6820)
static void C_ccall f_6820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5174)
static void C_ccall f_5174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7077)
static void C_ccall f_7077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7078)
static void C_ccall f_7078(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5182)
static void C_ccall f_5182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4632)
static void C_ccall f_4632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4638)
static void C_ccall f_4638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5836)
static void C_ccall f_5836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7666)
static void C_ccall f_7666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7359)
static void C_fcall f_7359(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5819)
static void C_ccall f_5819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7355)
static void C_ccall f_7355(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7355)
static void C_ccall f_7355r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7025)
static void C_ccall f_7025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7029)
static void C_ccall f_7029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3714)
static void C_ccall f_3714(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3714)
static void C_ccall f_3714r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3728)
static void C_ccall f_3728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7010)
static void C_ccall f_7010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5849)
static void C_ccall f_5849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5841)
static void C_fcall f_5841(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5844)
static void C_ccall f_5844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5125)
static void C_ccall f_5125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4656)
static void C_ccall f_4656(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7006)
static void C_ccall f_7006(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5858)
static void C_ccall f_5858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3708)
static void C_ccall f_3708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3643)
static void C_ccall f_3643(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3702)
static void C_ccall f_3702(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6094)
static void C_ccall f_6094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6090)
static void C_fcall f_6090(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3652)
static void C_ccall f_3652(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3652)
static void C_ccall f_3652r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3657)
static void C_ccall f_3657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6081)
static void C_ccall f_6081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3297)
static void C_fcall f_3297(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7053)
static void C_ccall f_7053(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7053)
static void C_ccall f_7053r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7051)
static void C_ccall f_7051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4688)
static void C_ccall f_4688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7057)
static void C_ccall f_7057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6301)
static void C_fcall f_6301(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4684)
static void C_ccall f_4684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4684)
static void C_ccall f_4684r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3762)
static void C_ccall f_3762(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6098)
static void C_ccall f_6098(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6096)
static void C_ccall f_6096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5885)
static void C_ccall f_5885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3627)
static void C_ccall f_3627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3739)
static void C_ccall f_3739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3737)
static void C_ccall f_3737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7863)
static void C_ccall f_7863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7044)
static void C_ccall f_7044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7046)
static void C_ccall f_7046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7869)
static void C_ccall f_7869(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7040)
static void C_ccall f_7040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4619)
static void C_ccall f_4619(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4619)
static void C_ccall f_4619r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7852)
static void C_ccall f_7852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7034)
static void C_ccall f_7034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4662)
static void C_ccall f_4662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7855)
static void C_ccall f_7855(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7032)
static void C_ccall f_7032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4660)
static void C_ccall f_4660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3687)
static void C_ccall f_3687(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3576)
static void C_ccall f_3576(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3691)
static void C_ccall f_3691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4674)
static void C_ccall f_4674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4676)
static void C_ccall f_4676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7846)
static void C_ccall f_7846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4670)
static void C_ccall f_4670(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3697)
static void C_ccall f_3697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3581)
static void C_ccall f_3581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3583)
static void C_fcall f_3583(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3661)
static void C_ccall f_3661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7838)
static void C_ccall f_7838(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7835)
static void C_ccall f_7835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4647)
static void C_ccall f_4647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3778)
static void C_ccall f_3778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3776)
static void C_ccall f_3776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3550)
static void C_ccall f_3550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3555)
static void C_ccall f_3555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3561)
static void C_ccall f_3561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3567)
static void C_ccall f_3567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3564)
static void C_ccall f_3564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3558)
static void C_ccall f_3558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3784)
static void C_ccall f_3784(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3784)
static void C_ccall f_3784r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3536)
static void C_ccall f_3536(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3536)
static void C_ccall f_3536r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3530)
static void C_ccall f_3530(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7883)
static void C_ccall f_7883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6358)
static void C_ccall f_6358(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6358)
static void C_ccall f_6358r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6027)
static void C_fcall f_6027(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6025)
static void C_ccall f_6025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3546)
static void C_ccall f_3546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3540)
static void C_ccall f_3540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7874)
static void C_ccall f_7874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3542)
static void C_ccall f_3542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7872)
static void C_ccall f_7872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3510)
static void C_ccall f_3510(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3548)
static void C_ccall f_3548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4698)
static void C_ccall f_4698(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4698)
static void C_ccall f_4698r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4693)
static void C_ccall f_4693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6009)
static void C_ccall f_6009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6009)
static void C_ccall f_6009r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6362)
static void C_ccall f_6362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6051)
static void C_ccall f_6051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6398)
static void C_ccall f_6398(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6394)
static void C_ccall f_6394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7113)
static void C_ccall f_7113(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7111)
static void C_ccall f_7111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6390)
static void C_ccall f_6390(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6390)
static void C_ccall f_6390r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7101)
static void C_ccall f_7101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7821)
static void C_ccall f_7821(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3507)
static void C_ccall f_3507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7829)
static void C_ccall f_7829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3509)
static void C_ccall f_3509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6378)
static void C_ccall f_6378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3349)
static void C_ccall f_3349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6374)
static void C_ccall f_6374(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6374)
static void C_ccall f_6374r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7812)
static void C_ccall f_7812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7818)
static void C_ccall f_7818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6033)
static void C_ccall f_6033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7801)
static void C_ccall f_7801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7804)
static void C_ccall f_7804(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4408)
static void C_ccall f_4408(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4408)
static void C_ccall f_4408r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7152)
static void C_ccall f_7152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7157)
static void C_fcall f_7157(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3325)
static void C_ccall f_3325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3322)
static void C_ccall f_3322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3371)
static void C_fcall f_3371(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3388)
static void C_ccall f_3388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7170)
static void C_ccall f_7170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7149)
static void C_ccall f_7149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4435)
static void C_fcall f_4435(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7166)
static void C_ccall f_7166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3369)
static void C_ccall f_3369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4442)
static void C_fcall f_4442(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7195)
static void C_fcall f_7195(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4444)
static void C_ccall f_4444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7168)
static void C_ccall f_7168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3361)
static void C_fcall f_3361(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3363)
static void C_fcall f_3363(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6343)
static void C_fcall f_6343(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7182)
static void C_ccall f_7182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7180)
static void C_ccall f_7180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5377)
static void C_ccall f_5377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5380)
static void C_ccall f_5380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5382)
static void C_fcall f_5382(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7188)
static void C_ccall f_7188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4472)
static void C_ccall f_4472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4470)
static void C_ccall f_4470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4477)
static void C_ccall f_4477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5351)
static void C_ccall f_5351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5356)
static void C_ccall f_5356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5354)
static void C_ccall f_5354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4485)
static void C_ccall f_4485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4458)
static void C_ccall f_4458(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_6955)
static void C_fcall trf_6955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6955(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6955(t0,t1,t2);}

C_noret_decl(trf_6568)
static void C_fcall trf_6568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6568(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6568(t0,t1,t2);}

C_noret_decl(trf_4327)
static void C_fcall trf_4327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4327(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4327(t0,t1,t2);}

C_noret_decl(trf_6556)
static void C_fcall trf_6556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6556(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6556(t0,t1,t2);}

C_noret_decl(trf_4358)
static void C_fcall trf_4358(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4358(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4358(t0,t1);}

C_noret_decl(trf_6259)
static void C_fcall trf_6259(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6259(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6259(t0,t1);}

C_noret_decl(trf_4568)
static void C_fcall trf_4568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4568(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4568(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6285)
static void C_fcall trf_6285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6285(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6285(t0,t1,t2,t3);}

C_noret_decl(trf_3108)
static void C_fcall trf_3108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3108(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3108(t0,t1,t2);}

C_noret_decl(trf_5001)
static void C_fcall trf_5001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5001(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5001(t0,t1);}

C_noret_decl(trf_3192)
static void C_fcall trf_3192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3192(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3192(t0,t1);}

C_noret_decl(trf_2876)
static void C_fcall trf_2876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2876(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2876(t0,t1,t2,t3);}

C_noret_decl(trf_3172)
static void C_fcall trf_3172(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3172(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3172(t0,t1);}

C_noret_decl(trf_5082)
static void C_fcall trf_5082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5082(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5082(t0,t1);}

C_noret_decl(trf_3186)
static void C_fcall trf_3186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3186(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3186(t0,t1);}

C_noret_decl(trf_5776)
static void C_fcall trf_5776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5776(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5776(t0,t1);}

C_noret_decl(trf_5778)
static void C_fcall trf_5778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5778(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5778(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3267)
static void C_fcall trf_3267(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3267(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3267(t0,t1,t2);}

C_noret_decl(trf_3942)
static void C_fcall trf_3942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3942(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3942(t0,t1);}

C_noret_decl(trf_6446)
static void C_fcall trf_6446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6446(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6446(t0,t1);}

C_noret_decl(trf_2633)
static void C_fcall trf_2633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2633(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2633(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4106)
static void C_fcall trf_4106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4106(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4106(t0,t1);}

C_noret_decl(trf_7487)
static void C_fcall trf_7487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7487(void *dummy){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
f_7487(t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(trf_6701)
static void C_fcall trf_6701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6701(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6701(t0,t1);}

C_noret_decl(trf_4188)
static void C_fcall trf_4188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4188(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4188(t0,t1,t2);}

C_noret_decl(trf_4122)
static void C_fcall trf_4122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4122(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4122(t0,t1);}

C_noret_decl(trf_5213)
static void C_fcall trf_5213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5213(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5213(t0,t1,t2,t3);}

C_noret_decl(trf_6647)
static void C_fcall trf_6647(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6647(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6647(t0,t1);}

C_noret_decl(trf_4284)
static void C_fcall trf_4284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4284(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4284(t0,t1,t2);}

C_noret_decl(trf_3002)
static void C_fcall trf_3002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3002(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3002(t0,t1);}

C_noret_decl(trf_4233)
static void C_fcall trf_4233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4233(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4233(t0,t1,t2);}

C_noret_decl(trf_2912)
static void C_fcall trf_2912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2912(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2912(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3059)
static void C_fcall trf_3059(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3059(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3059(t0,t1);}

C_noret_decl(trf_4029)
static void C_fcall trf_4029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4029(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4029(t0,t1);}

C_noret_decl(trf_4860)
static void C_fcall trf_4860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4860(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4860(t0,t1,t2);}

C_noret_decl(trf_4886)
static void C_fcall trf_4886(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4886(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4886(t0,t1,t2,t3);}

C_noret_decl(trf_6158)
static void C_fcall trf_6158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6158(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6158(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7603)
static void C_fcall trf_7603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7603(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7603(t0,t1,t2);}

C_noret_decl(trf_6896)
static void C_fcall trf_6896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6896(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6896(t0,t1);}

C_noret_decl(trf_6885)
static void C_fcall trf_6885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6885(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6885(t0,t1);}

C_noret_decl(trf_7321)
static void C_fcall trf_7321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7321(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7321(t0,t1);}

C_noret_decl(trf_5101)
static void C_fcall trf_5101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5101(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5101(t0,t1,t2);}

C_noret_decl(trf_5160)
static void C_fcall trf_5160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5160(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5160(t0,t1,t2);}

C_noret_decl(trf_7359)
static void C_fcall trf_7359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7359(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7359(t0,t1);}

C_noret_decl(trf_5841)
static void C_fcall trf_5841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5841(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5841(t0,t1,t2);}

C_noret_decl(trf_6090)
static void C_fcall trf_6090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6090(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6090(t0,t1);}

C_noret_decl(trf_3297)
static void C_fcall trf_3297(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3297(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3297(t0,t1,t2);}

C_noret_decl(trf_6301)
static void C_fcall trf_6301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6301(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6301(t0,t1);}

C_noret_decl(trf_3583)
static void C_fcall trf_3583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3583(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3583(t0,t1,t2);}

C_noret_decl(trf_6027)
static void C_fcall trf_6027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6027(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6027(t0,t1,t2,t3);}

C_noret_decl(trf_7157)
static void C_fcall trf_7157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7157(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7157(t0,t1,t2,t3);}

C_noret_decl(trf_3371)
static void C_fcall trf_3371(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3371(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3371(t0,t1,t2,t3);}

C_noret_decl(trf_4435)
static void C_fcall trf_4435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4435(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4435(t0,t1,t2);}

C_noret_decl(trf_4442)
static void C_fcall trf_4442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4442(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4442(t0,t1);}

C_noret_decl(trf_7195)
static void C_fcall trf_7195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7195(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7195(t0,t1,t2,t3);}

C_noret_decl(trf_3361)
static void C_fcall trf_3361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3361(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3361(t0,t1);}

C_noret_decl(trf_3363)
static void C_fcall trf_3363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3363(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3363(t0,t1);}

C_noret_decl(trf_6343)
static void C_fcall trf_6343(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6343(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6343(t0,t1,t2,t3);}

C_noret_decl(trf_5382)
static void C_fcall trf_5382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5382(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5382(t0,t1,t2,t3);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr8)
static void C_fcall tr8(C_proc8 k) C_regparm C_noret;
C_regparm static void C_fcall tr8(C_proc8 k){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
(k)(8,t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr7r)
static void C_fcall tr7r(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7r(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n*3);
t7=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* k4463 in k4440 in loop in k4432 in k4422 in k4416 in create-directory in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:774: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4435(t2,((C_word*)t0)[3],t1);}

/* ##sys#terminal-check in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_6955(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6955,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6959,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1717: ##sys#check-open-port */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t4,t3,t2);}

/* k4497 */
static void C_ccall f_4498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mkdir(t1);
t3=C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* posixunix.scm:762: posix-error */
t4=lf[1];
f_2617(6,t4,((C_word*)t0)[2],lf[8],((C_word*)t0)[3],lf[187],((C_word*)t0)[4]);}}

/* k6958 in terminal-check in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(7));
t3=C_eqp(lf[51],t2);
t4=(C_truep(t3)?C_tty_portp(((C_word*)t0)[2]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
/* posixunix.scm:1720: ##sys#error */
t5=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],((C_word*)t0)[4],lf[407],((C_word*)t0)[2]);}}

/* f_7131 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7131,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,stub1853(C_SCHEME_UNDEFINED));}

/* process-execute in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7133(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_7133r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7133r(t0,t1,t2,t3);}}

static void C_ccall f_7133r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(10);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_END_OF_LIST:C_i_car(t3));
t6=C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t8=C_i_nullp(t7);
t9=(C_truep(t8)?C_SCHEME_FALSE:C_i_car(t7));
t10=C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:C_i_cdr(t7));
t12=C_i_check_string_2(t2,lf[419]);
t13=C_i_check_list_2(t5,lf[419]);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7149,a[2]=t9,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=t5,tmp=(C_word)a,a+=10,tmp);
/* posixunix.scm:1780: pathname-strip-directory */
t15=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,t2);}

/* k6941 in terminal-port? in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1713: ##sys#peek-unsigned-integer */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[58]+1)))(4,*((C_word*)lf[58]+1),t2,((C_word*)t0)[3],C_fix(0));}

/* k6943 in k6941 in terminal-port? in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_eqp(C_fix(0),t1);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=C_tty_portp(((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4363 in k4357 in set-file-position! in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4370,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4376,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm:731: port? */
t4=*((C_word*)lf[182]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k7119 */
static void C_ccall f_7121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_foreign_fixnum_argumentp(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,stub1846(C_SCHEME_UNDEFINED,((C_word*)t0)[4],t1,t2));}

/* terminal-port? in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6938(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6938,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6942,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1712: ##sys#check-open-port */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t3,t2,lf[405]);}

/* k4368 in k4363 in k4357 in set-file-position! in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm:738: posix-error */
t2=lf[1];
f_2617(7,t2,((C_word*)t0)[2],lf[8],lf[179],lf[180],((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k4374 in k4363 in k4357 in set-file-position! in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(7));
t3=C_eqp(t2,lf[51]);
if(C_truep(t3)){
t4=C_fseek(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);
t5=((C_word*)t0)[5];
f_4370(2,t5,t4);}
else{
t4=((C_word*)t0)[5];
f_4370(2,t4,C_SCHEME_FALSE);}}
else{
if(C_truep(C_fixnump(((C_word*)t0)[2]))){
t2=C_lseek(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);
t3=((C_word*)t0)[5];
f_4370(2,t3,t2);}
else{
/* posixunix.scm:737: ##sys#signal-hook */
t2=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],lf[13],lf[179],lf[181],((C_word*)t0)[2]);}}}

/* change-file-mode in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5332,4,t0,t1,t2,t3);}
t4=C_i_check_string_2(t2,lf[309]);
t5=C_i_check_exact_2(t3,lf[309]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5351,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5354,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1197: ##sys#expand-home-path */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t7,t2);}

/* f_6995 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6995,5,t0,t1,t2,t3,t4);}
t5=C_i_foreign_fixnum_argumentp(t2);
t6=C_i_foreign_pointer_argumentp(t3);
t7=C_i_foreign_pointer_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,stub1782(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* scan in k6559 in loop in get-environment-variables in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_6568(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6568,NULL,3,t0,t1,t2);}
t3=C_subchar(((C_word*)t0)[2],t2);
if(C_truep(C_i_char_equalp(C_make_character(61),t3))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6590,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm:1580: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),t4,((C_word*)t0)[2],C_fix(0),t2);}
else{
t4=C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm:1583: scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k6559 in loop in get-environment-variables in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6560,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6568,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word)li188),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_6568(t5,((C_word*)t0)[4],C_fix(0));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k6988 in terminal-name in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_C_fileno(((C_word*)t0)[2]);
/* posixunix.scm:1726: ttyname */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[4],t2);}

/* terminal-name in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6985(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6985,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6989,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1725: ##sys#terminal-check */
f_6955(t3,lf[408],t2);}

/* for-each-loop749 in k4109 in k4107 in k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_4327(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4327,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4336,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* posixunix.scm:673: g750 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* loop in get-environment-variables in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_6556(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6556,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6560,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1576: get */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* get-environment-variables in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6550,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6556,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li189),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6556(t5,t1,C_fix(0));}

/* file-truncate in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6249,4,t0,t1,t2,t3);}
t4=C_i_check_number_2(t3,lf[351]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6259,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6265,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_stringp(t2))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6271,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6274,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1481: ##sys#expand-home-path */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t8,t2);}
else{
if(C_truep(C_fixnump(t2))){
t7=C_ftruncate(t2,t3);
t8=t5;
f_6259(t8,C_fixnum_lessp(t7,C_fix(0)));}
else{
/* posixunix.scm:1483: ##sys#error */
t7=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[351],lf[353],t2);}}}

/* f_6976 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6976(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6976,3,t0,t1,t2);}
t3=C_a_i_bytevector(&a,1,C_fix(3));
t4=C_i_foreign_fixnum_argumentp(t2);
t5=stub1771(t3,t4);
/* posixunix.scm:1723: ##sys#peek-nonnull-c-string */
t6=*((C_word*)lf[249]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,C_fix(0));}

/* k4335 in for-each-loop749 in k4109 in k4107 in k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4327(t3,((C_word*)t0)[4],t2);}

/* f_6541 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6541(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6541,3,t0,t1,t2);}
t3=C_a_i_bytevector(&a,1,C_fix(3));
t4=C_i_foreign_fixnum_argumentp(t2);
t5=stub1598(t3,t4);
/* posixunix.scm:1573: ##sys#peek-c-string */
t6=*((C_word*)lf[0]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,C_fix(0));}

/* k6273 in file-truncate in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1481: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],t1,lf[351]);}

/* block-device? in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2828,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2835,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:224: file-type */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k2825 in symbolic-link? in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(lf[24],t1));}

/* k6270 in file-truncate in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_truncate(t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_6259(t3,C_fixnum_lessp(t2,C_fix(0)));}

/* k6538 in unsetenv in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_unsetenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* unsetenv in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6532(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6532,3,t0,t1,t2);}
t3=C_i_check_string_2(t2,lf[369]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6539,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1569: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t4,t2,lf[369]);}

/* k6529 in k6526 in setenv in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_setenv(((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* k4593 in open-input-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:809: check */
f_4568(((C_word*)t0)[3],lf[195],((C_word*)t0)[4],C_SCHEME_TRUE,t1);}

/* character-device? in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2837(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2837,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2844,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:227: file-type */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k2834 in block-device? in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(lf[27],t1));}

/* set-file-position! in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4354r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4354r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4354r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4358,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(t4))){
t6=t4;
t7=t5;
f_4358(t7,C_u_i_car(t6));}
else{
t6=t5;
f_4358(t6,C_fix((C_word)SEEK_SET));}}

/* k4357 in set-file-position! in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_4358(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4358,NULL,2,t0,t1);}
t2=C_i_check_exact_2(((C_word*)t0)[2],lf[179]);
t3=C_i_check_exact_2(t1,lf[179]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4364,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
if(C_truep(C_fixnum_lessp(t5,C_fix(0)))){
/* posixunix.scm:730: ##sys#signal-hook */
t6=*((C_word*)lf[2]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,t4,lf[183],lf[179],lf[184],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t6=t4;
f_4364(2,t6,C_SCHEME_UNDEFINED);}}

/* k6257 in file-truncate in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_6259(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm:1485: posix-error */
t2=lf[1];
f_2617(7,t2,((C_word*)t0)[2],lf[8],lf[351],lf[352],((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* check in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_4568(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4568,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep(C_null_pointerp(t5))){
/* posixunix.scm:801: posix-error */
t6=lf[1];
f_2617(6,t6,t1,lf[8],t2,lf[193],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4580,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:802: ##sys#make-port */
((C_proc6)C_fast_retrieve_proc(*((C_word*)lf[48]+1)))(6,*((C_word*)lf[48]+1),t6,t4,*((C_word*)lf[49]+1),lf[194],lf[51]);}}

/* k6592 in k6589 in scan in k6559 in loop in get-environment-variables in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 in ... */
static void C_ccall f_6593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6593,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6584,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* posixunix.scm:1582: loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_6556(t5,t3,t4);}

/* k6589 in scan in k6559 in loop in get-environment-variables in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6593,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=C_block_size(((C_word*)t0)[6]);
/* posixunix.scm:1581: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),t2,((C_word*)t0)[6],t3,t4);}

/* setup in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_6285(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6285,NULL,4,t1,t2,t3,t4);}
t5=C_i_nullp(t3);
t6=(C_truep(t5)?C_fix(0):C_i_car(t3));
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_TRUE:C_i_car(t8));
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6297,a[2]=t6,a[3]=t4,a[4]=t2,a[5]=t11,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm:1498: ##sys#check-port */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[355]+1)))(4,*((C_word*)lf[355]+1),t14,t2,t4);}

/* k6583 in k6592 in k6589 in scan in k6559 in loop in get-environment-variables in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in ... */
static void C_ccall f_6584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6584,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* open-input-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4582(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_4582r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4582r(t0,t1,t2,t3);}}

static void C_ccall f_4582r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t4=C_i_check_string_2(t2,lf[195]);
t5=C_i_pairp(t3);
t6=(C_truep(t5)?C_slot(t3,C_fix(0)):lf[196]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4595,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=C_eqp(t6,lf[196]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4601,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:813: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t9,t2,lf[195]);}
else{
t9=C_eqp(t6,lf[197]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4610,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:814: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t10,t2,lf[195]);}
else{
/* posixunix.scm:798: ##sys#error */
t10=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,lf[198],t6);}}}

/* k4579 in check in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_file_ptr(t1,((C_word*)t0)[2]);
t3=t1;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* for-each-loop264 in k3081 in k3076 in delete-directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_3108(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3108,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3117,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* posix-common.scm:328: g265 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6264 in file-truncate in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6259(t2,C_fixnum_lessp(t1,C_fix(0)));}

/* f_4315 in k4109 in k4107 in k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4315(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4315,3,t0,t1,t2);}
t3=C_i_check_exact_2(t2,lf[174]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,C_i_fixnum_max(((C_word*)((C_word*)t0)[2])[1],t2));
/* posixunix.scm:677: fd_set */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,C_fix(0),t2);}

/* k3116 in for-each-loop264 in k3081 in k3076 in delete-directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3108(t3,((C_word*)t0)[4],t2);}

/* k6296 in setup in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6297,2,t0,t1);}
t2=C_i_check_number_2(((C_word*)t0)[2],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6301,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=C_eqp(C_SCHEME_TRUE,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[5],0,C_fix(0));
t6=t3;
f_6301(t6,t5);}
else{
t5=t3;
f_6301(t5,C_i_check_number_2(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[3]));}}

/* k4520 in change-directory in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_chdir(t1);
t4=C_eqp(C_fix(0),t3);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}
else{
/* posixunix.scm:784: posix-error */
t5=lf[1];
f_2617(6,t5,t2,lf[8],lf[63],lf[190],((C_word*)t0)[3]);}}

/* k4522 in k4520 in change-directory in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k4540 in change-directory* in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* change-directory in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4515(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4515,3,t0,t1,t2);}
t3=C_i_check_string_2(t2,lf[63]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4521,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4533,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:782: ##sys#expand-home-path */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t5,t2);}

/* k6526 in setenv in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6530,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1564: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t2,((C_word*)t0)[3],lf[368]);}

/* k5000 in user-information in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_5001(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5001,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[2])?*((C_word*)lf[256]+1):*((C_word*)lf[257]+1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5012,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t4=*((C_word*)lf[249]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_user->pw_name),C_fix(0));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5508 in read-symbolic-link in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1268: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],t1,lf[322]);}

/* k5498 in k5493 in k5479 in read-symbolic-link in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm:1275: read-symbolic-link */
t2=*((C_word*)lf[322]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[324]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* k2843 in character-device? in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(lf[26],t1));}

/* f_2846 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2846,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2853,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:230: file-type */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k5017 in k5014 in k5011 in k5000 in user-information in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[0]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_dir),C_fix(0));}

/* k5014 in k5011 in k5000 in user-information in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[249]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_gecos),C_fix(0));}

/* k6515 in fifo? in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1548: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],t1,lf[34]);}

/* k5011 in k5000 in user-information in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[249]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_passwd),C_fix(0));}

/* setenv in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6518(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6518,4,t0,t1,t2,t3);}
t4=C_i_check_string_2(t2,lf[368]);
t5=C_i_check_string_2(t3,lf[368]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6527,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1564: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t6,t2,lf[368]);}

/* socket? in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2855(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2855,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2862,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:233: file-type */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k2852 */
static void C_ccall f_2853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(lf[28],t1));}

/* k3101 in k3081 in k3076 in delete-directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posix-common.scm:339: rmdir */
f_3059(((C_word*)t0)[3],((C_word*)t0)[4]);}

/* change-directory* in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4535(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4535,3,t0,t1,t2);}
t3=C_i_check_exact_2(t2,lf[191]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4541,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=C_fchdir(t2);
t6=C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t2);}
else{
/* posixunix.scm:790: posix-error */
t7=lf[1];
f_2617(6,t7,t4,lf[8],lf[191],lf[192],t2);}}

/* k4532 in change-directory in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:782: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],t1,lf[63]);}

/* k2861 in socket? in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(lf[29],t1));}

/* directory? in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2864,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2871,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:236: file-type */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* group-information in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5075(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_5075r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5075r(t0,t1,t2,t3);}}

static void C_ccall f_5075r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5082,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnump(t2))){
t7=t6;
f_5082(t7,C_getgrgid(t2));}
else{
t7=C_i_check_string_2(t2,lf[260]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5125,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1087: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t8,t2,lf[260]);}}

/* k3190 in k3185 in k3181 in loop in k3157 in k3154 in k3152 in k3150 in k3140 in directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_3192(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3192,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posix-common.scm:367: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3172(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3201,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posix-common.scm:368: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3172(t3,t2);}}

/* mode in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_2876(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2876,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2883,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(t3))){
t6=t3;
t7=C_u_i_car(t6);
t8=C_eqp(t7,lf[40]);
if(C_truep(t8)){
t9=t2;
if(C_truep(t9)){
/* posix-common.scm:255: ##sys#error */
t10=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t5,lf[42],t7);}
else{
/* posix-common.scm:251: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t1,lf[43],t4);}}
else{
/* posix-common.scm:256: ##sys#error */
t9=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t5,lf[44],t7);}}
else{
if(C_truep(t2)){
/* posix-common.scm:251: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t1,lf[45],t4);}
else{
/* posix-common.scm:251: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t1,lf[46],t4);}}}

/* k2870 in directory? in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(lf[25],t1));}

/* current-user-name in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5047,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5050,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1069: current-user-id */
t4=*((C_word*)lf[251]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5046 in current-user-name in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_car(t1));}

/* current-effective-user-name in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5059,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5062,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1072: current-effective-user-id */
t4=*((C_word*)lf[252]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5049 in current-user-name in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1069: user-information */
t2=*((C_word*)lf[255]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* loop in k3157 in k3154 in k3152 in k3150 in k3140 in directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_3172(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3172,NULL,2,t0,t1);}
t2=C_readdir(((C_word*)t0)[2],((C_word*)t0)[3]);
if(C_truep(C_null_pointerp(((C_word*)t0)[3]))){
t3=C_closedir(((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=C_foundfile(((C_word*)t0)[3],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3182,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posix-common.scm:360: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),t4,((C_word*)t0)[4],C_fix(0),t3);}}

/* k5058 in current-effective-user-name in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_car(t1));}

/* symbolic-link? in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2819(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2819,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2826,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:221: file-type */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,C_SCHEME_TRUE,C_SCHEME_FALSE);}

/* k2816 in regular-file? in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(lf[23],t1));}

/* k5020 in k5017 in k5014 in k5011 in k5000 in user-information in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[0]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_shell),C_fix(0));}

/* regular-file? in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2810,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2817,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:218: file-type */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k5023 in k5020 in k5017 in k5014 in k5011 in k5000 in user-information in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1052: g1124 */
t2=((C_word*)t0)[2];
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],C_fix((C_word)C_user->pw_uid),C_fix((C_word)C_user->pw_gid),((C_word*)t0)[6],((C_word*)t0)[7],t1);}

/* k3200 in k3190 in k3185 in k3181 in loop in k3157 in k3154 in k3152 in k3150 in k3140 in directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3201,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k3150 in k3140 in directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3153,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posix-common.scm:346: ##sys#make-pointer */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[75]+1)))(2,*((C_word*)lf[75]+1),t2);}

/* k3152 in k3150 in k3140 in directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3155,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posix-common.scm:347: ##sys#make-pointer */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[75]+1)))(2,*((C_word*)lf[75]+1),t2);}

/* k3154 in k3152 in k3150 in k3140 in directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3231,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:350: ##sys#expand-home-path */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t3,((C_word*)t0)[4]);}

/* f_7093 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7093(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7093,5,t0,t1,t2,t3,t4);}
t5=C_i_foreign_fixnum_argumentp(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7101,a[2]=t4,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t7=C_i_foreign_string_argumentp(t3);
/* posixunix.scm:1772: ##sys#make-c-string */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t6,t7);}
else{
t7=C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,stub1834(C_SCHEME_UNDEFINED,t5,C_SCHEME_FALSE,t7));}}

/* k5081 in group-information in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_5082(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5082,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[2])?*((C_word*)lf[256]+1):*((C_word*)lf[257]+1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5093,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t4=*((C_word*)lf[249]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_group->gr_name),C_fix(0));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3157 in k3154 in k3152 in k3150 in k3140 in directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3158,2,t0,t1);}
t2=C_opendir(t1,((C_word*)t0)[2]);
if(C_truep(C_null_pointerp(((C_word*)t0)[2]))){
/* posix-common.scm:352: posix-error */
t3=lf[1];
f_2617(6,t3,((C_word*)t0)[3],lf[8],lf[25],lf[74],((C_word*)t0)[4]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3172,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=((C_word*)t0)[7],a[7]=((C_word)li28),tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3172(t6,((C_word*)t0)[3]);}}

/* k5095 in k5092 in k5081 in group-information in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5099,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5101,a[2]=t4,a[3]=((C_word)li130),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5101(t6,t2,C_fix(0));}

/* k5092 in k5081 in group-information in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[249]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_passwd),C_fix(0));}

/* directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3137(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3137r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3137r(t0,t1,t2);}}

static void C_ccall f_3137r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3141,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t2))){
/* posix-common.scm:343: current-directory */
t4=*((C_word*)lf[62]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=t3;
f_3141(2,t4,C_i_car(t2));}}

/* k5098 in k5095 in k5092 in k5081 in group-information in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1082: g1150 */
t2=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],C_fix((C_word)C_group->gr_gid),t1);}

/* k3230 in k3154 in k3152 in k3150 in k3140 in directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posix-common.scm:350: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],t1,lf[25]);}

/* k5556 in file-link in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm:1284: posix-error */
t2=lf[1];
f_2617(7,t2,((C_word*)t0)[2],lf[8],lf[327],lf[328],((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##sys#custom-input-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr5r,(void*)f_5559r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5559r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5559r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a=C_alloc(9);
t6=C_i_nullp(t5);
t7=(C_truep(t6)?C_SCHEME_FALSE:C_i_car(t5));
t8=C_i_nullp(t5);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t5));
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_fix(1):C_i_car(t9));
t12=C_i_nullp(t9);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t9));
t14=C_i_nullp(t13);
t15=(C_truep(t14)?*((C_word*)lf[330]+1):C_i_car(t13));
t16=C_i_nullp(t13);
t17=(C_truep(t16)?C_SCHEME_END_OF_LIST:C_i_cdr(t13));
t18=C_i_nullp(t17);
t19=(C_truep(t18)?C_SCHEME_FALSE:C_i_car(t17));
t20=C_i_nullp(t17);
t21=(C_truep(t20)?C_SCHEME_END_OF_LIST:C_i_cdr(t17));
t22=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5579,a[2]=t11,a[3]=t2,a[4]=t4,a[5]=t3,a[6]=t19,a[7]=t1,a[8]=t15,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t7)){
/* posixunix.scm:1289: ##sys#file-nonblocking! */
t23=*((C_word*)lf[122]+1);
((C_proc3)(void*)(*((C_word*)t23+1)))(3,t23,t22,t4);}
else{
t23=t22;
f_5579(2,t23,C_SCHEME_UNDEFINED);}}

/* k3185 in k3181 in loop in k3157 in k3154 in k3152 in k3150 in k3140 in directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_3186(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3186,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_eqp(C_make_character(46),((C_word*)t0)[5]);
if(C_truep(t3)){
t4=C_i_not(t1);
if(C_truep(t4)){
t5=t2;
f_3192(t5,t4);}
else{
t5=C_eqp(C_make_character(46),t1);
if(C_truep(t5)){
t6=C_eqp(C_fix(2),((C_word*)t0)[6]);
t7=t2;
f_3192(t7,(C_truep(t6)?t6:C_i_not(((C_word*)t0)[7])));}
else{
t6=t2;
f_3192(t6,C_i_not(((C_word*)t0)[7]));}}}
else{
t4=t2;
f_3192(t4,C_SCHEME_FALSE);}}

/* k5290 in initialize-groups in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5291,2,t0,t1);}
if(C_truep(C_fixnum_lessp(t1,C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5285,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1144: ##sys#update-errno */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3181 in loop in k3157 in k3154 in k3152 in k3150 in k3140 in directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3182,2,t0,t1);}
t2=C_i_string_ref(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_fixnum_greaterp(((C_word*)t0)[4],C_fix(1)))){
t4=t1;
t5=t3;
f_3186(t5,C_subchar(t4,C_fix(1)));}
else{
t4=t3;
f_3186(t4,C_SCHEME_FALSE);}}

/* k5061 in current-effective-user-name in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1072: user-information */
t2=*((C_word*)lf[255]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5723 in k5721 */
static void C_ccall f_5724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* k5721 */
static void C_ccall f_5722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1344: peek */
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_5730 in k5582 in k5578 in custom-input-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5730,2,t0,t1);}
t2=C_fixnum_lessp(((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm:1351: ready? */
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* file-open in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3938(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3938r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3938r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3938r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3942,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(t4))){
t6=t4;
t7=t5;
f_3942(t7,C_u_i_car(t6));}
else{
t6=t5;
f_3942(t6,((C_word*)t0)[2]);}}

/* k2882 in mode in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posix-common.scm:251: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k5713 in k5582 in k5578 in custom-input-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5715,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5717,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1417: set-port-name! */
t4=*((C_word*)lf[340]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[4]);}

/* k3140 in directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3141,2,t0,t1);}
t2=C_i_nullp(((C_word*)t0)[2]);
t3=(C_truep(t2)?C_SCHEME_END_OF_LIST:C_i_cdr(((C_word*)t0)[2]));
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t8=C_i_check_string_2(t1,lf[25]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3151,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#make-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[66]+1)))(4,*((C_word*)lf[66]+1),t9,C_fix(256),C_make_character(32));}

/* f_5719 in k5582 in k5578 in custom-input-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5722,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1343: fetch */
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5716 in k5713 in k5582 in k5578 in custom-input-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[3])[1]);}

/* f_3281 in conc-loop in glob in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3281,2,t0,t1);}
/* posix-common.scm:379: decompose-pathname */
t2=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* f_3286 in conc-loop in glob in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3286(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3286,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3289,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3349,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t7=t3;
/* posix-common.scm:380: make-pathname */
t8=*((C_word*)lf[78]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}
else{
/* posix-common.scm:380: make-pathname */
t7=*((C_word*)lf[78]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,C_SCHEME_FALSE,lf[83],t4);}}

/* k3288 */
static void C_ccall f_3289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3295,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=((C_word*)t0)[4];
/* posix-common.scm:381: directory */
t4=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_TRUE);}
else{
/* posix-common.scm:381: directory */
t3=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[81],C_SCHEME_TRUE);}}

/* f_5769 in k5582 in k5578 in custom-input-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5769(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5769,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5776,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t7=t6;
f_5776(t7,t3);}
else{
t7=C_block_size(t4);
t8=t6;
f_5776(t8,C_fixnum_difference(t7,t5));}}

/* f_5761 in k5582 in k5578 in custom-input-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5764,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1359: fetch */
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5031 in user-information in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5001(t2,C_getpwnam(t1));}

/* k5763 */
static void C_ccall f_5764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1360: peek */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k5774 */
static void C_fcall f_5776(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5776,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5778,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word)li157),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_5778(t5,((C_word*)t0)[7],t1,C_fix(0),((C_word*)t0)[8]);}

/* loop in k5774 */
static void C_fcall f_5778(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5778,NULL,5,t0,t1,t2,t3,t4);}
t5=C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=t3;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
if(C_truep(C_fixnum_lessp(((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[3])[1]))){
t6=C_fixnum_difference(((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);
t7=C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t8);
t10=C_substring_copy(((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)((C_word*)t0)[2])[1],t9,t4);
t11=C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t13=C_fixnum_difference(t2,t8);
t14=C_fixnum_plus(t3,t8);
t15=C_fixnum_plus(t4,t8);
/* posixunix.scm:1369: loop */
t19=t1;
t20=t13;
t21=t14;
t22=t15;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5819,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm:1371: fetch */
t7=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* glob in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3261(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_3261r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3261r(t0,t1,t2);}}

static void C_ccall f_3261r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3267,a[2]=t4,a[3]=((C_word)li34),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3267(t6,t1,t2);}

/* k3950 in k3941 in file-open in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3951,2,t0,t1);}
t2=C_open(t1,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3953,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm:612: posix-error */
t5=lf[1];
f_2617(8,t5,t3,lf[8],lf[162],lf[163],((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* conc-loop in glob in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_3267(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3267,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3281,a[2]=t3,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3286,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li33),tmp=(C_word)a,a+=5,tmp);
/* posix-common.scm:378: ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}}

/* k3952 in k3950 in k3941 in file-open in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k5748 */
static void C_ccall f_5749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1357: on-close */
t2=((C_word*)t0)[2];
((C_proc2)C_fast_retrieve_proc(t2))(2,t2,((C_word*)t0)[3]);}

/* f_5741 in k5582 in k5578 in custom-input-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5741,2,t0,t1);}
if(C_truep(C_slot(((C_word*)((C_word*)t0)[2])[1],C_fix(8)))){
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5749,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_close(((C_word*)t0)[4]);
if(C_truep(C_fixnum_lessp(t3,C_fix(0)))){
/* posixunix.scm:1356: posix-error */
t4=lf[1];
f_2617(7,t4,t2,lf[8],((C_word*)t0)[5],lf[341],((C_word*)t0)[4],((C_word*)t0)[6]);}
else{
/* posixunix.scm:1357: on-close */
t4=((C_word*)t0)[3];
((C_proc2)C_fast_retrieve_proc(t4))(2,t4,t1);}}}

/* file-owner in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2708(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2708,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2712,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:201: ##sys#stat */
f_2633(t3,t2,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[19]);}

/* k2705 in file-change-time in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2706,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* k2699 in file-access-time in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2700,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-change-time in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2702(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2702,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2706,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:200: ##sys#stat */
f_2633(t3,t2,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[18]);}

/* file-read in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3984r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3984r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3984r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(5);
t5=C_i_check_exact_2(t2,lf[166]);
t6=C_i_check_exact_2(t3,lf[166]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3992,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(t4))){
t8=t4;
t9=t7;
f_3992(2,t9,C_u_i_car(t8));}
else{
t8=t3;
/* ##sys#make-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[66]+1)))(4,*((C_word*)lf[66]+1),t7,t8,C_make_character(32));}}

/* set-root-directory! in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7746(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7746,3,t0,t1,t2);}
t3=C_i_check_string_2(t2,lf[437]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7762,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1983: chroot */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* file-link in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5539,4,t0,t1,t2,t3);}
t4=C_i_check_string_2(t2,lf[326]);
t5=C_i_check_string_2(t3,lf[326]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5557,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1283: link */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,t3);}

/* k2717 in file-permissions in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-permissions in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2714(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2714,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2718,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:202: ##sys#stat */
f_2633(t3,t2,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[20]);}

/* k2711 in file-owner in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-unlock in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6415(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6415,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[354],lf[362]);
t4=C_slot(t2,C_fix(2));
t5=C_slot(t2,C_fix(3));
t6=C_flock_setup(C_fix((C_word)F_UNLCK),t4,t5);
t7=C_slot(t2,C_fix(1));
t8=C_flock_lock(t7);
if(C_truep(C_fixnum_lessp(t8,C_fix(0)))){
/* posixunix.scm:1530: posix-error */
t9=lf[1];
f_2617(6,t9,t1,lf[8],lf[362],lf[363],t2);}
else{
t9=C_SCHEME_UNDEFINED;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* k7737 */
static void C_ccall f_7739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,stub2108(C_SCHEME_UNDEFINED,t1));}

/* file-control in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3908r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3908r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3908r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(5);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_fix(0):C_i_car(t4));
t7=C_i_check_exact_2(t2,lf[160]);
t8=C_i_check_exact_2(t3,lf[160]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3919,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:598: fcntl */
t10=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,t2,t3,t6);}

/* f_7734 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7734(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7734,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7739,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t2)){
t4=C_i_foreign_string_argumentp(t2);
/* posixunix.scm:1980: ##sys#make-c-string */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t3,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub2108(C_SCHEME_UNDEFINED,C_SCHEME_FALSE));}}

/* f_7767 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7767(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7767,3,t0,t1,t2);}
t3=C_i_check_exact_2(t2,lf[318]);
t4=C_getpgid(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7772,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnum_lessp(t4,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7777,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1235: ##sys#update-errno */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t4);}}

/* k3961 in k3941 in file-open in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:610: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],t1,lf[162]);}

/* f_5517 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5517,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5522,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t5=C_i_foreign_string_argumentp(t2);
/* posixunix.scm:1279: ##sys#make-c-string */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t4,t5);}
else{
t5=t4;
f_5522(2,t5,C_SCHEME_FALSE);}}

/* k3918 in file-control in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_eqp(t1,C_fix(-1));
if(C_truep(t2)){
/* posixunix.scm:600: posix-error */
t3=lf[1];
f_2617(7,t3,((C_word*)t0)[2],lf[8],lf[160],lf[161],((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t3=t1;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3480 in k3386 in loop in k3368 in k3362 in k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3481,2,t0,t1);}
if(C_truep((C_truep(C_i_equalp(t1,lf[84]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t1,lf[85]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posix-common.scm:413: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3371(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3475,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* posix-common.scm:414: symbolic-link? */
t3=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}}

/* k7761 in set-root-directory! in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm:1984: posix-error */
t2=lf[1];
f_2617(6,t2,((C_word*)t0)[2],lf[8],lf[437],lf[438],((C_word*)t0)[3]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3485 in k3386 in loop in k3368 in k3362 in k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3487,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3493,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posix-common.scm:422: action */
t3=((C_word*)t0)[5];
((C_proc4)C_fast_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
/* posix-common.scm:423: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3371(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[7]);}}

/* k5524 in k5520 */
static void C_ccall f_5526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,stub1310(C_SCHEME_UNDEFINED,((C_word*)t0)[3],t1));}

/* k5520 */
static void C_ccall f_5522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5522,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5526,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=C_i_foreign_string_argumentp(t2);
/* posixunix.scm:1279: ##sys#make-c-string */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t3,t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub1310(C_SCHEME_UNDEFINED,t1,C_SCHEME_FALSE));}}

/* file-close in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3968(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3968,3,t0,t1,t2);}
t3=C_i_check_exact_2(t2,lf[164]);
t4=C_close(t2);
if(C_truep(C_fixnum_lessp(t4,C_fix(0)))){
/* posixunix.scm:619: posix-error */
t5=lf[1];
f_2617(6,t5,t1,lf[8],lf[164],lf[165],t2);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k3941 in file-open in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_3942(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3942,NULL,2,t0,t1);}
t2=C_i_check_string_2(((C_word*)t0)[2],lf[162]);
t3=C_i_check_exact_2(((C_word*)t0)[3],lf[162]);
t4=C_i_check_exact_2(t1,lf[162]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3951,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3962,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:610: ##sys#expand-home-path */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t6,((C_word*)t0)[2]);}

/* k5578 in custom-input-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5579,2,t0,t1);}
t2=C_fixnump(((C_word*)t0)[2]);
t3=(C_truep(t2)?((C_word*)t0)[2]:C_block_size(((C_word*)t0)[2]));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5583,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_fixnump(((C_word*)t0)[2]))){
/* posixunix.scm:1291: ##sys#make-string */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[66]+1)))(3,*((C_word*)lf[66]+1),t4,((C_word*)t0)[2]);}
else{
t5=t4;
f_5583(2,t5,((C_word*)t0)[2]);}}

/* k6765 in k6758 in time->string in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixunix.scm:1649: ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[111],lf[390],((C_word*)t0)[3]);}}

/* k3465 in k3419 in k3473 in k3480 in k3386 in loop in k3368 in k3362 in k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in ... */
static void C_ccall f_3466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posix-common.scm:421: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3371(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* f_7782 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7782,4,t0,t1,t2,t3);}
t4=C_i_check_exact_2(t2,lf[440]);
t5=C_i_check_exact_2(t3,lf[440]);
t6=C_setpgid(t2,t3);
if(C_truep(C_fixnum_lessp(t6,C_fix(0)))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7795,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1242: ##sys#update-errno */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t7);}
else{
t7=C_SCHEME_UNDEFINED;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k3467 in k3419 in k3473 in k3480 in k3386 in loop in k3368 in k3362 in k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in ... */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posix-common.scm:421: action */
t2=((C_word*)t0)[2];
((C_proc4)C_fast_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[5];
/* posix-common.scm:421: loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3371(t3,((C_word*)t0)[7],((C_word*)t0)[8],t2);}}

/* k2599 in k2597 in k2595 */
static void C_ccall f_2600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2602,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2604,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k5582 in k5578 in custom-input-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[79],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5583,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5584,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li149),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5611,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=((C_word)li150),tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5618,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[6],a[10]=((C_word)li152),tmp=(C_word)a,a+=11,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5715,a[2]=t10,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5719,a[2]=t5,a[3]=t7,a[4]=t8,a[5]=((C_word)li153),tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5730,a[2]=t5,a[3]=t3,a[4]=t6,a[5]=((C_word)li154),tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5741,a[2]=t10,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[4],a[7]=((C_word)li155),tmp=(C_word)a,a+=8,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5761,a[2]=t7,a[3]=t8,a[4]=((C_word)li156),tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5769,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=t8,a[6]=((C_word)li158),tmp=(C_word)a,a+=7,tmp);
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5836,a[2]=t5,a[3]=t3,a[4]=t8,a[5]=t1,a[6]=((C_word)li163),tmp=(C_word)a,a+=7,tmp);
t18=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5935,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=((C_word)li164),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm:1341: make-input-port */
t19=*((C_word*)lf[346]+1);
((C_proc9)(void*)(*((C_word*)t19+1)))(9,t19,t11,t12,t13,t14,t15,t16,t17,t18);}

/* k7776 */
static void C_ccall f_7777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1236: ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[318],lf[439],((C_word*)t0)[3]);}

/* k5586 */
static void C_ccall f_5587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5587,2,t0,t1);}
t2=C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_5601(2,t5,t3);}
else{
/* posixunix.scm:1299: rx= */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[332]+1)))(4,*((C_word*)lf[332]+1),t4,C_fix((C_word)errno),C_fix((C_word)EAGAIN));}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_eqp(C_fix(1),t1));}}

/* f_5584 in k5582 in k5578 in custom-input-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5587,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm:1296: ##sys#file-select-one */
t3=*((C_word*)lf[123]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6758 in time->string in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6759,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=C_i_check_string_2(((C_word*)t0)[2],lf[111]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6766,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6775,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1648: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t4,((C_word*)t0)[2],lf[111]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6777,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1650: asctime */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}}

/* time->string in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6752(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6752r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6752r(t0,t1,t2,t3);}}

static void C_ccall f_6752r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6759,a[2]=t5,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm:1644: check-time-vector */
f_3583(t6,lf[111],t2);}

/* k3473 in k3480 in k3386 in loop in k3368 in k3362 in k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3475,2,t0,t1);}
t2=(C_truep(t1)?C_i_not(((C_word*)t0)[2]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3409,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3412,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* posix-common.scm:415: pproc */
t5=((C_word*)t0)[9];
((C_proc3)C_fast_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[7]);}
else{
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3421,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* posix-common.scm:416: lproc */
t4=((C_word*)t0)[11];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[7]);}}

/* k7771 */
static void C_ccall f_7772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k6445 in create-fifo in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_6446(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6446,NULL,2,t0,t1);}
t2=C_i_check_exact_2(t1,lf[364]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6461,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6464,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1540: ##sys#expand-home-path */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t4,((C_word*)t0)[3]);}

/* f_2608 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2608(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2608,3,t0,t1,t2);}
t3=C_a_i_bytevector(&a,1,C_fix(3));
t4=C_i_foreign_fixnum_argumentp(t2);
t5=stub65(t3,t4);
/* posix-common.scm:116: ##sys#peek-c-string */
t6=*((C_word*)lf[0]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,C_fix(0));}

/* k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2606,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* f_6746 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6746(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6746,4,t0,t1,t2,t3);}
t4=C_a_i_bytevector(&a,1,C_fix(3));
t5=stub1678(t4,t2,t3);
/* posixunix.scm:1642: ##sys#peek-c-string */
t6=*((C_word*)lf[0]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,C_fix(0));}

/* k3442 */
static void C_ccall f_3443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3449,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* posix-common.scm:420: pproc */
t4=((C_word*)t0)[7];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}

/* k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2608,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp);
t3=C_mutate(&lf[1] /* (set! posix-error ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2617,a[2]=t2,a[3]=((C_word)li1),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[6]+1 /* (set! ##sys#posix-error ...) */,lf[1]);
t5=C_mutate(&lf[7] /* (set! ##sys#stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2633,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[15]+1 /* (set! file-stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2674,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2694,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7939,a[2]=((C_word)li276),tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7944,a[2]=((C_word)li278),tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:186: getter-with-setter */
t10=*((C_word*)lf[442]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,t8,t9,lf[461]);}

/* k3445 in k3442 */
static void C_ccall f_3446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posix-common.scm:419: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3371(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* f_6740 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6740(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6740,3,t0,t1,t2);}
t3=C_a_i_bytevector(&a,1,C_fix(3));
t4=stub1672(t3,t2);
/* posixunix.scm:1641: ##sys#peek-c-string */
t5=*((C_word*)lf[0]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,C_fix(0));}

/* k3447 in k3442 */
static void C_ccall f_3449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posix-common.scm:420: action */
t2=((C_word*)t0)[2];
((C_proc4)C_fast_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[5];
/* posix-common.scm:419: loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3371(t3,((C_word*)t0)[7],((C_word*)t0)[8],t2);}}

/* k2620 in posix-error in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2630,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* posix-common.scm:120: strerror */
t4=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* posix-error in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_2617r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2617r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2617r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2621,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t5,a[6]=t4,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* posix-common.scm:119: ##sys#update-errno */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t6);}

/* memory-mapped-file? in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6734(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6734,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[381]));}

/* f_3457 in k3419 in k3473 in k3480 in k3386 in loop in k3368 in k3362 in k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in ... */
static void C_ccall f_3457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3457,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[4])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k3454 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posix-common.scm:419: glob */
t2=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2597 in k2595 */
static void C_ccall f_2598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2600,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k7794 */
static void C_ccall f_7795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1243: ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[440],lf[441],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k2595 */
static void C_ccall f_2596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2598,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_irregex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2629 in k2620 in posix-error in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posix-common.scm:120: string-append */
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[4],t1);}

/* k2626 in k2620 in posix-error in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[2],*((C_word*)lf[2]+1),((C_word*)t0)[3],((C_word*)t0)[4],t1,((C_word*)t0)[5]);}

/* k3419 in k3473 in k3480 in k3386 in loop in k3368 in k3362 in k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 in ... */
static void C_ccall f_3421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3421,2,t0,t1);}
if(C_truep(t1)){
t2=C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3430,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3432,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word)li36),tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3437,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word)li37),tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3457,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word)li38),tmp=(C_word)a,a+=6,tmp);
/* posix-common.scm:418: ##sys#dynamic-wind */
t10=*((C_word*)lf[87]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3466,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3469,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* posix-common.scm:421: pproc */
t4=((C_word*)t0)[9];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[7]);}}

/* k3993 in k3991 in file-read in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3994,2,t0,t1);}
t2=C_read(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3996,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm:630: posix-error */
t5=lf[1];
f_2617(7,t5,t3,lf[8],lf[166],lf[167],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list2(&a,2,((C_word*)t0)[3],t2));}}

/* k3991 in file-read in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3994,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_blockp(t1))){
if(C_truep(C_byteblockp(t1))){
t3=t2;
f_3994(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm:627: ##sys#signal-hook */
t3=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[13],lf[166],lf[168],t1);}}
else{
/* posixunix.scm:627: ##sys#signal-hook */
t3=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[13],lf[166],lf[168],t1);}}

/* f_7403 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7403(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word ab[9],*a=ab;
if(c!=8) C_bad_argc_2(c,8,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr8,(void*)f_7403,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7405,a[2]=t4,a[3]=t5,a[4]=t6,a[5]=t7,a[6]=t3,a[7]=t2,a[8]=((C_word)li237),tmp=(C_word)a,a+=9,tmp));}

/* k2636 in stat in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_fixnum_lessp(t1,C_fix(0)))){
if(C_truep(((C_word*)t0)[2])){
/* posix-common.scm:173: posix-error */
t2=lf[1];
f_2617(6,t2,((C_word*)t0)[3],lf[8],((C_word*)t0)[4],lf[9],((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}}

/* ##sys#stat in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_2633(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2633,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2637,a[2]=t4,a[3]=t1,a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnump(t2))){
t7=t6;
f_2637(2,t7,C_fstat(t2));}
else{
if(C_truep(C_i_stringp(t2))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2660,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2666,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2669,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:163: ##sys#expand-home-path */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t9,t2);}
else{
/* posix-common.scm:169: ##sys#signal-hook */
t7=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,lf[13],t5,lf[14],t2);}}}

/* f_7405 */
static void C_ccall f_7405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7405,2,t0,t1);}
t2=C_i_vector_set(((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_TRUE);
t3=C_i_vector_ref(((C_word*)t0)[2],((C_word*)t0)[4]);
t4=(C_truep(t3)?C_i_vector_ref(((C_word*)t0)[2],((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7419,a[2]=((C_word*)t0)[6],a[3]=((C_word)li235),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7424,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word)li236),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1882: ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k3428 in k3419 in k3473 in k3480 in k3386 in loop in k3368 in k3362 in k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in ... */
static void C_ccall f_3430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posix-common.scm:417: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3371(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* f_3432 in k3419 in k3473 in k3480 in k3386 in loop in k3368 in k3362 in k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in ... */
static void C_ccall f_3432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3432,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[4])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* f_3437 in k3419 in k3473 in k3480 in k3386 in loop in k3368 in k3362 in k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in ... */
static void C_ccall f_3437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3443,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3455,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:419: make-pathname */
t4=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[86]);}

/* k6482 in fifo? in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_fifo_p(t1);
switch(t2){
case C_SCHEME_TRUE:
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);
case C_SCHEME_FALSE:
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);
case C_fix(0):
/* posixunix.scm:1551: ##sys#signal-hook */
t3=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],lf[8],lf[34],lf[366],((C_word*)t0)[3]);
default:
/* posixunix.scm:1553: posix-error */
t3=lf[1];
f_2617(6,t3,((C_word*)t0)[2],lf[8],lf[34],lf[367],((C_word*)t0)[3]);}}

/* k6460 in k6445 in create-fifo in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mkfifo(t1,((C_word*)t0)[2]);
if(C_truep(C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm:1541: posix-error */
t3=lf[1];
f_2617(7,t3,((C_word*)t0)[3],lf[8],lf[364],lf[365],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3995 in k3993 in k3991 in file-read in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3996,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list2(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]));}

/* k2659 in stat in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2637(2,t2,(C_truep(((C_word*)t0)[3])?C_lstat(t1):C_stat(t1)));}

/* k3408 in k3473 in k3480 in k3386 in loop in k3368 in k3362 in k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 in ... */
static void C_ccall f_3409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posix-common.scm:415: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3371(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* fifo? in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6476(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6476,3,t0,t1,t2);}
t3=C_i_check_string_2(t2,lf[34]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6483,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6516,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1548: ##sys#expand-home-path */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t5,t2);}

/* k2740 in file-type in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_stat_type);
if(C_truep(C_i_eqvp(t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)S_IFREG)))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[23]);}
else{
if(C_truep(C_i_eqvp(t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)S_IFLNK)))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[24]);}
else{
if(C_truep(C_i_eqvp(t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)S_IFDIR)))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[25]);}
else{
if(C_truep(C_i_eqvp(t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)S_IFCHR)))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[26]);}
else{
if(C_truep(C_i_eqvp(t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)S_IFBLK)))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[27]);}
else{
if(C_truep(C_i_eqvp(t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)S_IFIFO)))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[28]);}
else{
t3=C_i_eqvp(t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)S_IFSOCK));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?lf[29]:lf[23]));}}}}}}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6774 in k6758 in time->string in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1648: strftime */
t2=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k3410 in k3473 in k3480 in k3386 in loop in k3368 in k3362 in k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 in ... */
static void C_ccall f_3412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posix-common.scm:415: action */
t2=((C_word*)t0)[2];
((C_proc4)C_fast_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[5];
/* posix-common.scm:415: loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3371(t3,((C_word*)t0)[7],((C_word*)t0)[8],t2);}}

/* k6776 in k6758 in time->string in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_block_size(t1);
t3=C_fixnum_difference(t2,C_fix(1));
/* posixunix.scm:1652: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),((C_word*)t0)[2],t1,C_fix(0),t3);}
else{
/* posixunix.scm:1653: ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[111],lf[391],((C_word*)t0)[3]);}}

/* k6463 in k6445 in create-fifo in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1540: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],t1,lf[364]);}

/* k4107 in k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm:666: fd_zero */
t3=((C_word*)t0)[9];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(1));}

/* k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_4106(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4106,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* posixunix.scm:665: fd_zero */
t3=((C_word*)t0)[8];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(0));}

/* file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4r,(void*)f_4102r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4102r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4102r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(11);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4106,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t6,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_pairp(t4))){
t8=t4;
t9=t7;
f_4106(t9,C_u_i_car(t8));}
else{
t8=t7;
f_4106(t8,C_SCHEME_FALSE);}}

/* f_7419 */
static void C_ccall f_7419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7419,2,t0,t1);}
/* posixunix.scm:1882: process-wait */
t2=*((C_word*)lf[118]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k2668 in stat in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posix-common.scm:162: ##sys#platform-fixup-pathname */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[11]+1)))(3,*((C_word*)lf[11]+1),((C_word*)t0)[2],t1);}

/* k2665 in stat in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posix-common.scm:161: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k4113 in k4109 in k4107 in k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4115,2,t0,t1);}
t2=C_i_not(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4120,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_4120(2,t4,t2);}
else{
if(C_truep(C_fixnump(((C_word*)t0)[2]))){
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[2]);
/* posixunix.scm:682: fd_set */
t5=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_fix(1),((C_word*)t0)[2]);}
else{
t4=C_i_check_list_2(((C_word*)t0)[2],lf[174]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4272,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word)li82),tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[2];
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4284,a[2]=t8,a[3]=t5,a[4]=((C_word)li83),tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_4284(t10,t3,t6);}}}

/* k4109 in k4107 in k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4110,2,t0,t1);}
t2=C_i_not(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4115,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=t3;
f_4115(2,t4,t2);}
else{
if(C_truep(C_fixnump(((C_word*)t0)[2]))){
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[2]);
/* posixunix.scm:670: fd_set */
t5=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_fix(0),((C_word*)t0)[2]);}
else{
t4=C_i_check_list_2(((C_word*)t0)[2],lf[174]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4315,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word)li84),tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[2];
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4327,a[2]=t8,a[3]=t5,a[4]=((C_word)li85),tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_4327(t10,t3,t6);}}}

/* file-type in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2726(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_2726r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2726r(t0,t1,t2,t3);}}

static void C_ccall f_2726r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(3);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t8=C_i_nullp(t7);
t9=(C_truep(t8)?C_SCHEME_TRUE:C_i_car(t7));
t10=C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:C_i_cdr(t7));
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2742,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:206: ##sys#stat */
f_2633(t12,t2,t5,t9,lf[22]);}

/* k2723 in file-size in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2724,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_double_to_num(&a,C_statbuf.st_size));}

/* file-stat in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_2674r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2674r(t0,t1,t2,t3);}}

static void C_ccall f_2674r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(3);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2681,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:178: ##sys#stat */
f_2633(t6,t2,t5,C_SCHEME_TRUE,lf[15]);}

/* file-size in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2720(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2720,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2724,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:203: ##sys#stat */
f_2633(t3,t2,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[21]);}

/* k2680 in file-stat in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2681,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_a_double_to_num(&a,C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_dev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_rdev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blksize),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blocks)));}

/* f_7424 */
static void C_ccall f_7424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7424,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
/* posixunix.scm:1884: ##sys#signal-hook */
t5=*((C_word*)lf[2]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[120],((C_word*)t0)[2],lf[432],((C_word*)t0)[3],t4);}}

/* file-access-time in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2696(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2696,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2700,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:199: ##sys#stat */
f_2633(t3,t2,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);}

/* k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[89],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2694,2,t0,t1);}
t2=C_mutate((C_word*)lf[16]+1 /* (set! file-modification-time ...) */,t1);
t3=C_mutate((C_word*)lf[17]+1 /* (set! file-access-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2696,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[18]+1 /* (set! file-change-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2702,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[19]+1 /* (set! file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2708,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[20]+1 /* (set! file-permissions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2714,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[21]+1 /* (set! file-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2720,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[22]+1 /* (set! file-type ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2726,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[30]+1 /* (set! regular-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2810,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[31]+1 /* (set! symbolic-link? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2819,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[32]+1 /* (set! block-device? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2828,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[33]+1 /* (set! character-device? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2837,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[34]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2846,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[35]+1 /* (set! socket? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2855,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[36]+1 /* (set! directory? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2864,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[37]+1 /* (set! fileno/stdin ...) */,C_fix((C_word)STDIN_FILENO));
t17=C_mutate((C_word*)lf[38]+1 /* (set! fileno/stdout ...) */,C_fix((C_word)STDOUT_FILENO));
t18=C_mutate((C_word*)lf[39]+1 /* (set! fileno/stderr ...) */,C_fix((C_word)STDERR_FILENO));
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2876,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t24=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2912,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[52]+1 /* (set! open-input-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2926,a[2]=t22,a[3]=t20,a[4]=((C_word)li19),tmp=(C_word)a,a+=5,tmp));
t26=C_mutate((C_word*)lf[53]+1 /* (set! open-output-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2939,a[2]=t22,a[3]=t20,a[4]=((C_word)li20),tmp=(C_word)a,a+=5,tmp));
t27=C_mutate((C_word*)lf[54]+1 /* (set! port->fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2952,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[60]+1 /* (set! duplicate-fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2996,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[62]+1 /* (set! current-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3019,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[67]+1 /* (set! delete-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3052,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[25]+1 /* (set! directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3137,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[76]+1 /* (set! glob ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3261,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[71]+1 /* (set! find-files ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3536,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3581,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7914,a[2]=((C_word)li274),tmp=(C_word)a,a+=3,tmp);
t36=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7934,a[2]=((C_word)li275),tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:437: getter-with-setter */
t37=*((C_word*)lf[442]+1);
((C_proc5)(void*)(*((C_word*)t37+1)))(5,t37,t34,t35,t36,lf[458]);}

/* f_7450 */
static void C_ccall f_7450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7450,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t2,t3));}

/* f_7454 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[4],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7454,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(t4)){
t6=C_i_car(t3);
t7=t3;
t8=C_u_i_cdr(t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7462,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1894: file-close */
t10=*((C_word*)lf[164]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t8);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* memory-mapped-file-pointer in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6725,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[381],lf[388]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(1)));}

/* spawn in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_7487(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7487,NULL,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7491,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t5,a[6]=((C_word*)t0)[2],a[7]=t2,a[8]=t8,a[9]=((C_word*)t0)[3],a[10]=t6,a[11]=t7,a[12]=((C_word*)t0)[4],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm:1909: needed-pipe */
t10=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t2,t7);}

/* k6712 in k6700 in unmap-file-from-memory in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_eqp(C_fix(0),t1);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* posixunix.scm:1629: posix-error */
t3=lf[1];
f_2617(7,t3,((C_word*)t0)[2],lf[8],lf[386],lf[387],((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k4160 in k4157 in k4121 in k4118 in k4113 in k4109 in k4107 in k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:699: values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* f_7437 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7437,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7445,a[2]=((C_word)li239),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7450,a[2]=((C_word)li240),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1887: ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k6700 in unmap-file-from-memory in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_6701(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6701,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm:1628: munmap */
t4=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* f_4171 in k4157 in k4121 in k4118 in k4113 in k4109 in k4107 in k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4171(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4171,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4177,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:710: fd_test */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(1),t2);}

/* k5396 in check in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5397,2,t0,t1);}
t2=C_test_access(t1,((C_word*)t0)[2]);
t3=C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5390,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
/* posixunix.scm:1216: ##sys#update-errno */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t4);}}

/* k4175 */
static void C_ccall f_4177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4177,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* f_7463 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7463,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(t4)){
t6=C_i_car(t3);
t7=t3;
t8=C_u_i_cdr(t7);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7471,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=t6,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm:1900: file-close */
t10=*((C_word*)lf[164]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t8);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k7461 */
static void C_ccall f_7462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* for-each-loop829 in k4157 in k4121 in k4118 in k4113 in k4109 in k4107 in k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_4188(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4188,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4197,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* posixunix.scm:709: g830 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* initialize-groups in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5271(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5271,4,t0,t1,t2,t3);}
t4=C_i_check_string_2(t2,lf[268]);
t5=C_i_check_exact_2(t3,lf[268]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5291,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1143: init */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,t3);}

/* k4184 in k4157 in k4121 in k4118 in k4113 in k4109 in k4107 in k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[2])[1];
/* posixunix.scm:699: values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[4],t2);}

/* k7492 in k7490 in spawn in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm:1911: needed-pipe */
t3=((C_word*)t0)[13];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[8],((C_word*)t0)[9]);}

/* create-fifo in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6440(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_6440r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6440r(t0,t1,t2,t3);}}

static void C_ccall f_6440r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=C_i_check_string_2(t2,lf[364]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6446,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(t3))){
t6=t3;
t7=t5;
f_6446(t7,C_u_i_car(t6));}
else{
t6=C_fixnum_or(C_fix((C_word)S_IRWXG),C_fix((C_word)S_IRWXO));
t7=t5;
f_6446(t7,C_fixnum_or(C_fix((C_word)S_IRWXU),t6));}}

/* k7494 in k7492 in k7490 in spawn in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm:1913: swapped-ends */
t3=((C_word*)t0)[10];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[12]);}

/* k7490 in spawn in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7493,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm:1910: needed-pipe */
t3=((C_word*)t0)[12];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[7],((C_word*)t0)[10]);}

/* k4196 in for-each-loop829 in k4157 in k4121 in k4118 in k4113 in k4109 in k4107 in k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4188(t3,((C_word*)t0)[4],t2);}

/* k5284 in k5290 in initialize-groups in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1145: ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[268],lf[269],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k4118 in k4113 in k4109 in k4107 in k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=C_i_check_number_2(((C_word*)t0)[6],lf[174]);
t4=C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],C_fix(1));
t5=t2;
f_4122(t5,C_C_select_t(t4,((C_word*)t0)[6]));}
else{
t3=C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],C_fix(1));
t4=t2;
f_4122(t4,C_C_select(t3));}}

/* k4121 in k4118 in k4113 in k4109 in k4107 in k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_4122(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4122,NULL,2,t0,t1);}
if(C_truep(C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm:696: posix-error */
t2=lf[1];
f_2617(7,t2,((C_word*)t0)[2],lf[8],lf[174],lf[175],((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=C_i_pairp(((C_word*)t0)[3]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
/* posixunix.scm:697: values */
C_values(4,0,((C_word*)t0)[2],t4,C_SCHEME_END_OF_LIST);}
else{
/* posixunix.scm:697: values */
C_values(4,0,((C_word*)t0)[2],t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(C_fixnump(((C_word*)t0)[3]))){
/* posixunix.scm:702: fd_test */
t4=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(0),((C_word*)t0)[3]);}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4216,a[2]=t5,a[3]=((C_word*)t0)[5],a[4]=((C_word)li80),tmp=(C_word)a,a+=5,tmp);
t7=((C_word*)t0)[3];
t8=C_i_check_list_2(t7,lf[70]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4231,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4233,a[2]=t11,a[3]=t6,a[4]=((C_word)li81),tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_4233(t13,t9,t7);}}
else{
t4=t3;
f_4158(2,t4,C_SCHEME_FALSE);}}}}

/* f_7475 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7475(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7475,3,t0,t1,t2);}
if(C_truep(t2)){
t3=C_i_cdr(t2);
t4=t2;
t5=C_u_i_car(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,t3,t5));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7470 */
static void C_ccall f_7471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1901: replace-fd */
t2=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k5389 in k5396 in check in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k4157 in k4121 in k4118 in k4113 in k4109 in k4107 in k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4161,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(C_fixnump(((C_word*)t0)[3]))){
/* posixunix.scm:708: fd_test */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(1),((C_word*)t0)[3]);}
else{
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4171,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word)li78),tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[3];
t7=C_i_check_list_2(t6,lf[70]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4186,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4188,a[2]=t10,a[3]=t5,a[4]=((C_word)li79),tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_4188(t12,t8,t6);}}
else{
/* posixunix.scm:699: values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}}

/* signal-masked? in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4908(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4908,3,t0,t1,t2);}
t3=C_i_check_exact_2(t2,lf[243]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_sigismember(t2));}

/* f_5915 in loop */
static void C_ccall f_5915(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5915,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* posixunix.scm:1403: loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5841(t4,t1,t2);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* f_5910 in loop */
static void C_ccall f_5910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5910,2,t0,t1);}
/* posixunix.scm:1401: ##sys#scan-buffer-line */
((C_proc6)C_fast_retrieve_proc(*((C_word*)lf[344]+1)))(6,*((C_word*)lf[344]+1),t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}

/* doloop1179 in k5207 in set-groups! in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_5213(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5213,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_set_groups(t3);
if(C_truep(C_fixnum_lessp(t4,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5228,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1132: ##sys#update-errno */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t5);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=C_slot(t2,C_fix(0));
t5=C_i_check_exact_2(t4,lf[265]);
t6=C_set_gid(t3,t4);
t7=C_slot(t2,C_fix(1));
t8=C_fixnum_plus(t3,C_fix(1));
t12=t1;
t13=t7;
t14=t8;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* signal-mask! in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4914(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4914,3,t0,t1,t2);}
t3=C_i_check_exact_2(t2,lf[244]);
t4=C_sigaddset(t2);
t5=C_sigprocmask_block(C_fix(0));
if(C_truep(C_fixnum_lessp(t5,C_fix(0)))){
/* posixunix.scm:977: posix-error */
t6=lf[1];
f_2617(5,t6,t1,lf[120],lf[244],lf[245]);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k5923 in loop */
static void C_ccall f_5924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_fixnum_lessp(((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[3])[1]))){
/* posixunix.scm:1408: loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5841(t2,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* k5227 in doloop1179 in k5207 in set-groups! in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1133: ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[265],lf[266],((C_word*)t0)[3]);}

/* k5207 in set-groups! in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5208,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5213,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li134),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5213(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* f_7445 */
static void C_ccall f_7445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7445,2,t0,t1);}
/* posixunix.scm:1889: create-pipe */
t2=*((C_word*)lf[212]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* set-groups! in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5204(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5204,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5208,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=C_i_length(t2);
t5=C_i_foreign_fixnum_argumentp(t4);
if(C_truep(stub1163(C_SCHEME_UNDEFINED,t5))){
t6=t3;
f_5208(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm:1127: ##sys#error */
t6=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[265],lf[267]);}}

/* f_5256 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5256(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5256,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5261,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t5=C_i_foreign_string_argumentp(t2);
/* posixunix.scm:1139: ##sys#make-c-string */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t4,t5);}
else{
t5=C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,stub1193(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t5));}}

/* k5259 */
static void C_ccall f_5261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_foreign_fixnum_argumentp(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,stub1193(C_SCHEME_UNDEFINED,t1,t2));}

/* k4964 in k4961 in k4958 in k4955 in k4949 in system-information in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[249]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.machine),C_fix(0));}

/* k4961 in k4958 in k4955 in k4949 in system-information in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[249]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.version),C_fix(0));}

/* k4967 in k4964 in k4961 in k4958 in k4955 in k4949 in system-information in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4968,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list5(&a,5,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t1));}

/* f_5935 in k5582 in k5578 in custom-input-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5935(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5935,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[3])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[345]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5943,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1413: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[3])[1]);}}

/* k6664 in k6650 in k6648 in k6646 in k6644 in map-file-to-memory in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 in ... */
static void C_ccall f_6665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6665,2,t0,t1);}
t2=C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm:1620: posix-error */
t3=lf[1];
f_2617(11,t3,((C_word*)t0)[2],lf[8],lf[380],lf[382],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8]);}
else{
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record3(&a,3,lf[381],((C_word*)t0)[10],((C_word*)t0)[4]));}}

/* k4972 in system-information in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:999: ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[248],lf[250]);}

/* k5942 */
static void C_ccall f_5943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4988,2,t0,t1);}
t2=C_mutate((C_word*)lf[253]+1 /* (set! current-group-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4992,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7801,a[2]=((C_word)li264),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7804,a[2]=((C_word)li265),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1035: getter-with-setter */
t6=*((C_word*)lf[442]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,t4,t5,lf[446]);}

/* k6652 in k6650 in k6648 in k6646 in k6644 in map-file-to-memory in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 in ... */
static void C_ccall f_6653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6653,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_record3(&a,3,lf[381],((C_word*)t0)[3],((C_word*)t0)[4]));}

/* k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4984,2,t0,t1);}
t2=C_mutate((C_word*)lf[252]+1 /* (set! current-effective-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4988,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7818,a[2]=((C_word)li266),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7821,a[2]=((C_word)li267),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1026: getter-with-setter */
t6=*((C_word*)lf[442]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,t4,t5,lf[449]);}

/* k6650 in k6648 in k6646 in k6644 in map-file-to-memory in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6653,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6665,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[2],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm:1619: ##sys#pointer->address */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[383]+1)))(3,*((C_word*)lf[383]+1),t3,t1);}

/* k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4980,2,t0,t1);}
t2=C_mutate((C_word*)lf[251]+1 /* (set! current-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4984,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7835,a[2]=((C_word)li268),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7838,a[2]=((C_word)li269),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1016: getter-with-setter */
t6=*((C_word*)lf[442]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,t4,t5,lf[452]);}

/* k6648 in k6646 in k6644 in map-file-to-memory in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm:1618: mmap */
t3=((C_word*)t0)[9];
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8]);}

/* k6644 in map-file-to-memory in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[8]))){
t3=((C_word*)t0)[8];
t4=t2;
f_6647(t4,C_u_i_car(t3));}
else{
t3=t2;
f_6647(t3,C_fix(0));}}

/* k6646 in k6644 in map-file-to-memory in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_6647(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6647,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_blockp(((C_word*)t0)[4]))){
if(C_truep(C_specialp(((C_word*)t0)[4]))){
t3=t2;
f_6649(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm:1617: ##sys#signal-hook */
t3=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[13],lf[380],lf[384],((C_word*)t0)[4]);}}
else{
/* posixunix.scm:1617: ##sys#signal-hook */
t3=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[13],lf[380],lf[384],((C_word*)t0)[4]);}}

/* map-file-to-memory in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(c<7) C_bad_min_argc_2(c,7,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr7r,(void*)f_6641r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest(a,C_rest_count(0));
f_6641r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_6641r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(9);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6645,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=((C_word*)t0)[2],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t9=t2;
if(C_truep(t9)){
t10=t8;
f_6645(2,t10,t2);}
else{
/* posixunix.scm:1614: ##sys#null-pointer */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[385]+1)))(2,*((C_word*)lf[385]+1),t8);}}

/* k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4992,2,t0,t1);}
t2=C_mutate((C_word*)lf[254]+1 /* (set! current-effective-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[255]+1 /* (set! user-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4994,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[258]+1 /* (set! current-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5040,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[259]+1 /* (set! current-effective-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5052,a[2]=((C_word)li129),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[260]+1 /* (set! group-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5075,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[261]+1 /* (set! get-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5147,a[2]=((C_word)li133),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[265]+1 /* (set! set-groups! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5204,a[2]=((C_word)li135),tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5256,a[2]=((C_word)li136),tmp=(C_word)a,a+=3,tmp);
t10=C_mutate((C_word*)lf[268]+1 /* (set! initialize-groups ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5271,a[2]=t9,a[3]=((C_word)li137),tmp=(C_word)a,a+=4,tmp));
t11=C_mutate((C_word*)lf[270]+1 /* (set! errno/perm ...) */,C_fix((C_word)EPERM));
t12=C_mutate((C_word*)lf[271]+1 /* (set! errno/noent ...) */,C_fix((C_word)ENOENT));
t13=C_mutate((C_word*)lf[272]+1 /* (set! errno/srch ...) */,C_fix((C_word)ESRCH));
t14=C_mutate((C_word*)lf[273]+1 /* (set! errno/intr ...) */,C_fix((C_word)EINTR));
t15=C_mutate((C_word*)lf[274]+1 /* (set! errno/io ...) */,C_fix((C_word)EIO));
t16=C_mutate((C_word*)lf[275]+1 /* (set! errno/noexec ...) */,C_fix((C_word)ENOEXEC));
t17=C_mutate((C_word*)lf[276]+1 /* (set! errno/badf ...) */,C_fix((C_word)EBADF));
t18=C_mutate((C_word*)lf[277]+1 /* (set! errno/child ...) */,C_fix((C_word)ECHILD));
t19=C_mutate((C_word*)lf[278]+1 /* (set! errno/nomem ...) */,C_fix((C_word)ENOMEM));
t20=C_mutate((C_word*)lf[279]+1 /* (set! errno/acces ...) */,C_fix((C_word)EACCES));
t21=C_mutate((C_word*)lf[280]+1 /* (set! errno/fault ...) */,C_fix((C_word)EFAULT));
t22=C_mutate((C_word*)lf[281]+1 /* (set! errno/busy ...) */,C_fix((C_word)EBUSY));
t23=C_mutate((C_word*)lf[282]+1 /* (set! errno/notdir ...) */,C_fix((C_word)ENOTDIR));
t24=C_mutate((C_word*)lf[283]+1 /* (set! errno/isdir ...) */,C_fix((C_word)EISDIR));
t25=C_mutate((C_word*)lf[284]+1 /* (set! errno/inval ...) */,C_fix((C_word)EINVAL));
t26=C_mutate((C_word*)lf[285]+1 /* (set! errno/mfile ...) */,C_fix((C_word)EMFILE));
t27=C_mutate((C_word*)lf[286]+1 /* (set! errno/nospc ...) */,C_fix((C_word)ENOSPC));
t28=C_mutate((C_word*)lf[287]+1 /* (set! errno/spipe ...) */,C_fix((C_word)ESPIPE));
t29=C_mutate((C_word*)lf[288]+1 /* (set! errno/pipe ...) */,C_fix((C_word)EPIPE));
t30=C_mutate((C_word*)lf[289]+1 /* (set! errno/again ...) */,C_fix((C_word)EAGAIN));
t31=C_mutate((C_word*)lf[290]+1 /* (set! errno/rofs ...) */,C_fix((C_word)EROFS));
t32=C_mutate((C_word*)lf[291]+1 /* (set! errno/exist ...) */,C_fix((C_word)EEXIST));
t33=C_mutate((C_word*)lf[292]+1 /* (set! errno/wouldblock ...) */,C_fix((C_word)EWOULDBLOCK));
t34=C_set_block_item(lf[293] /* errno/2big */,0,C_fix(0));
t35=C_set_block_item(lf[294] /* errno/deadlk */,0,C_fix(0));
t36=C_set_block_item(lf[295] /* errno/dom */,0,C_fix(0));
t37=C_set_block_item(lf[296] /* errno/fbig */,0,C_fix(0));
t38=C_set_block_item(lf[297] /* errno/ilseq */,0,C_fix(0));
t39=C_set_block_item(lf[298] /* errno/mlink */,0,C_fix(0));
t40=C_set_block_item(lf[299] /* errno/nametoolong */,0,C_fix(0));
t41=C_set_block_item(lf[300] /* errno/nfile */,0,C_fix(0));
t42=C_set_block_item(lf[301] /* errno/nodev */,0,C_fix(0));
t43=C_set_block_item(lf[302] /* errno/nolck */,0,C_fix(0));
t44=C_set_block_item(lf[303] /* errno/nosys */,0,C_fix(0));
t45=C_set_block_item(lf[304] /* errno/notempty */,0,C_fix(0));
t46=C_set_block_item(lf[305] /* errno/notty */,0,C_fix(0));
t47=C_set_block_item(lf[306] /* errno/nxio */,0,C_fix(0));
t48=C_set_block_item(lf[307] /* errno/range */,0,C_fix(0));
t49=C_set_block_item(lf[308] /* errno/xdev */,0,C_fix(0));
t50=C_mutate((C_word*)lf[309]+1 /* (set! change-file-mode ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5332,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[311]+1 /* (set! change-file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5356,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5382,a[2]=((C_word)li140),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[313]+1 /* (set! file-read-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5402,a[2]=t52,a[3]=((C_word)li141),tmp=(C_word)a,a+=4,tmp));
t54=C_mutate((C_word*)lf[314]+1 /* (set! file-write-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5408,a[2]=t52,a[3]=((C_word)li142),tmp=(C_word)a,a+=4,tmp));
t55=C_mutate((C_word*)lf[315]+1 /* (set! file-execute-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5414,a[2]=t52,a[3]=((C_word)li143),tmp=(C_word)a,a+=4,tmp));
t56=C_mutate((C_word*)lf[316]+1 /* (set! create-session ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5420,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp));
t57=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5436,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t58=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7767,a[2]=((C_word)li262),tmp=(C_word)a,a+=3,tmp);
t59=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7782,a[2]=((C_word)li263),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1230: getter-with-setter */
t60=*((C_word*)lf[442]+1);
((C_proc5)(void*)(*((C_word*)t60+1)))(5,t60,t57,t58,t59,lf[443]);}

/* user-information in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4994(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_4994r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4994r(t0,t1,t2,t3);}}

static void C_ccall f_4994r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5001,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnump(t2))){
t7=t6;
f_5001(t7,C_getpwuid(t2));}
else{
t7=C_i_check_string_2(t2,lf[255]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5032,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1057: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t8,t2,lf[255]);}}

/* f_7533 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_7533,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7536,a[2]=t1,a[3]=t2,a[4]=t4,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm:1926: connect-parent */
t10=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t9,t2,t5,t6,t7);}

/* k4292 in for-each-loop777 in k4113 in k4109 in k4107 in k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4284(t3,((C_word*)t0)[4],t2);}

/* f_7549 in process in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7549,2,t0,t1);}
/* posixunix.scm:1930: spawn */
t2=((C_word*)t0)[2];
f_7487(t2,t1,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],((C_word*)t0)[9]);}

/* k7562 */
static void C_ccall f_7563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7566,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7575,a[2]=((C_word*)t0)[11],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm:1939: make-on-close */
t4=((C_word*)t0)[9];
((C_proc8)(void*)(*((C_word*)t4+1)))(8,t4,t3,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[10],C_fix(1),C_fix(0),C_fix(2));}

/* signal-unmask! in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4930(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4930,3,t0,t1,t2);}
t3=C_i_check_exact_2(t2,lf[246]);
t4=C_sigdelset(t2);
t5=C_sigprocmask_unblock(C_fix(0));
if(C_truep(C_fixnum_lessp(t5,C_fix(0)))){
/* posixunix.scm:983: posix-error */
t6=lf[1];
f_2617(5,t6,t1,lf[120],lf[246],lf[247]);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k7535 */
static void C_ccall f_7536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm:1927: ##sys#custom-output-port */
t2=*((C_word*)lf[347]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1,C_SCHEME_TRUE,C_fix(0),((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2923 in check in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_file_ptr(t1,((C_word*)t0)[2]);
t3=t1;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* open-input-file* in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2926(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2926r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2926r(t0,t1,t2,t3);}}

static void C_ccall f_2926r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=C_i_check_exact_2(t2,lf[52]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2937,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posix-common.scm:269: mode */
f_2876(t5,C_SCHEME_TRUE,t3,lf[52]);}

/* f_4272 in k4113 in k4109 in k4107 in k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4272,3,t0,t1,t2);}
t3=C_i_check_exact_2(t2,lf[174]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,C_i_fixnum_max(((C_word*)((C_word*)t0)[2])[1],t2));
/* posixunix.scm:689: fd_set */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,C_fix(1),t2);}

/* f_7554 in process in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7554(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7554,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_not(((C_word*)t0)[2]);
t7=C_i_not(((C_word*)t0)[3]);
t8=C_i_not(((C_word*)t0)[4]);
t9=C_a_i_vector3(&a,3,t6,t7,t8);
t10=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7563,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t4,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[8],a[10]=t9,a[11]=((C_word*)t0)[9],a[12]=t3,a[13]=((C_word*)t0)[3],tmp=(C_word)a,a+=14,tmp);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7578,a[2]=((C_word*)t0)[5],a[3]=t10,a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm:1937: make-on-close */
t12=((C_word*)t0)[8];
((C_proc8)(void*)(*((C_word*)t12+1)))(8,t12,t11,((C_word*)t0)[6],t5,t9,C_fix(0),C_fix(1),C_fix(2));}

/* unmap-file-from-memory in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6695(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6695r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6695r(t0,t1,t2,t3);}}

static void C_ccall f_6695r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=C_i_check_structure_2(t2,lf[381],lf[386]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6701,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(t3))){
t6=t3;
t7=t5;
f_6701(t7,C_u_i_car(t6));}
else{
t6=t5;
f_6701(t6,C_slot(t2,C_fix(2)));}}

/* k7568 in k7565 in k7562 */
static void C_ccall f_7569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1935: values */
C_values(6,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* system-information in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4950,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fixnum_lessp(C_fix((C_word)C_uname),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4973,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:998: ##sys#update-errno */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t3);}
else{
t3=t2;
f_4950(2,t3,C_SCHEME_UNDEFINED);}}

/* k7565 in k7562 */
static void C_ccall f_7566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7569,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7572,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm:1942: make-on-close */
t4=((C_word*)t0)[10];
((C_proc8)(void*)(*((C_word*)t4+1)))(8,t4,t3,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[11],C_fix(2),C_fix(0),C_fix(1));}

/* k2936 in open-input-file* in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2937,2,t0,t1);}
t2=C_fdopen(&a,2,((C_word*)t0)[2],t1);
/* posix-common.scm:269: check */
f_2912(((C_word*)t0)[4],lf[52],((C_word*)t0)[2],C_SCHEME_TRUE,t2);}

/* open-output-file* in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2939(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2939r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2939r(t0,t1,t2,t3);}}

static void C_ccall f_2939r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=C_i_check_exact_2(t2,lf[53]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2950,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posix-common.scm:273: mode */
f_2876(t5,C_SCHEME_FALSE,t3,lf[53]);}

/* for-each-loop777 in k4113 in k4109 in k4107 in k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_4284(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4284,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4293,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* posixunix.scm:685: g778 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f_6683 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6683,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=C_i_foreign_pointer_argumentp(t2);
t5=C_i_foreign_integer_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,stub1653(C_SCHEME_UNDEFINED,t4,t5));}
else{
t4=C_i_foreign_integer_argumentp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,stub1653(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t4));}}

/* k4955 in k4949 in system-information in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4959,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[249]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.nodename),C_fix(0));}

/* k4958 in k4955 in k4949 in system-information in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[249]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.release),C_fix(0));}

/* k4949 in system-information in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4956,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[249]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.sysname),C_fix(0));}

/* k3001 in duplicate-fileno in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_3002(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3002,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3004,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnum_lessp(t1,C_fix(0)))){
/* posix-common.scm:300: posix-error */
t3=lf[1];
f_2617(6,t3,t2,lf[8],lf[60],lf[61],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k3003 in k3001 in duplicate-fileno in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k7571 in k7565 in k7562 */
static void C_ccall f_7572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1941: input-port */
t2=((C_word*)t0)[2];
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],*((C_word*)lf[39]+1),t1);}

/* k7574 in k7562 */
static void C_ccall f_7575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1938: output-port */
t2=((C_word*)t0)[2];
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],*((C_word*)lf[38]+1),t1);}

/* f_7588 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[23],*a=ab;
if(c!=8) C_bad_argc_2(c,8,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr8,(void*)f_7588,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7590,a[2]=t2,a[3]=((C_word)li254),tmp=(C_word)a,a+=4,tmp);
t11=C_i_check_string_2(((C_word*)t8)[1],t2);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7625,a[2]=t2,a[3]=t8,a[4]=t9,a[5]=t6,a[6]=t3,a[7]=t1,a[8]=t7,a[9]=t10,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t9)[1])){
/* posixunix.scm:1957: chkstrlst */
t13=t10;
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t9)[1]);}
else{
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7645,a[2]=t9,a[3]=t8,a[4]=t12,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1959: ##sys#shell-command-arguments */
t14=*((C_word*)lf[429]+1);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,((C_word*)t8)[1]);}}

/* current-directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3019(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3019r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3019r(t0,t1,t2);}}

static void C_ccall f_3019r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:C_i_car(t2));
if(C_truep(t4)){
/* posix-common.scm:308: change-directory */
t5=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3032,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#make-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[66]+1)))(4,*((C_word*)lf[66]+1),t5,C_fix(1024),C_make_character(32));}}

/* k7577 */
static void C_ccall f_7578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1936: input-port */
t2=((C_word*)t0)[2];
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],*((C_word*)lf[37]+1),t1);}

/* k4229 in k4121 in k4118 in k4113 in k4109 in k4107 in k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[2])[1];
t3=((C_word*)t0)[3];
f_4158(2,t3,t2);}

/* for-each-loop808 in k4121 in k4118 in k4113 in k4109 in k4107 in k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_4233(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4233,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4242,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* posixunix.scm:703: g809 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f_7590 */
static void C_ccall f_7590(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7590,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7594,a[2]=((C_word*)t0)[2],a[3]=((C_word)li252),tmp=(C_word)a,a+=4,tmp);
t5=t2;
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7603,a[2]=t7,a[3]=t4,a[4]=((C_word)li253),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_7603(t9,t1,t5);}

/* f_7594 */
static void C_ccall f_7594(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7594,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3374)){
C_save(t1);
C_rereclaim2(3374*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,462);
lf[0]=C_h_intern(&lf[0],17,"\003syspeek-c-string");
lf[2]=C_h_intern(&lf[2],15,"\003syssignal-hook");
lf[3]=C_h_intern(&lf[3],13,"string-append");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[5]=C_h_intern(&lf[5],16,"\003sysupdate-errno");
lf[6]=C_h_intern(&lf[6],15,"\003sysposix-error");
lf[8]=C_h_intern(&lf[8],11,"\000file-error");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[10]=C_h_intern(&lf[10],17,"\003sysmake-c-string");
lf[11]=C_h_intern(&lf[11],27,"\003sysplatform-fixup-pathname");
lf[12]=C_h_intern(&lf[12],20,"\003sysexpand-home-path");
lf[13]=C_h_intern(&lf[13],11,"\000type-error");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\052bad argument type - not a fixnum or string");
lf[15]=C_h_intern(&lf[15],9,"file-stat");
lf[16]=C_h_intern(&lf[16],22,"file-modification-time");
lf[17]=C_h_intern(&lf[17],16,"file-access-time");
lf[18]=C_h_intern(&lf[18],16,"file-change-time");
lf[19]=C_h_intern(&lf[19],10,"file-owner");
lf[20]=C_h_intern(&lf[20],16,"file-permissions");
lf[21]=C_h_intern(&lf[21],9,"file-size");
lf[22]=C_h_intern(&lf[22],9,"file-type");
lf[23]=C_h_intern(&lf[23],12,"regular-file");
lf[24]=C_h_intern(&lf[24],13,"symbolic-link");
lf[25]=C_h_intern(&lf[25],9,"directory");
lf[26]=C_h_intern(&lf[26],16,"character-device");
lf[27]=C_h_intern(&lf[27],12,"block-device");
lf[28]=C_h_intern(&lf[28],4,"fifo");
lf[29]=C_h_intern(&lf[29],6,"socket");
lf[30]=C_h_intern(&lf[30],13,"regular-file\077");
lf[31]=C_h_intern(&lf[31],14,"symbolic-link\077");
lf[32]=C_h_intern(&lf[32],13,"block-device\077");
lf[33]=C_h_intern(&lf[33],17,"character-device\077");
lf[34]=C_h_intern(&lf[34],5,"fifo\077");
lf[35]=C_h_intern(&lf[35],7,"socket\077");
lf[36]=C_h_intern(&lf[36],10,"directory\077");
lf[37]=C_h_intern(&lf[37],12,"fileno/stdin");
lf[38]=C_h_intern(&lf[38],13,"fileno/stdout");
lf[39]=C_h_intern(&lf[39],13,"fileno/stderr");
lf[40]=C_h_intern(&lf[40],7,"\000append");
lf[41]=C_h_intern(&lf[41],9,"\003syserror");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[48]=C_h_intern(&lf[48],13,"\003sysmake-port");
lf[49]=C_h_intern(&lf[49],21,"\003sysstream-port-class");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[51]=C_h_intern(&lf[51],6,"stream");
lf[52]=C_h_intern(&lf[52],16,"open-input-file\052");
lf[53]=C_h_intern(&lf[53],17,"open-output-file\052");
lf[54]=C_h_intern(&lf[54],12,"port->fileno");
lf[55]=C_h_intern(&lf[55],13,"\003sysport-data");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[58]=C_h_intern(&lf[58],25,"\003syspeek-unsigned-integer");
lf[59]=C_h_intern(&lf[59],19,"\003syscheck-open-port");
lf[60]=C_h_intern(&lf[60],16,"duplicate-fileno");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file-descriptor");
lf[62]=C_h_intern(&lf[62],17,"current-directory");
lf[63]=C_h_intern(&lf[63],16,"change-directory");
lf[64]=C_h_intern(&lf[64],13,"\003syssubstring");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[66]=C_h_intern(&lf[66],15,"\003sysmake-string");
lf[67]=C_h_intern(&lf[67],16,"delete-directory");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[69]=C_h_intern(&lf[69],11,"delete-file");
lf[70]=C_h_intern(&lf[70],8,"for-each");
lf[71]=C_h_intern(&lf[71],10,"find-files");
lf[72]=C_h_intern(&lf[72],9,"\000dotfiles");
lf[73]=C_h_intern(&lf[73],16,"\000follow-symlinks");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[75]=C_h_intern(&lf[75],16,"\003sysmake-pointer");
lf[76]=C_h_intern(&lf[76],4,"glob");
lf[77]=C_h_intern(&lf[77],18,"decompose-pathname");
lf[78]=C_h_intern(&lf[78],13,"make-pathname");
lf[79]=C_h_intern(&lf[79],23,"irregex-match-substring");
lf[80]=C_h_intern(&lf[80],13,"irregex-match");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[82]=C_h_intern(&lf[82],16,"\003sysglob->regexp");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\001\052");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\001\052");
lf[87]=C_h_intern(&lf[87],16,"\003sysdynamic-wind");
lf[88]=C_h_intern(&lf[88],13,"pathname-file");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\002\077\052");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\001\052");
lf[91]=C_h_intern(&lf[91],7,"irregex");
lf[92]=C_h_intern(&lf[92],8,"irregex\077");
lf[93]=C_h_intern(&lf[93],15,"\003sysget-keyword");
lf[94]=C_h_intern(&lf[94],6,"\000limit");
lf[95]=C_h_intern(&lf[95],5,"\000seed");
lf[96]=C_h_intern(&lf[96],7,"\000action");
lf[97]=C_h_intern(&lf[97],5,"\000test");
lf[98]=C_h_intern(&lf[98],18,"file-creation-mode");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[101]=C_h_intern(&lf[101],19,"seconds->local-time");
lf[102]=C_h_intern(&lf[102],18,"\003sysdecode-seconds");
lf[103]=C_h_intern(&lf[103],15,"current-seconds");
lf[104]=C_h_intern(&lf[104],17,"seconds->utc-time");
lf[105]=C_h_intern(&lf[105],15,"seconds->string");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[107]=C_h_intern(&lf[107],19,"local-time->seconds");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[109]=C_h_intern(&lf[109],3,"fp=");
lf[110]=C_decode_literal(C_heaptop,"\376U-1.0\000");
lf[111]=C_h_intern(&lf[111],12,"time->string");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[114]=C_h_intern(&lf[114],19,"set-signal-handler!");
lf[115]=C_h_intern(&lf[115],17,"\003syssignal-vector");
lf[116]=C_h_intern(&lf[116],14,"signal-handler");
lf[117]=C_h_intern(&lf[117],18,"current-process-id");
lf[118]=C_h_intern(&lf[118],12,"process-wait");
lf[119]=C_h_intern(&lf[119],16,"\003sysprocess-wait");
lf[120]=C_h_intern(&lf[120],14,"\000process-error");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[122]=C_h_intern(&lf[122],21,"\003sysfile-nonblocking!");
lf[123]=C_h_intern(&lf[123],19,"\003sysfile-select-one");
lf[124]=C_h_intern(&lf[124],8,"pipe/buf");
lf[125]=C_h_intern(&lf[125],11,"fcntl/dupfd");
lf[126]=C_h_intern(&lf[126],11,"fcntl/getfd");
lf[127]=C_h_intern(&lf[127],11,"fcntl/setfd");
lf[128]=C_h_intern(&lf[128],11,"fcntl/getfl");
lf[129]=C_h_intern(&lf[129],11,"fcntl/setfl");
lf[130]=C_h_intern(&lf[130],11,"open/rdonly");
lf[131]=C_h_intern(&lf[131],11,"open/wronly");
lf[132]=C_h_intern(&lf[132],9,"open/rdwr");
lf[133]=C_h_intern(&lf[133],9,"open/read");
lf[134]=C_h_intern(&lf[134],10,"open/write");
lf[135]=C_h_intern(&lf[135],10,"open/creat");
lf[136]=C_h_intern(&lf[136],11,"open/append");
lf[137]=C_h_intern(&lf[137],9,"open/excl");
lf[138]=C_h_intern(&lf[138],11,"open/noctty");
lf[139]=C_h_intern(&lf[139],13,"open/nonblock");
lf[140]=C_h_intern(&lf[140],10,"open/trunc");
lf[141]=C_h_intern(&lf[141],9,"open/sync");
lf[142]=C_h_intern(&lf[142],10,"open/fsync");
lf[143]=C_h_intern(&lf[143],11,"open/binary");
lf[144]=C_h_intern(&lf[144],9,"open/text");
lf[145]=C_h_intern(&lf[145],10,"perm/irusr");
lf[146]=C_h_intern(&lf[146],10,"perm/iwusr");
lf[147]=C_h_intern(&lf[147],10,"perm/ixusr");
lf[148]=C_h_intern(&lf[148],10,"perm/irgrp");
lf[149]=C_h_intern(&lf[149],10,"perm/iwgrp");
lf[150]=C_h_intern(&lf[150],10,"perm/ixgrp");
lf[151]=C_h_intern(&lf[151],10,"perm/iroth");
lf[152]=C_h_intern(&lf[152],10,"perm/iwoth");
lf[153]=C_h_intern(&lf[153],10,"perm/ixoth");
lf[154]=C_h_intern(&lf[154],10,"perm/irwxu");
lf[155]=C_h_intern(&lf[155],10,"perm/irwxg");
lf[156]=C_h_intern(&lf[156],10,"perm/irwxo");
lf[157]=C_h_intern(&lf[157],10,"perm/isvtx");
lf[158]=C_h_intern(&lf[158],10,"perm/isuid");
lf[159]=C_h_intern(&lf[159],10,"perm/isgid");
lf[160]=C_h_intern(&lf[160],12,"file-control");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot control file");
lf[162]=C_h_intern(&lf[162],9,"file-open");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[164]=C_h_intern(&lf[164],10,"file-close");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[166]=C_h_intern(&lf[166],9,"file-read");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[169]=C_h_intern(&lf[169],10,"file-write");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[172]=C_h_intern(&lf[172],12,"file-mkstemp");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[174]=C_h_intern(&lf[174],11,"file-select");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\006failed");
lf[176]=C_h_intern(&lf[176],8,"seek/set");
lf[177]=C_h_intern(&lf[177],8,"seek/end");
lf[178]=C_h_intern(&lf[178],8,"seek/cur");
lf[179]=C_h_intern(&lf[179],18,"set-file-position!");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[182]=C_h_intern(&lf[182],5,"port\077");
lf[183]=C_h_intern(&lf[183],13,"\000bounds-error");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[185]=C_h_intern(&lf[185],13,"file-position");
lf[186]=C_h_intern(&lf[186],16,"create-directory");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[188]=C_h_intern(&lf[188],18,"pathname-directory");
lf[189]=C_h_intern(&lf[189],12,"file-exists\077");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[191]=C_h_intern(&lf[191],17,"change-directory\052");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[195]=C_h_intern(&lf[195],15,"open-input-pipe");
lf[196]=C_h_intern(&lf[196],5,"\000text");
lf[197]=C_h_intern(&lf[197],7,"\000binary");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[199]=C_h_intern(&lf[199],16,"open-output-pipe");
lf[200]=C_h_intern(&lf[200],16,"close-input-pipe");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[202]=C_h_intern(&lf[202],20,"\003syscheck-input-port");
lf[203]=C_h_intern(&lf[203],17,"close-output-pipe");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[205]=C_h_intern(&lf[205],21,"\003syscheck-output-port");
lf[206]=C_h_intern(&lf[206],20,"call-with-input-pipe");
lf[207]=C_h_intern(&lf[207],21,"call-with-output-pipe");
lf[208]=C_h_intern(&lf[208],20,"with-input-from-pipe");
lf[209]=C_h_intern(&lf[209],18,"\003sysstandard-input");
lf[210]=C_h_intern(&lf[210],19,"with-output-to-pipe");
lf[211]=C_h_intern(&lf[211],19,"\003sysstandard-output");
lf[212]=C_h_intern(&lf[212],11,"create-pipe");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[214]=C_h_intern(&lf[214],11,"signal/term");
lf[215]=C_h_intern(&lf[215],11,"signal/kill");
lf[216]=C_h_intern(&lf[216],10,"signal/int");
lf[217]=C_h_intern(&lf[217],10,"signal/hup");
lf[218]=C_h_intern(&lf[218],10,"signal/fpe");
lf[219]=C_h_intern(&lf[219],10,"signal/ill");
lf[220]=C_h_intern(&lf[220],11,"signal/segv");
lf[221]=C_h_intern(&lf[221],11,"signal/abrt");
lf[222]=C_h_intern(&lf[222],11,"signal/trap");
lf[223]=C_h_intern(&lf[223],11,"signal/quit");
lf[224]=C_h_intern(&lf[224],11,"signal/alrm");
lf[225]=C_h_intern(&lf[225],13,"signal/vtalrm");
lf[226]=C_h_intern(&lf[226],11,"signal/prof");
lf[227]=C_h_intern(&lf[227],9,"signal/io");
lf[228]=C_h_intern(&lf[228],10,"signal/urg");
lf[229]=C_h_intern(&lf[229],11,"signal/chld");
lf[230]=C_h_intern(&lf[230],11,"signal/cont");
lf[231]=C_h_intern(&lf[231],11,"signal/stop");
lf[232]=C_h_intern(&lf[232],11,"signal/tstp");
lf[233]=C_h_intern(&lf[233],11,"signal/pipe");
lf[234]=C_h_intern(&lf[234],11,"signal/xcpu");
lf[235]=C_h_intern(&lf[235],11,"signal/xfsz");
lf[236]=C_h_intern(&lf[236],11,"signal/usr1");
lf[237]=C_h_intern(&lf[237],11,"signal/usr2");
lf[238]=C_h_intern(&lf[238],12,"signal/winch");
lf[239]=C_h_intern(&lf[239],12,"signals-list");
lf[240]=C_h_intern(&lf[240],16,"set-signal-mask!");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot set signal mask");
lf[242]=C_h_intern(&lf[242],11,"signal-mask");
lf[243]=C_h_intern(&lf[243],14,"signal-masked\077");
lf[244]=C_h_intern(&lf[244],12,"signal-mask!");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot block signal");
lf[246]=C_h_intern(&lf[246],14,"signal-unmask!");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot unblock signal");
lf[248]=C_h_intern(&lf[248],18,"system-information");
lf[249]=C_h_intern(&lf[249],25,"\003syspeek-nonnull-c-string");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system information");
lf[251]=C_h_intern(&lf[251],15,"current-user-id");
lf[252]=C_h_intern(&lf[252],25,"current-effective-user-id");
lf[253]=C_h_intern(&lf[253],16,"current-group-id");
lf[254]=C_h_intern(&lf[254],26,"current-effective-group-id");
lf[255]=C_h_intern(&lf[255],16,"user-information");
lf[256]=C_h_intern(&lf[256],6,"vector");
lf[257]=C_h_intern(&lf[257],4,"list");
lf[258]=C_h_intern(&lf[258],17,"current-user-name");
lf[259]=C_h_intern(&lf[259],27,"current-effective-user-name");
lf[260]=C_h_intern(&lf[260],17,"group-information");
lf[261]=C_h_intern(&lf[261],10,"get-groups");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[265]=C_h_intern(&lf[265],11,"set-groups!");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot set supplementary group ids");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[268]=C_h_intern(&lf[268],17,"initialize-groups");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000)cannot initialize supplementary group ids");
lf[270]=C_h_intern(&lf[270],10,"errno/perm");
lf[271]=C_h_intern(&lf[271],11,"errno/noent");
lf[272]=C_h_intern(&lf[272],10,"errno/srch");
lf[273]=C_h_intern(&lf[273],10,"errno/intr");
lf[274]=C_h_intern(&lf[274],8,"errno/io");
lf[275]=C_h_intern(&lf[275],12,"errno/noexec");
lf[276]=C_h_intern(&lf[276],10,"errno/badf");
lf[277]=C_h_intern(&lf[277],11,"errno/child");
lf[278]=C_h_intern(&lf[278],11,"errno/nomem");
lf[279]=C_h_intern(&lf[279],11,"errno/acces");
lf[280]=C_h_intern(&lf[280],11,"errno/fault");
lf[281]=C_h_intern(&lf[281],10,"errno/busy");
lf[282]=C_h_intern(&lf[282],12,"errno/notdir");
lf[283]=C_h_intern(&lf[283],11,"errno/isdir");
lf[284]=C_h_intern(&lf[284],11,"errno/inval");
lf[285]=C_h_intern(&lf[285],11,"errno/mfile");
lf[286]=C_h_intern(&lf[286],11,"errno/nospc");
lf[287]=C_h_intern(&lf[287],11,"errno/spipe");
lf[288]=C_h_intern(&lf[288],10,"errno/pipe");
lf[289]=C_h_intern(&lf[289],11,"errno/again");
lf[290]=C_h_intern(&lf[290],10,"errno/rofs");
lf[291]=C_h_intern(&lf[291],11,"errno/exist");
lf[292]=C_h_intern(&lf[292],16,"errno/wouldblock");
lf[293]=C_h_intern(&lf[293],10,"errno/2big");
lf[294]=C_h_intern(&lf[294],12,"errno/deadlk");
lf[295]=C_h_intern(&lf[295],9,"errno/dom");
lf[296]=C_h_intern(&lf[296],10,"errno/fbig");
lf[297]=C_h_intern(&lf[297],11,"errno/ilseq");
lf[298]=C_h_intern(&lf[298],11,"errno/mlink");
lf[299]=C_h_intern(&lf[299],17,"errno/nametoolong");
lf[300]=C_h_intern(&lf[300],11,"errno/nfile");
lf[301]=C_h_intern(&lf[301],11,"errno/nodev");
lf[302]=C_h_intern(&lf[302],11,"errno/nolck");
lf[303]=C_h_intern(&lf[303],11,"errno/nosys");
lf[304]=C_h_intern(&lf[304],14,"errno/notempty");
lf[305]=C_h_intern(&lf[305],11,"errno/notty");
lf[306]=C_h_intern(&lf[306],10,"errno/nxio");
lf[307]=C_h_intern(&lf[307],11,"errno/range");
lf[308]=C_h_intern(&lf[308],10,"errno/xdev");
lf[309]=C_h_intern(&lf[309],16,"change-file-mode");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[311]=C_h_intern(&lf[311],17,"change-file-owner");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot change file owner");
lf[313]=C_h_intern(&lf[313],17,"file-read-access\077");
lf[314]=C_h_intern(&lf[314],18,"file-write-access\077");
lf[315]=C_h_intern(&lf[315],20,"file-execute-access\077");
lf[316]=C_h_intern(&lf[316],14,"create-session");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot create session");
lf[318]=C_h_intern(&lf[318],16,"process-group-id");
lf[319]=C_h_intern(&lf[319],20,"create-symbolic-link");
lf[320]=C_h_intern(&lf[320],18,"create-symbol-link");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create symbolic link");
lf[322]=C_h_intern(&lf[322],18,"read-symbolic-link");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot read symbolic link");
lf[324]=C_h_intern(&lf[324],12,"canonicalize");
lf[325]=C_h_intern(&lf[325],9,"substring");
lf[326]=C_h_intern(&lf[326],9,"file-link");
lf[327]=C_h_intern(&lf[327],9,"hard-link");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\032could not create hard link");
lf[329]=C_h_intern(&lf[329],21,"\003syscustom-input-port");
lf[330]=C_h_intern(&lf[330],4,"void");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\015cannot select");
lf[332]=C_h_intern(&lf[332],3,"rx=");
lf[333]=C_h_intern(&lf[333],17,"\003systhread-yield!");
lf[334]=C_h_intern(&lf[334],25,"\003systhread-block-for-i/o!");
lf[335]=C_h_intern(&lf[335],18,"\003syscurrent-thread");
lf[336]=C_h_intern(&lf[336],6,"\000input");
lf[337]=C_h_intern(&lf[337],22,"\003sysdispatch-interrupt");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[340]=C_h_intern(&lf[340],14,"set-port-name!");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[343]=C_h_intern(&lf[343],17,"\003sysstring-append");
lf[344]=C_h_intern(&lf[344],20,"\003sysscan-buffer-line");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[346]=C_h_intern(&lf[346],15,"make-input-port");
lf[347]=C_h_intern(&lf[347],22,"\003syscustom-output-port");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot write");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[350]=C_h_intern(&lf[350],16,"make-output-port");
lf[351]=C_h_intern(&lf[351],13,"file-truncate");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot truncate file");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[354]=C_h_intern(&lf[354],4,"lock");
lf[355]=C_h_intern(&lf[355],14,"\003syscheck-port");
lf[356]=C_h_intern(&lf[356],9,"file-lock");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[358]=C_h_intern(&lf[358],18,"file-lock/blocking");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[360]=C_h_intern(&lf[360],14,"file-test-lock");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[362]=C_h_intern(&lf[362],11,"file-unlock");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[364]=C_h_intern(&lf[364],11,"create-fifo");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create FIFO");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000(system error while trying to access file");
lf[368]=C_h_intern(&lf[368],6,"setenv");
lf[369]=C_h_intern(&lf[369],8,"unsetenv");
lf[370]=C_h_intern(&lf[370],25,"get-environment-variables");
lf[371]=C_h_intern(&lf[371],9,"prot/read");
lf[372]=C_h_intern(&lf[372],10,"prot/write");
lf[373]=C_h_intern(&lf[373],9,"prot/exec");
lf[374]=C_h_intern(&lf[374],9,"prot/none");
lf[375]=C_h_intern(&lf[375],9,"map/fixed");
lf[376]=C_h_intern(&lf[376],10,"map/shared");
lf[377]=C_h_intern(&lf[377],11,"map/private");
lf[378]=C_h_intern(&lf[378],13,"map/anonymous");
lf[379]=C_h_intern(&lf[379],8,"map/file");
lf[380]=C_h_intern(&lf[380],18,"map-file-to-memory");
lf[381]=C_h_intern(&lf[381],4,"mmap");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot map file to memory");
lf[383]=C_h_intern(&lf[383],20,"\003syspointer->address");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - not a foreign pointer");
lf[385]=C_h_intern(&lf[385],16,"\003sysnull-pointer");
lf[386]=C_h_intern(&lf[386],22,"unmap-file-from-memory");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot unmap file from memory");
lf[388]=C_h_intern(&lf[388],26,"memory-mapped-file-pointer");
lf[389]=C_h_intern(&lf[389],19,"memory-mapped-file\077");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[392]=C_h_intern(&lf[392],12,"string->time");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\027%a %b %e %H:%M:%S %Z %Y");
lf[394]=C_h_intern(&lf[394],17,"utc-time->seconds");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[396]=C_h_intern(&lf[396],27,"local-timezone-abbreviation");
lf[397]=C_h_intern(&lf[397],5,"_exit");
lf[398]=C_h_intern(&lf[398],10,"set-alarm!");
lf[399]=C_h_intern(&lf[399],19,"set-buffering-mode!");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[401]=C_h_intern(&lf[401],5,"\000full");
lf[402]=C_h_intern(&lf[402],5,"\000line");
lf[403]=C_h_intern(&lf[403],5,"\000none");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[405]=C_h_intern(&lf[405],14,"terminal-port\077");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000#port is not connected to a terminal");
lf[408]=C_h_intern(&lf[408],13,"terminal-name");
lf[409]=C_h_intern(&lf[409],13,"terminal-size");
lf[410]=C_h_intern(&lf[410],6,"\000error");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\036Unable to get size of terminal");
lf[412]=C_h_intern(&lf[412],17,"\003sysmake-locative");
lf[413]=C_h_intern(&lf[413],8,"location");
lf[414]=C_h_intern(&lf[414],13,"get-host-name");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[416]=C_h_intern(&lf[416],12,"process-fork");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create child process");
lf[418]=C_h_intern(&lf[418],24,"pathname-strip-directory");
lf[419]=C_h_intern(&lf[419],15,"process-execute");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[421]=C_h_intern(&lf[421],17,"parent-process-id");
lf[422]=C_h_intern(&lf[422],5,"sleep");
lf[423]=C_h_intern(&lf[423],14,"process-signal");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000 could not send signal to process");
lf[425]=C_h_intern(&lf[425],17,"\003sysshell-command");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\007/bin/sh");
lf[427]=C_h_intern(&lf[427],24,"get-environment-variable");
lf[428]=C_decode_literal(C_heaptop,"\376B\000\000\005SHELL");
lf[429]=C_h_intern(&lf[429],27,"\003sysshell-command-arguments");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[431]=C_h_intern(&lf[431],11,"process-run");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\025abnormal process exit");
lf[433]=C_h_intern(&lf[433],11,"\003sysprocess");
lf[434]=C_h_intern(&lf[434],7,"process");
lf[435]=C_h_intern(&lf[435],8,"process\052");
lf[436]=C_h_intern(&lf[436],6,"values");
lf[437]=C_h_intern(&lf[437],19,"set-root-directory!");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\037unable to change root directory");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve process group ID");
lf[440]=C_h_intern(&lf[440],21,"set-process-group-id!");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot set process group ID");
lf[442]=C_h_intern(&lf[442],18,"getter-with-setter");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\026(process-group-id pid)");
lf[444]=C_h_intern(&lf[444],26,"effective-group-id!-setter");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot set effective group ID");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\034(current-effective-group-id)");
lf[447]=C_h_intern(&lf[447],12,"set-user-id!");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot set group ID");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\022(current-group-id)");
lf[450]=C_h_intern(&lf[450],25,"effective-user-id!-setter");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot set effective user ID");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\033(current-effective-used-id)");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot set user ID");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000\021(current-user-id)");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\024(file-position port)");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\031(file-creation-mode mode)");
lf[459]=C_h_intern(&lf[459],26,"set-file-modification-time");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000!cannot set file modification-time");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\032(file-modification-time f)");
C_register_lf2(lf,462,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2596,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k4241 in for-each-loop808 in k4121 in k4118 in k4113 in k4109 in k4107 in k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4233(t3,((C_word*)t0)[4],t2);}

/* ##sys#process in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_7543,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7549,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t5,a[7]=t6,a[8]=t7,a[9]=t8,a[10]=((C_word)li249),tmp=(C_word)a,a+=11,tmp);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7554,a[2]=t7,a[3]=t6,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word)li250),tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm:1870: ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}

/* f_4216 in k4121 in k4118 in k4113 in k4109 in k4107 in k4105 in file-select in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4216(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4216,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4222,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:704: fd_test */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(0),t2);}

/* k4220 */
static void C_ccall f_4222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4222,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* port->fileno in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2952(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2952,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2956,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posix-common.scm:277: ##sys#check-open-port */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t3,t2,lf[54]);}

/* k2955 in port->fileno in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2956,2,t0,t1);}
t2=C_slot(((C_word*)t0)[2],C_fix(7));
t3=C_eqp(lf[29],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2968,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:283: ##sys#port-data */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[55]+1)))(3,*((C_word*)lf[55]+1),t4,((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posix-common.scm:284: ##sys#peek-unsigned-integer */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[58]+1)))(4,*((C_word*)lf[58]+1),t4,((C_word*)t0)[2],C_fix(0));}}

/* k2949 in open-output-file* in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2950,2,t0,t1);}
t2=C_fdopen(&a,2,((C_word*)t0)[2],t1);
/* posix-common.scm:273: check */
f_2912(((C_word*)t0)[4],lf[53],((C_word*)t0)[2],C_SCHEME_FALSE,t2);}

/* file-write-access? in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5408(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5408,3,t0,t1,t2);}
/* posixunix.scm:1219: check */
f_5382(t1,t2,C_fix((C_word)W_OK),lf[314]);}

/* k5399 in check in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1215: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* file-read-access? in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5402(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5402,3,t0,t1,t2);}
/* posixunix.scm:1218: check */
f_5382(t1,t2,C_fix((C_word)R_OK),lf[313]);}

/* f_6617 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[5],*a=ab;
if(c!=8) C_bad_argc_2(c,8,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr8,(void*)f_6617,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=C_a_i_bytevector(&a,1,C_fix(3));
t9=(C_truep(t2)?C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t10=C_i_foreign_integer_argumentp(t3);
t11=C_i_foreign_fixnum_argumentp(t4);
t12=C_i_foreign_fixnum_argumentp(t5);
t13=C_i_foreign_fixnum_argumentp(t6);
t14=C_i_foreign_integer_argumentp(t7);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,stub1626(t8,t9,t10,t11,t12,t13,t14));}

/* file-mkstemp in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4054(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4054,3,t0,t1,t2);}
t3=C_i_check_string_2(t2,lf[172]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4060,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:648: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t4,t2,lf[172]);}

/* k4059 in file-mkstemp in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4060,2,t0,t1);}
t2=C_mkstemp(t1);
t3=C_block_size(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4064,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
/* posixunix.scm:652: posix-error */
t6=lf[1];
f_2617(6,t6,t4,lf[8],lf[172],lf[173],((C_word*)t0)[3]);}
else{
t6=t4;
f_4064(2,t6,C_SCHEME_UNDEFINED);}}

/* f_3083 in k3081 in k3076 in delete-directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3083(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3083,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3092,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posix-common.scm:334: symbolic-link? */
t4=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4063 in k4059 in file-mkstemp in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4070,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* posixunix.scm:653: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),t2,((C_word*)t0)[5],C_fix(0),t3);}

/* k3081 in k3076 in delete-directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3083,a[2]=((C_word*)t0)[2],a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
t3=C_i_check_list_2(t1,lf[70]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3103,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3108,a[2]=t6,a[3]=t2,a[4]=((C_word)li26),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3108(t8,t4,t1);}

/* k7508 */
static void C_ccall f_7509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7522,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm:1917: swapped-ends */
t4=((C_word*)t0)[9];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[12]);}

/* f_7914 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7914(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_7914r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7914r(t0,t1,t2);}}

static void C_ccall f_7914r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
t3=C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:C_i_car(t2));
t5=(C_truep(t4)?C_i_check_exact_2(t4,lf[98]):C_SCHEME_UNDEFINED);
t6=C_umask(t4);
if(C_truep(t4)){
t7=C_SCHEME_UNDEFINED;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=C_umask(t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t6);}}

/* k4032 in k4028 in k4026 in file-write in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k7521 in k7508 */
static void C_ccall f_7522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1917: connect-child */
t2=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[4],t1,((C_word*)t0)[5],*((C_word*)lf[38]+1));}

/* f_7523 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7523(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_7523,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7526,a[2]=t1,a[3]=t2,a[4]=t4,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm:1922: connect-parent */
t10=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t9,t2,t5,t6,t7);}

/* check in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_2912(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2912,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep(C_null_pointerp(t5))){
/* posix-common.scm:262: posix-error */
t6=lf[1];
f_2617(6,t6,t1,lf[8],t2,lf[47],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2924,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posix-common.scm:263: ##sys#make-port */
((C_proc6)C_fast_retrieve_proc(*((C_word*)lf[48]+1)))(6,*((C_word*)lf[48]+1),t6,t4,*((C_word*)lf[49]+1),lf[50],lf[51]);}}

/* k7525 */
static void C_ccall f_7526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm:1923: ##sys#custom-input-port */
t2=*((C_word*)lf[329]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1,C_SCHEME_TRUE,C_fix(256),((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3090 */
static void C_ccall f_3092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3092,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[69]+1);
/* posix-common.scm:333: g275 */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[69]+1)))(3,*((C_word*)lf[69]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3098,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posix-common.scm:335: directory? */
t3=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}

/* k3096 in k3090 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posix-common.scm:333: g275 */
f_3059(((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=*((C_word*)lf[69]+1);
/* posix-common.scm:333: g275 */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[69]+1)))(3,*((C_word*)lf[69]+1),((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* f_7906 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7906(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7906,3,t0,t1,t2);}
t3=C_i_check_exact_2(t2,lf[116]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(*((C_word*)lf[115]+1),t2));}

/* k2967 in k2955 in port->fileno in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_slot(t1,C_fix(0)));}

/* k7512 in k7510 in k7508 */
static void C_ccall f_7513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1919: process-execute */
t2=*((C_word*)lf[419]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k3062 in rmdir in delete-directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_rmdir(t1);
t3=C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* posix-common.scm:324: posix-error */
t4=lf[1];
f_2617(6,t4,((C_word*)t0)[2],lf[8],lf[67],lf[68],((C_word*)t0)[3]);}}

/* k7510 in k7508 */
static void C_ccall f_7511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7519,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm:1918: swapped-ends */
t4=((C_word*)t0)[9];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[10]);}

/* f_7934 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7934(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7934,3,t0,t1,t2);}
t3=C_i_check_exact_2(t2,lf[98]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_umask(t2));}

/* k2975 in k2990 in k2955 in port->fileno in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* f_4094 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4094,4,t0,t1,t2,t3);}
t4=C_i_foreign_fixnum_argumentp(t2);
t5=C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,stub731(C_SCHEME_UNDEFINED,t4,t5));}

/* k7518 in k7510 in k7508 */
static void C_ccall f_7519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1918: connect-child */
t2=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[4],t1,((C_word*)t0)[5],*((C_word*)lf[39]+1));}

/* k3076 in delete-directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3077,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3082,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posix-common.scm:328: find-files */
t3=*((C_word*)lf[71]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,t1,lf[72],C_SCHEME_TRUE,lf[73],C_SCHEME_FALSE);}
else{
/* posix-common.scm:340: rmdir */
f_3059(((C_word*)t0)[4],t1);}}

/* k5493 in k5479 in read-symbolic-link in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5500,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixunix.scm:1274: symbolic-link? */
t3=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* f_7939 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7939(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7939,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7942,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:188: ##sys#stat */
f_2633(t3,t2,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[16]);}

/* k7951 */
static void C_ccall f_7953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,stub117(C_SCHEME_UNDEFINED,t1,((C_word*)t0)[3]));}

/* k4069 in k4063 in k4059 in file-mkstemp in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:653: values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* delete-directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_3052r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3052r(t0,t1,t2,t3);}}

static void C_ccall f_3052r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(8);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3059,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp);
t7=C_i_check_string_2(t2,lf[67]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3077,a[2]=t5,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posix-common.scm:326: ##sys#expand-home-path */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t8,t2);}

/* rmdir in delete-directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_3059(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3059,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3063,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posix-common.scm:322: ##sys#make-c-string */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t3,t2);}

/* k7941 */
static void C_ccall f_7942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7942,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* f_7944 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7944(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7944,4,t0,t1,t2,t3);}
t4=C_i_check_number_2(t3,lf[459]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7948,a[2]=((C_word)li277),tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7962,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7974,a[2]=t5,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posix-common.scm:192: ##sys#expand-home-path */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t7,t2);}

/* f_4081 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4081(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4081,3,t0,t1,t2);}
t3=C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub720(C_SCHEME_UNDEFINED,t3));}

/* f_4086 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4086,4,t0,t1,t2,t3);}
t4=C_i_foreign_fixnum_argumentp(t2);
t5=C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,stub725(C_SCHEME_UNDEFINED,t4,t5));}

/* k7973 */
static void C_ccall f_7974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posix-common.scm:191: g113 */
t2=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* f_7948 */
static void C_ccall f_7948(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7948,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7953,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t5=C_i_foreign_string_argumentp(t2);
/* posix-common.scm:191: ##sys#make-c-string */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t4,t5);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,stub117(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t3));}}

/* k5456 in create-symbolic-link in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5460,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5463,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1256: ##sys#expand-home-path */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t3,((C_word*)t0)[4]);}

/* k3031 in current-directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3032,2,t0,t1);}
t2=C_curdir(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3034,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posix-common.scm:312: ##sys#update-errno */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t3);}

/* k7500 in k7494 in k7492 in k7490 in spawn in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7504,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7506,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[3],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word)li245),tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm:1914: process-fork */
t4=*((C_word*)lf[416]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k7503 in k7500 in k7494 in k7492 in k7490 in spawn in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 in ... */
static void C_ccall f_7504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1912: values */
C_values(6,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* k3033 in k3031 in current-directory in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[2])){
/* posix-common.scm:314: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),((C_word*)t0)[3],((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2]);}
else{
/* posix-common.scm:315: ##sys#signal-hook */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[8],lf[62],lf[65]);}}

/* f_7506 in k7500 in k7494 in k7492 in k7490 in spawn in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 in ... */
static void C_ccall f_7506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7509,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm:1916: connect-child */
t3=((C_word*)t0)[5];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[6],((C_word*)t0)[12],((C_word*)t0)[13],*((C_word*)lf[37]+1));}

/* k7960 */
static void C_ccall f_7962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_fixnum_lessp(t1,C_fix(0)))){
/* posix-common.scm:194: posix-error */
t2=lf[1];
f_2617(7,t2,((C_word*)t0)[2],lf[8],lf[459],lf[460],((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k5459 in k5456 in create-symbolic-link in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_symlink(((C_word*)t0)[2],t1);
if(C_truep(C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm:1258: posix-error */
t3=lf[1];
f_2617(7,t3,((C_word*)t0)[3],lf[8],lf[320],lf[321],((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5462 in k5456 in create-symbolic-link in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1256: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],t1,lf[319]);}

/* k5465 in create-symbolic-link in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1255: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],t1,lf[319]);}

/* k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word ab[257],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5469,2,t0,t1);}
t2=C_mutate((C_word*)lf[322]+1 /* (set! read-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5470,a[2]=t1,a[3]=((C_word)li146),tmp=(C_word)a,a+=4,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5517,a[2]=((C_word)li147),tmp=(C_word)a,a+=3,tmp);
t4=C_mutate((C_word*)lf[326]+1 /* (set! file-link ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5539,a[2]=t3,a[3]=((C_word)li148),tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[329]+1 /* (set! ##sys#custom-input-port ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5559,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[347]+1 /* (set! ##sys#custom-output-port ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6009,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[351]+1 /* (set! file-truncate ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6249,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6285,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp));
t13=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6343,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[356]+1 /* (set! file-lock ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6358,a[2]=t11,a[3]=t9,a[4]=((C_word)li178),tmp=(C_word)a,a+=5,tmp));
t15=C_mutate((C_word*)lf[358]+1 /* (set! file-lock/blocking ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6374,a[2]=t11,a[3]=t9,a[4]=((C_word)li179),tmp=(C_word)a,a+=5,tmp));
t16=C_mutate((C_word*)lf[360]+1 /* (set! file-test-lock ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6390,a[2]=t11,a[3]=t9,a[4]=((C_word)li181),tmp=(C_word)a,a+=5,tmp));
t17=C_mutate((C_word*)lf[362]+1 /* (set! file-unlock ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6415,a[2]=((C_word)li182),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[364]+1 /* (set! create-fifo ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6440,a[2]=((C_word)li183),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[34]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6476,a[2]=((C_word)li184),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[368]+1 /* (set! setenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6518,a[2]=((C_word)li185),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[369]+1 /* (set! unsetenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6532,a[2]=((C_word)li186),tmp=(C_word)a,a+=3,tmp));
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6541,a[2]=((C_word)li187),tmp=(C_word)a,a+=3,tmp);
t23=C_mutate((C_word*)lf[370]+1 /* (set! get-environment-variables ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6550,a[2]=t22,a[3]=((C_word)li190),tmp=(C_word)a,a+=4,tmp));
t24=C_mutate((C_word*)lf[371]+1 /* (set! prot/read ...) */,C_fix((C_word)PROT_READ));
t25=C_mutate((C_word*)lf[372]+1 /* (set! prot/write ...) */,C_fix((C_word)PROT_WRITE));
t26=C_mutate((C_word*)lf[373]+1 /* (set! prot/exec ...) */,C_fix((C_word)PROT_EXEC));
t27=C_mutate((C_word*)lf[374]+1 /* (set! prot/none ...) */,C_fix((C_word)PROT_NONE));
t28=C_mutate((C_word*)lf[375]+1 /* (set! map/fixed ...) */,C_fix((C_word)MAP_FIXED));
t29=C_mutate((C_word*)lf[376]+1 /* (set! map/shared ...) */,C_fix((C_word)MAP_SHARED));
t30=C_mutate((C_word*)lf[377]+1 /* (set! map/private ...) */,C_fix((C_word)MAP_PRIVATE));
t31=C_mutate((C_word*)lf[378]+1 /* (set! map/anonymous ...) */,C_fix((C_word)MAP_ANON));
t32=C_mutate((C_word*)lf[379]+1 /* (set! map/file ...) */,C_fix((C_word)MAP_FILE));
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6617,a[2]=((C_word)li191),tmp=(C_word)a,a+=3,tmp);
t34=C_mutate((C_word*)lf[380]+1 /* (set! map-file-to-memory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6641,a[2]=t33,a[3]=((C_word)li192),tmp=(C_word)a,a+=4,tmp));
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6683,a[2]=((C_word)li193),tmp=(C_word)a,a+=3,tmp);
t36=C_mutate((C_word*)lf[386]+1 /* (set! unmap-file-from-memory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6695,a[2]=t35,a[3]=((C_word)li194),tmp=(C_word)a,a+=4,tmp));
t37=C_mutate((C_word*)lf[388]+1 /* (set! memory-mapped-file-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6725,a[2]=((C_word)li195),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[389]+1 /* (set! memory-mapped-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6734,a[2]=((C_word)li196),tmp=(C_word)a,a+=3,tmp));
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6740,a[2]=((C_word)li197),tmp=(C_word)a,a+=3,tmp);
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6746,a[2]=((C_word)li198),tmp=(C_word)a,a+=3,tmp);
t41=C_mutate((C_word*)lf[111]+1 /* (set! time->string ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6752,a[2]=t40,a[3]=t39,a[4]=((C_word)li199),tmp=(C_word)a,a+=5,tmp));
t42=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6800,a[2]=((C_word)li200),tmp=(C_word)a,a+=3,tmp);
t43=C_mutate((C_word*)lf[392]+1 /* (set! string->time ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6802,a[2]=t42,a[3]=((C_word)li201),tmp=(C_word)a,a+=4,tmp));
t44=C_mutate((C_word*)lf[394]+1 /* (set! utc-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6831,a[2]=((C_word)li202),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[396]+1 /* (set! local-timezone-abbreviation ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6846,a[2]=((C_word)li203),tmp=(C_word)a,a+=3,tmp));
t46=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6854,a[2]=((C_word)li204),tmp=(C_word)a,a+=3,tmp);
t47=C_mutate((C_word*)lf[397]+1 /* (set! _exit ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6859,a[2]=t46,a[3]=((C_word)li205),tmp=(C_word)a,a+=4,tmp));
t48=C_mutate((C_word*)lf[398]+1 /* (set! set-alarm! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6872,a[2]=((C_word)li206),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[399]+1 /* (set! set-buffering-mode! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6879,a[2]=((C_word)li207),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[405]+1 /* (set! terminal-port? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6938,a[2]=((C_word)li208),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate(&lf[406] /* (set! ##sys#terminal-check ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6955,a[2]=((C_word)li209),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6976,a[2]=((C_word)li210),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[408]+1 /* (set! terminal-name ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6985,a[2]=t52,a[3]=((C_word)li211),tmp=(C_word)a,a+=4,tmp));
t54=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6995,a[2]=((C_word)li212),tmp=(C_word)a,a+=3,tmp);
t55=C_mutate((C_word*)lf[409]+1 /* (set! terminal-size ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7006,a[2]=t54,a[3]=((C_word)li213),tmp=(C_word)a,a+=4,tmp));
t56=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7034,a[2]=((C_word)li214),tmp=(C_word)a,a+=3,tmp);
t57=C_mutate((C_word*)lf[414]+1 /* (set! get-host-name ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7040,a[2]=t56,a[3]=((C_word)li215),tmp=(C_word)a,a+=4,tmp));
t58=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7051,a[2]=((C_word)li216),tmp=(C_word)a,a+=3,tmp);
t59=C_mutate((C_word*)lf[416]+1 /* (set! process-fork ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7053,a[2]=t58,a[3]=((C_word)li218),tmp=(C_word)a,a+=4,tmp));
t60=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7093,a[2]=((C_word)li219),tmp=(C_word)a,a+=3,tmp);
t61=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7111,a[2]=((C_word)li220),tmp=(C_word)a,a+=3,tmp);
t62=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7113,a[2]=((C_word)li221),tmp=(C_word)a,a+=3,tmp);
t63=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7131,a[2]=((C_word)li222),tmp=(C_word)a,a+=3,tmp);
t64=*((C_word*)lf[418]+1);
t65=C_mutate((C_word*)lf[419]+1 /* (set! process-execute ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7133,a[2]=t63,a[3]=t61,a[4]=t62,a[5]=t60,a[6]=t64,a[7]=((C_word)li225),tmp=(C_word)a,a+=8,tmp));
t66=C_mutate((C_word*)lf[119]+1 /* (set! ##sys#process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7270,a[2]=((C_word)li227),tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[421]+1 /* (set! parent-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7306,a[2]=((C_word)li228),tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[422]+1 /* (set! sleep ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7310,a[2]=((C_word)li229),tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[423]+1 /* (set! process-signal ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7317,a[2]=((C_word)li230),tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[425]+1 /* (set! ##sys#shell-command ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7340,a[2]=((C_word)li231),tmp=(C_word)a,a+=3,tmp));
t71=C_mutate((C_word*)lf[429]+1 /* (set! ##sys#shell-command-arguments ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7349,a[2]=((C_word)li232),tmp=(C_word)a,a+=3,tmp));
t72=C_mutate((C_word*)lf[431]+1 /* (set! process-run ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7355,a[2]=((C_word)li233),tmp=(C_word)a,a+=3,tmp));
t73=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7391,a[2]=((C_word)li234),tmp=(C_word)a,a+=3,tmp);
t74=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7403,a[2]=((C_word)li238),tmp=(C_word)a,a+=3,tmp);
t75=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7437,a[2]=((C_word)li241),tmp=(C_word)a,a+=3,tmp);
t76=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7454,a[2]=((C_word)li242),tmp=(C_word)a,a+=3,tmp);
t77=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7463,a[2]=t73,a[3]=((C_word)li243),tmp=(C_word)a,a+=4,tmp);
t78=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7475,a[2]=((C_word)li244),tmp=(C_word)a,a+=3,tmp);
t79=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7487,a[2]=t77,a[3]=t78,a[4]=t75,a[5]=((C_word)li246),tmp=(C_word)a,a+=6,tmp);
t80=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7523,a[2]=t76,a[3]=((C_word)li247),tmp=(C_word)a,a+=4,tmp);
t81=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7533,a[2]=t76,a[3]=((C_word)li248),tmp=(C_word)a,a+=4,tmp);
t82=C_mutate((C_word*)lf[433]+1 /* (set! ##sys#process ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7543,a[2]=t79,a[3]=t80,a[4]=t74,a[5]=t81,a[6]=((C_word)li251),tmp=(C_word)a,a+=7,tmp));
t83=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7588,a[2]=((C_word)li256),tmp=(C_word)a,a+=3,tmp);
t84=C_mutate((C_word*)lf[434]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7651,a[2]=t83,a[3]=((C_word)li258),tmp=(C_word)a,a+=4,tmp));
t85=C_mutate((C_word*)lf[435]+1 /* (set! process* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7695,a[2]=t83,a[3]=((C_word)li259),tmp=(C_word)a,a+=4,tmp));
t86=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7734,a[2]=((C_word)li260),tmp=(C_word)a,a+=3,tmp);
t87=C_mutate((C_word*)lf[437]+1 /* (set! set-root-directory! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7746,a[2]=t86,a[3]=((C_word)li261),tmp=(C_word)a,a+=4,tmp));
t88=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t88+1)))(2,t88,C_SCHEME_UNDEFINED);}

/* duplicate-fileno in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2996(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2996r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2996r(t0,t1,t2,t3);}}

static void C_ccall f_2996r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=C_i_check_exact_2(t2,*((C_word*)lf[60]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3002,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t6=t5;
f_3002(t6,C_dup(t2));}
else{
t6=C_i_car(t3);
t7=C_i_check_exact_2(t6,lf[60]);
t8=t5;
f_3002(t8,C_dup2(t2,t6));}}

/* k2990 in k2955 in port->fileno in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2991,2,t0,t1);}
if(C_truep(C_i_zerop(t1))){
/* posix-common.scm:289: posix-error */
t2=lf[1];
f_2617(6,t2,((C_word*)t0)[2],lf[13],lf[54],lf[56],((C_word*)t0)[3]);}
else{
t2=C_C_fileno(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2976,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnum_lessp(t2,C_fix(0)))){
/* posix-common.scm:287: posix-error */
t4=lf[1];
f_2617(6,t4,t3,lf[8],lf[54],lf[57],((C_word*)t0)[3]);}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}}

/* f_5611 in k5582 in k5578 in custom-input-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5611,2,t0,t1);}
if(C_truep(C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[3])[1]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=C_subchar(((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* f_5618 in k5582 in k5578 in custom-input-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5618,2,t0,t1);}
if(C_truep(C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[3])[1]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5629,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[2],a[11]=((C_word)li151),tmp=(C_word)a,a+=12,tmp));
t5=((C_word*)t3)[1];
f_5629(2,t5,t1);}
else{
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* loop */
static void C_ccall f_5629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5629,2,t0,t1);}
t2=C_read(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);
t3=C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=C_fix((C_word)errno);
t5=C_i_eqvp(t4,C_fix((C_word)EWOULDBLOCK));
t6=(C_truep(t5)?t5:C_i_eqvp(t4,C_fix((C_word)EAGAIN)));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5647,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1316: ##sys#thread-block-for-i/o! */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[334]+1)))(5,*((C_word*)lf[334]+1),t7,*((C_word*)lf[335]+1),((C_word*)t0)[2],lf[336]);}
else{
if(C_truep(C_i_eqvp(t4,C_fix((C_word)EINTR)))){
/* posixunix.scm:1320: ##sys#dispatch-interrupt */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[337]+1)))(3,*((C_word*)lf[337]+1),t1,((C_word*)((C_word*)t0)[5])[1]);}
else{
/* posixunix.scm:1321: posix-error */
t7=lf[1];
f_2617(7,t7,t1,lf[8],((C_word*)t0)[6],lf[338],((C_word*)t0)[2],((C_word*)t0)[7]);}}}
else{
t4=(C_truep(((C_word*)t0)[8])?C_eqp(t2,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5679,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm:1325: more? */
t6=((C_word*)t0)[8];
((C_proc2)C_fast_retrieve_proc(t6))(2,t6,t5);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[9])+1,t2);
t6=C_set_block_item(((C_word*)t0)[10],0,C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* k5677 in loop */
static void C_ccall f_5679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5679,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1327: ##sys#thread-yield! */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[333]+1)))(2,*((C_word*)lf[333]+1),t2);}
else{
t2=C_read(((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6]);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5686,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=C_eqp(((C_word*)t3)[1],C_fix(-1));
if(C_truep(t5)){
t6=C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
t7=(C_truep(t6)?t6:C_eqp(C_fix((C_word)errno),C_fix((C_word)EAGAIN)));
if(C_truep(t7)){
t8=C_set_block_item(t3,0,C_fix(0));
t9=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t3)[1]);
t10=C_set_block_item(((C_word*)t0)[8],0,C_fix(0));
t11=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
/* posixunix.scm:1334: posix-error */
t8=lf[1];
f_2617(7,t8,t4,lf[8],((C_word*)t0)[9],lf[339],((C_word*)t0)[4],((C_word*)t0)[10]);}}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t3)[1]);
t7=C_set_block_item(((C_word*)t0)[8],0,C_fix(0));
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}}

/* file-write in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4021r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4021r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4021r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=C_i_check_exact_2(t2,lf[169]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4027,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_blockp(t3))){
if(C_truep(C_byteblockp(t3))){
t7=t6;
f_4027(2,t7,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm:637: ##sys#signal-hook */
t7=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,lf[13],lf[169],lf[171],t3);}}
else{
/* posixunix.scm:637: ##sys#signal-hook */
t7=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,lf[13],lf[169],lf[171],t3);}}

/* k5599 in k5586 */
static void C_ccall f_5601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* posixunix.scm:1301: posix-error */
t2=lf[1];
f_2617(7,t2,((C_word*)t0)[2],lf[8],((C_word*)t0)[3],lf[331],((C_word*)t0)[4],((C_word*)t0)[5]);}}

/* k4026 in file-write in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4029,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[5]))){
t3=((C_word*)t0)[5];
t4=t2;
f_4029(t4,C_u_i_car(t3));}
else{
t3=t2;
f_4029(t3,C_block_size(((C_word*)t0)[3]));}}

/* k4028 in k4026 in file-write in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_4029(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4029,NULL,2,t0,t1);}
t2=C_i_check_exact_2(t1,lf[169]);
t3=C_write(((C_word*)t0)[2],((C_word*)t0)[3],t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4033,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_eqp(C_fix(-1),t3);
if(C_truep(t5)){
/* posixunix.scm:642: posix-error */
t6=lf[1];
f_2617(7,t6,t4,lf[8],lf[169],lf[170],((C_word*)t0)[2],t1);}
else{
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}}

/* f_4720 in k4709 in call-with-output-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4720(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4720r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4720r(t0,t1,t2);}}

static void C_ccall f_4720r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4723,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:857: close-output-pipe */
t4=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* with-input-from-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_4728r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4728r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4728r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4732,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t5,*((C_word*)lf[195]+1),t2,t4);}

/* k4722 */
static void C_ccall f_4723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4731 in with-input-from-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4732,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4737,a[2]=t5,a[3]=t3,a[4]=((C_word)li107),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4742,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word)li109),tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4755,a[2]=t3,a[3]=t5,a[4]=((C_word)li110),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:861: ##sys#dynamic-wind */
t9=*((C_word*)lf[87]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[3],t6,t7,t8);}

/* f_4737 in k4731 in with-input-from-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4737,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[209]+1));
t3=C_mutate((C_word*)lf[209]+1 /* (set! ##sys#standard-input ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k4868 in for-each-loop1048 in set-signal-mask! in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4860(t3,((C_word*)t0)[4],t2);}

/* for-each-loop1048 in set-signal-mask! in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_4860(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4860,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4869,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* posixunix.scm:954: g1049 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* ##sys#file-nonblocking! in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3847(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3847,3,t0,t1,t2);}
t3=C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub602(C_SCHEME_UNDEFINED,t3));}

/* ##sys#file-select-one in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3854(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3854,3,t0,t1,t2);}
t3=C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub607(C_SCHEME_UNDEFINED,t3));}

/* set-signal-mask! in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4837(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4837,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,lf[240]);
t4=C_sigemptyset(C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4842,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp);
t6=t2;
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4848,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4860,a[2]=t9,a[3]=t5,a[4]=((C_word)li119),tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_4860(t11,t7,t6);}

/* f_4842 in set-signal-mask! in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4842(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4842,3,t0,t1,t2);}
t3=C_i_check_exact_2(t2,lf[240]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_sigaddset(t2));}

/* k4846 in set-signal-mask! in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_sigprocmask_set(C_fix(0));
if(C_truep(C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm:960: posix-error */
t3=lf[1];
f_2617(5,t3,((C_word*)t0)[2],lf[120],lf[240],lf[241]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5648 in k5646 in loop */
static void C_ccall f_5649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1318: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_5629(2,t2,((C_word*)t0)[3]);}

/* k5646 in loop */
static void C_ccall f_5647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1317: ##sys#thread-yield! */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[333]+1)))(2,*((C_word*)lf[333]+1),t2);}

/* k7210 in doloop1877 in k7165 in doloop1873 in k7150 in k7148 in process-execute in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in ... */
static void C_ccall f_7212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t5=((C_word*)((C_word*)t0)[4])[1];
f_7195(t5,((C_word*)t0)[5],t3,t4);}

/* k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5436,2,t0,t1);}
t2=C_mutate((C_word*)lf[318]+1 /* (set! process-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[319]+1 /* (set! create-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5438,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5469,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=C_fixnum_plus(C_fix((C_word)FILENAME_MAX),C_fix(1));
/* ##sys#make-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[66]+1)))(4,*((C_word*)lf[66]+1),t4,t5,C_make_character(32));}

/* create-symbolic-link in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5438,4,t0,t1,t2,t3);}
t4=C_i_check_string_2(t2,lf[319]);
t5=C_i_check_string_2(t3,lf[319]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5457,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5466,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1255: ##sys#expand-home-path */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t7,t2);}

/* f_3804 in process-wait in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3804,2,t0,t1);}
/* posix-common.scm:520: ##sys#process-wait */
t2=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* f_3809 in process-wait in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3809,5,t0,t1,t2,t3,t4);}
t5=C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
/* posix-common.scm:522: posix-error */
t6=lf[1];
f_2617(6,t6,t1,lf[120],lf[118],lf[121],((C_word*)t0)[2]);}
else{
/* posix-common.scm:523: values */
C_values(5,0,t1,t2,t3,t4);}}

/* file-execute-access? in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5414(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5414,3,t0,t1,t2);}
/* posixunix.scm:1220: check */
f_5382(t1,t2,C_fix((C_word)X_OK),lf[315]);}

/* k6110 */
static void C_ccall f_6111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1469: on-close */
t2=((C_word*)t0)[2];
((C_proc2)C_fast_retrieve_proc(t2))(2,t2,((C_word*)t0)[3]);}

/* k5423 in create-session in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* loop in signal-mask in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_4886(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4886,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_i_car(t2);
t5=t2;
t6=C_u_i_cdr(t5);
if(C_truep(C_sigismember(t4))){
t7=C_a_i_cons(&a,2,t4,t3);
/* posixunix.scm:967: loop */
t11=t1;
t12=t6;
t13=t7;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
t7=t3;
/* posixunix.scm:967: loop */
t11=t1;
t12=t6;
t13=t7;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}

/* create-session in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5420,2,t0,t1);}
t2=C_setsid(C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5424,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5429,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1225: ##sys#update-errno */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* f_6103 in k6088 in k6024 in custom-output-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6103,2,t0,t1);}
if(C_truep(C_slot(((C_word*)((C_word*)t0)[2])[1],C_fix(8)))){
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6111,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_close(((C_word*)t0)[4]);
if(C_truep(C_fixnum_lessp(t3,C_fix(0)))){
/* posixunix.scm:1468: posix-error */
t4=lf[1];
f_2617(7,t4,t2,lf[8],((C_word*)t0)[5],lf[349],((C_word*)t0)[4],((C_word*)t0)[6]);}
else{
/* posixunix.scm:1469: on-close */
t4=((C_word*)t0)[3];
((C_proc2)C_fast_retrieve_proc(t4))(2,t4,t1);}}}

/* signal-mask in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4880,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4886,a[2]=t3,a[3]=((C_word)li121),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4886(t5,t1,*((C_word*)lf[239]+1),C_SCHEME_END_OF_LIST);}

/* k5428 in create-session in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1226: ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[316],lf[317]);}

/* k5685 in k5677 in loop */
static void C_ccall f_5686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_set_block_item(((C_word*)t0)[4],0,C_fix(0));
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5680 in k5677 in loop */
static void C_ccall f_5681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1328: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_5629(2,t2,((C_word*)t0)[3]);}

/* k3492 in k3485 in k3386 in loop in k3368 in k3362 in k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posix-common.scm:422: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3371(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* read-symbolic-link in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5470(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_5470r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5470r(t0,t1,t2,t3);}}

static void C_ccall f_5470r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(9);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=C_i_check_string_2(t2,lf[322]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5480,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5509,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1268: ##sys#expand-home-path */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t8,t2);}

/* k3498 in k3362 in k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posix-common.scm:406: glob */
t2=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6166 in loop */
static void C_ccall f_6167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
/* posixunix.scm:1452: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6158(t3,((C_word*)t0)[4],((C_word*)t0)[5],C_fix(0),((C_word*)t0)[6]);}

/* k5479 in read-symbolic-link in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5480,2,t0,t1);}
t2=C_do_readlink(t1,((C_word*)t0)[2]);
if(C_truep(C_fixnum_lessp(t2,C_fix(0)))){
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* posixunix.scm:1272: posix-error */
t3=lf[1];
f_2617(6,t3,((C_word*)t0)[4],lf[8],lf[322],lf[323],((C_word*)t0)[5]);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5494,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1273: substring */
t4=*((C_word*)lf[325]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],C_fix(0),t2);}}

/* _exit in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6859(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_6859r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6859r(t0,t1,t2);}}

static void C_ccall f_6859r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
if(C_truep(C_i_pairp(t2))){
t3=t2;
t4=C_u_i_car(t3);
/* posixunix.scm:1686: ex0 */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}
else{
/* posixunix.scm:1686: ex0 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,C_fix(0));}}

/* f_4742 in k4731 in with-input-from-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4747,a[2]=((C_word*)t0)[2],a[3]=((C_word)li108),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:864: ##sys#call-with-values */
C_call_with_values(4,0,t1,((C_word*)t0)[3],t2);}

/* f_6854 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6854(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6854,3,t0,t1,t2);}
t3=C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub1736(C_SCHEME_UNDEFINED,t3));}

/* f_4747 */
static void C_ccall f_4747(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4747r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4747r(t0,t1,t2);}}

static void C_ccall f_4747r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4750,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:866: close-input-pipe */
t4=*((C_word*)lf[200]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_6158(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6158,NULL,5,t0,t1,t2,t3,t4);}
t5=C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6167,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm:1450: poke */
t7=((C_word*)((C_word*)t0)[5])[1];
f_6027(t7,t6,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
if(C_truep(C_fixnum_lessp(t2,t4))){
t6=C_substring_copy(((C_word*)t0)[7],((C_word*)t0)[6],t3,t2,((C_word*)((C_word*)t0)[2])[1]);
t7=C_fixnum_difference(t4,t2);
/* posixunix.scm:1455: loop */
t13=t1;
t14=C_fix(0);
t15=t2;
t16=t7;
t1=t13;
t2=t14;
t3=t15;
t4=t16;
goto loop;}
else{
t6=C_substring_copy(((C_word*)t0)[7],((C_word*)t0)[6],t3,t4,((C_word*)((C_word*)t0)[2])[1]);
t7=C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t4);
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}}

/* f_4755 in k4731 in with-input-from-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4755,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[209]+1));
t3=C_mutate((C_word*)lf[209]+1 /* (set! ##sys#standard-input ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* local-timezone-abbreviation in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6846,2,t0,t1);}
t2=C_a_i_bytevector(&a,1,C_fix(3));
t3=stub1730(t2);
/* posixunix.scm:1670: ##sys#peek-c-string */
t4=*((C_word*)lf[0]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,C_fix(0));}

/* k6839 in k6834 in utc-time->seconds in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm:1666: ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[394],lf[395],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* k4749 */
static void C_ccall f_4750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k6141 in k6024 in custom-output-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6142,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[2];
f_6090(t4,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6143,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word)li173),tmp=(C_word)a,a+=7,tmp));}

/* f_6143 in k6141 in k6024 in custom-output-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6143,3,t0,t1,t2);}
if(C_truep(t2)){
t3=C_fixnum_difference(((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t4=C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6158,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word)li172),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_6158(t8,t1,t3,C_fix(0),t4);}
else{
if(C_truep(C_fixnum_lessp(C_fix(0),((C_word*)((C_word*)t0)[3])[1]))){
/* posixunix.scm:1460: poke */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6027(t3,t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}

/* k6834 in utc-time->seconds in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6835,2,t0,t1);}
t2=C_a_timegm(&a,1,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1665: fp= */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[110],t2);}

/* k4763 in with-output-to-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4764,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4769,a[2]=t5,a[3]=t3,a[4]=((C_word)li112),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4774,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word)li114),tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4787,a[2]=t3,a[3]=t5,a[4]=((C_word)li115),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:869: ##sys#dynamic-wind */
t9=*((C_word*)lf[87]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[3],t6,t7,t8);}

/* process-signal in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7317(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7317r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7317r(t0,t1,t2,t3);}}

static void C_ccall f_7317r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7321,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(t3))){
t5=t3;
t6=t4;
f_7321(t6,C_u_i_car(t5));}
else{
t5=t4;
f_7321(t5,C_fix((C_word)SIGTERM));}}

/* f_4769 in k4763 in with-output-to-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4769,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[211]+1));
t3=C_mutate((C_word*)lf[211]+1 /* (set! ##sys#standard-output ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* utc-time->seconds in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6831(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6831,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6835,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1663: check-time-vector */
f_3583(t3,lf[394],t2);}

/* with-output-to-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_4760r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4760r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4760r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4764,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t5,*((C_word*)lf[199]+1),t2,t4);}

/* k7611 in for-each-loop2038 */
static void C_ccall f_7612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7603(t3,((C_word*)t0)[4],t2);}

/* sleep in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7310(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7310,3,t0,t1,t2);}
t3=C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub1913(C_SCHEME_UNDEFINED,t3));}

/* f_6130 in k6024 in custom-output-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6130(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6130,3,t0,t1,t2);}
if(C_truep(t2)){
t3=C_block_size(t2);
/* posixunix.scm:1443: poke */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6027(t4,t1,t2,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f_4774 in k4763 in with-output-to-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4779,a[2]=((C_word*)t0)[2],a[3]=((C_word)li113),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:872: ##sys#call-with-values */
C_call_with_values(4,0,t1,((C_word*)t0)[3],t2);}

/* f_4779 */
static void C_ccall f_4779(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4779r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4779r(t0,t1,t2);}}

static void C_ccall f_4779r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4782,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:874: close-output-pipe */
t4=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* f_7286 in process-wait in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7286,2,t0,t1);}
/* posixunix.scm:1814: ##sys#process-wait */
t2=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* for-each-loop2038 */
static void C_fcall f_7603(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7603,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7612,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* posixunix.scm:1954: g2039 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4700 */
static void C_ccall f_4701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k6894 in k6886 in k6884 in k6882 in set-buffering-mode! in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_6896(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm:1709: ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[2],lf[399],lf[400],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* call-with-output-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4706(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_4706r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4706r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4706r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4710,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t5,*((C_word*)lf[199]+1),t2,t4);}

/* ##sys#process-wait in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7270(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7270,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?C_fix((C_word)WNOHANG):C_fix(0));
t5=C_waitpid(t2,t4);
t6=C_WIFEXITED(C_fix((C_word)C_wait_status));
t7=C_eqp(t5,C_fix(-1));
t8=(C_truep(t7)?C_eqp(C_fix((C_word)errno),C_fix((C_word)EINTR)):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7286,a[2]=t2,a[3]=t3,a[4]=((C_word)li226),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1813: ##sys#dispatch-interrupt */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[337]+1)))(3,*((C_word*)lf[337]+1),t1,t9);}
else{
if(C_truep(t6)){
t9=C_WEXITSTATUS(C_fix((C_word)C_wait_status));
/* posixunix.scm:1815: values */
C_values(5,0,t1,t5,t6,t9);}
else{
if(C_truep(C_WIFSIGNALED(C_fix((C_word)C_wait_status)))){
t9=C_WTERMSIG(C_fix((C_word)C_wait_status));
/* posixunix.scm:1815: values */
C_values(5,0,t1,t5,t6,t9);}
else{
t9=C_WSTOPSIG(C_fix((C_word)C_wait_status));
/* posixunix.scm:1815: values */
C_values(5,0,t1,t5,t6,t9);}}}}

/* f_3897 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3897,5,t0,t1,t2,t3,t4);}
t5=C_i_foreign_fixnum_argumentp(t2);
t6=C_i_foreign_fixnum_argumentp(t3);
t7=C_i_foreign_integer_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,stub651(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* k6884 in k6882 in set-buffering-mode! in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_6885(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6885,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6888,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_eqp(t2,lf[401]);
if(C_truep(t4)){
t5=t3;
f_6888(2,t5,C_fix((C_word)_IOFBF));}
else{
t5=C_eqp(t2,lf[402]);
if(C_truep(t5)){
t6=C_fix((C_word)_IOLBF);
t7=t3;
f_6888(2,t7,t6);}
else{
t6=C_eqp(t2,lf[403]);
if(C_truep(t6)){
t7=t3;
f_6888(2,t7,C_fix((C_word)_IONBF));}
else{
/* posixunix.scm:1703: ##sys#error */
t7=*((C_word*)lf[41]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t3,lf[399],lf[404],((C_word*)t0)[2],((C_word*)t0)[4]);}}}}

/* k6882 in set-buffering-mode! in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[5]))){
t3=((C_word*)t0)[5];
t4=t2;
f_6885(t4,C_u_i_car(t3));}
else{
t3=t2;
f_6885(t3,C_fix((C_word)BUFSIZ));}}

/* k4709 in call-with-output-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4715,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word)li104),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4720,a[2]=t1,a[3]=((C_word)li105),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:854: ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],t2,t3);}

/* k6886 in k6884 in k6882 in set-buffering-mode! in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6888,2,t0,t1);}
t2=C_i_check_exact_2(((C_word*)t0)[2],lf[399]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6896,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[4],C_fix(7));
t5=C_eqp(lf[51],t4);
if(C_truep(t5)){
t6=C_setvbuf(((C_word*)t0)[4],t1,((C_word*)t0)[2]);
t7=t3;
f_6896(t7,C_fixnum_lessp(t6,C_fix(0)));}
else{
t6=t3;
f_6896(t6,C_SCHEME_TRUE);}}

/* f_4715 in k4709 in call-with-output-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4715,2,t0,t1);}
/* posixunix.scm:855: proc */
t2=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[3]);}

/* set-alarm! in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6872(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6872,3,t0,t1,t2);}
t3=C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub1742(C_SCHEME_UNDEFINED,t3));}

/* set-buffering-mode! in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6879r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6879r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6879r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6883,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm:1697: ##sys#check-port */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[355]+1)))(4,*((C_word*)lf[355]+1),t5,t2,lf[399]);}

/* parent-process-id in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7306,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,stub1909(C_SCHEME_UNDEFINED));}

/* k7228 in doloop1873 in k7150 in k7148 in process-execute in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t5=((C_word*)((C_word*)t0)[4])[1];
f_7157(t5,((C_word*)t0)[5],t3,t4);}

/* k5113 in k5104 in loop in k5095 in k5092 in k5081 in group-information in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5114,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k7626 in k7624 */
static void C_ccall f_7627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7632,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li255),tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm:1962: ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[7],t2,((C_word*)t0)[8]);}

/* k7624 */
static void C_ccall f_7625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm:1961: chkstrlst */
t3=((C_word*)t0)[9];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_7627(2,t3,C_SCHEME_UNDEFINED);}}

/* k7320 in process-signal in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_7321(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_i_check_exact_2(((C_word*)t0)[2],lf[423]);
t3=C_i_check_exact_2(t1,lf[423]);
t4=C_kill(((C_word*)t0)[2],t1);
t5=C_eqp(t4,C_fix(-1));
if(C_truep(t5)){
/* posixunix.scm:1833: posix-error */
t6=lf[1];
f_2617(7,t6,((C_word*)t0)[3],lf[120],lf[423],lf[424],((C_word*)t0)[2],t1);}
else{
t6=C_SCHEME_UNDEFINED;
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k7398 */
static void C_ccall f_7399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1875: file-close */
t2=*((C_word*)lf[164]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* process* in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7695(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_7695r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7695r(t0,t1,t2,t3);}}

static void C_ccall f_7695r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t8=C_i_nullp(t7);
t9=(C_truep(t8)?C_SCHEME_FALSE:C_i_car(t7));
if(C_truep(C_i_nullp(t7))){
/* posixunix.scm:1972: %process */
t10=((C_word*)t0)[2];
((C_proc8)(void*)(*((C_word*)t10+1)))(8,t10,t1,lf[435],C_SCHEME_TRUE,t2,t5,t9,*((C_word*)lf[436]+1));}
else{
t10=C_i_cdr(t7);
/* posixunix.scm:1972: %process */
t11=((C_word*)t0)[2];
((C_proc8)(void*)(*((C_word*)t11+1)))(8,t11,t1,lf[435],C_SCHEME_TRUE,t2,t5,t9,*((C_word*)lf[436]+1));}}

/* f_7391 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7391,5,t0,t1,t2,t3,t4);}
t5=C_eqp(t4,t3);
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7399,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1874: duplicate-fileno */
t7=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,t4);}}

/* ##sys#shell-command-arguments in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7349(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7349,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list2(&a,2,lf[430],t2));}

/* string->time in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6802(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6802r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6802r(t0,t1,t2,t3);}}

static void C_ccall f_6802r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(5);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?lf[393]:C_i_car(t3));
t6=C_i_check_string_2(t2,lf[392]);
t7=C_i_check_string_2(t5,lf[392]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6817,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1660: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t8,t2,lf[392]);}

/* f_6800 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6800,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,stub1706(C_SCHEME_UNDEFINED,t2,t3,t4));}

/* ##sys#shell-command in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7344,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1836: get-environment-variable */
t3=*((C_word*)lf[427]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[428]);}

/* f_6123 in k6088 in k6024 in custom-output-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6123,2,t0,t1);}
/* posixunix.scm:1471: store */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_fast_retrieve_proc(t2))(3,t2,t1,C_SCHEME_FALSE);}

/* k7343 in shell-command in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[426]);}}

/* k5104 in loop in k5095 in k5092 in k5081 in group-information in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5105,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5114,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm:1096: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5101(t4,t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k6816 in string->time in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6820,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1660: ##sys#make-c-string */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,((C_word*)t0)[4]);}

/* loop in k5095 in k5092 in k5081 in group-information in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_5101(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5101,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5105,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=C_a_i_bytevector(&a,1,C_fix(3));
t6=C_i_foreign_fixnum_argumentp(t4);
t7=stub1130(t5,t6);
/* posixunix.scm:1079: ##sys#peek-c-string */
t8=*((C_word*)lf[0]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* f_4787 in k4763 in with-output-to-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4787,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[211]+1));
t3=C_mutate((C_word*)lf[211]+1 /* (set! ##sys#standard-output ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k4781 */
static void C_ccall f_4782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5152 in k5150 in get-groups in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5155,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_foreign_fixnum_argumentp(((C_word*)t0)[2]);
t4=stub1158(C_SCHEME_UNDEFINED,t3);
if(C_truep(C_fixnum_lessp(t4,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5182,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1118: ##sys#update-errno */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t5);}
else{
t5=t2;
f_5155(2,t5,C_SCHEME_UNDEFINED);}}

/* k5150 in get-groups in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5153,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_foreign_fixnum_argumentp(((C_word*)t0)[2]);
if(C_truep(stub1163(C_SCHEME_UNDEFINED,t3))){
t4=t2;
f_5153(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm:1116: ##sys#error */
t4=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[261],lf[263]);}}

/* k5154 in k5152 in k5150 in get-groups in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5155,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5160,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li132),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5160(t5,((C_word*)t0)[3],C_fix(0));}

/* k4795 in create-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:884: values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* create-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4796,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=C_pipe(C_SCHEME_FALSE);
if(C_truep(C_fixnum_lessp(t3,C_fix(0)))){
/* posixunix.scm:883: posix-error */
t4=lf[1];
f_2617(5,t4,t2,lf[8],lf[212],lf[213]);}
else{
/* posixunix.scm:884: values */
C_values(4,0,t1,C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}}

/* k7360 in k7358 in process-run in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7361,2,t0,t1);}
t2=C_eqp(C_fix(0),t1);
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[2])){
/* posixunix.scm:1846: process-execute */
t3=*((C_word*)lf[419]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7379,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1848: ##sys#shell-command */
t4=*((C_word*)lf[425]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}
else{
t3=t1;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* loop in k5154 in k5152 in k5150 in get-groups in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_5160(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5160,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_get_gid(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5174,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm:1123: loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* process in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7651(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_7651r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7651r(t0,t1,t2,t3);}}

static void C_ccall f_7651r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(3);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t8=C_i_nullp(t7);
t9=(C_truep(t8)?C_SCHEME_FALSE:C_i_car(t7));
t10=C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:C_i_cdr(t7));
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7666,a[2]=((C_word)li257),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1967: %process */
t13=((C_word*)t0)[2];
((C_proc8)(void*)(*((C_word*)t13+1)))(8,t13,t1,lf[434],C_SCHEME_FALSE,t2,t5,t9,t12);}

/* k7647 in k7643 */
static void C_ccall f_7649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_7625(2,t3,t2);}

/* k7643 */
static void C_ccall f_7645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7645,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7649,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1960: ##sys#shell-command */
t4=*((C_word*)lf[425]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* get-groups in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5147,2,t0,t1);}
t2=C_fix((C_word)getgroups(0, C_groups));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5151,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5199,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1113: ##sys#update-errno */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t4);}
else{
t4=t3;
f_5151(2,t4,C_SCHEME_UNDEFINED);}}

/* k7381 in k7378 in k7360 in k7358 in process-run in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1848: process-execute */
t2=*((C_word*)lf[419]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k7378 in k7360 in k7358 in process-run in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7382,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1848: ##sys#shell-command-arguments */
t3=*((C_word*)lf[429]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_7632 in k7626 in k7624 */
static void C_ccall f_7632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7632,2,t0,t1);}
/* posixunix.scm:1963: ##sys#process */
t2=*((C_word*)lf[433]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[6]);}

/* k5198 in get-groups in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1114: ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[261],lf[264]);}

/* k6819 in k6816 in string->time in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6820,2,t0,t1);}
t2=C_a_i_vector(&a,10,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
/* posixunix.scm:1660: strptime */
t3=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[4],t1,t2);}

/* k5173 in loop in k5154 in k5152 in k5150 in get-groups in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5174,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k7075 in k7056 in process-fork in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7078,a[2]=((C_word)li217),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1759: g1818 */
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],C_fix(0));}

/* f_7078 in k7075 in k7056 in process-fork in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7078(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7078,3,t0,t1,t2);}
t3=C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub1821(C_SCHEME_UNDEFINED,t3));}

/* k5181 in k5152 in k5150 in get-groups in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1119: ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[261],lf[262]);}

/* k4630 in open-output-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:820: check */
f_4568(((C_word*)t0)[3],lf[199],((C_word*)t0)[4],C_SCHEME_FALSE,t1);}

/* k4637 in open-output-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4638,2,t0,t1);}
t2=open_text_output_pipe(&a,1,t1);
/* posixunix.scm:820: check */
f_4568(((C_word*)t0)[3],lf[199],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* f_5836 in k5582 in k5578 in custom-input-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5836,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t5,a[8]=((C_word)li162),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_5841(t7,t1,C_SCHEME_FALSE);}

/* k4600 in open-input-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4601,2,t0,t1);}
t2=open_text_input_pipe(&a,1,t1);
/* posixunix.scm:809: check */
f_4568(((C_word*)t0)[3],lf[195],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* f_7666 in process in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7666,6,t0,t1,t2,t3,t4,t5);}
/* posixunix.scm:1969: values */
C_values(5,0,t1,t2,t3,t4);}

/* k7358 in process-run in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_7359(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7359,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7361,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1844: process-fork */
t3=*((C_word*)lf[416]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5818 in loop in k5774 */
static void C_ccall f_5819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_eqp(C_fix(0),((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* posixunix.scm:1374: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_5778(t3,((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[7]);}}

/* process-run in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7355(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7355r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7355r(t0,t1,t2,t3);}}

static void C_ccall f_7355r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7359,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(t3))){
t5=t3;
t6=t4;
f_7359(t6,C_u_i_car(t5));}
else{
t5=t4;
f_7359(t5,C_SCHEME_FALSE);}}

/* k3604 in seconds->local-time in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_check_number_2(t1,lf[101]);
/* posix-common.scm:458: ##sys#decode-seconds */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[102]+1)))(4,*((C_word*)lf[102]+1),((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* seconds->local-time in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3601(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3601r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3601r(t0,t1,t2);}}

static void C_ccall f_3601r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3606,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t2))){
/* posix-common.scm:456: current-seconds */
t4=*((C_word*)lf[103]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_i_car(t2);
t5=C_i_check_number_2(t4,lf[101]);
/* posix-common.scm:458: ##sys#decode-seconds */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[102]+1)))(4,*((C_word*)lf[102]+1),t1,t4,C_SCHEME_FALSE);}}

/* k7024 in k7009 in terminal-size in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_eqp(C_fix(0),t1);
if(C_truep(t2)){
/* posixunix.scm:1740: values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[3]))),C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[4]))));}
else{
/* posixunix.scm:1741: posix-error */
t3=lf[1];
f_2617(6,t3,((C_word*)t0)[2],lf[410],lf[409],lf[411],((C_word*)t0)[5]);}}

/* k7028 in k7009 in terminal-size in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7032,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm:1739: ##sys#make-locative */
((C_proc6)C_fast_retrieve_proc(*((C_word*)lf[412]+1)))(6,*((C_word*)lf[412]+1),t2,((C_word*)t0)[5],C_fix(0),C_SCHEME_FALSE,lf[413]);}

/* f_3714 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3714(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_3714r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3714r(t0,t1,t2,t3);}}

static void C_ccall f_3714r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3721,a[2]=t5,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* posix-common.scm:484: check-time-vector */
f_3583(t6,lf[111],t2);}

/* k3727 in k3720 */
static void C_ccall f_3728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posix-common.scm:489: ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[111],lf[112],((C_word*)t0)[3]);}}

/* k7009 in terminal-size in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7010,2,t0,t1);}
t2=C_a_i_bytevector(&a,1,C_fix(1));
t3=C_a_i_bytevector(&a,1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7025,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=C_C_fileno(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7029,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm:1738: ##sys#make-locative */
((C_proc6)C_fast_retrieve_proc(*((C_word*)lf[412]+1)))(6,*((C_word*)lf[412]+1),t6,t2,C_fix(0),C_SCHEME_FALSE,lf[413]);}

/* k5848 */
static void C_ccall f_5849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5849,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_eqp(((C_word*)t0)[4],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm:1393: fetch */
t5=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_slot(((C_word*)t0)[8],C_fix(4));
t5=C_fixnum_plus(t4,C_fix(1));
t6=C_i_set_i_slot(((C_word*)t0)[8],C_fix(4),t5);
t7=C_i_set_i_slot(((C_word*)t0)[8],C_fix(5),C_fix(0));
/* posixunix.scm:1398: values */
C_values(4,0,((C_word*)t0)[6],t1,C_SCHEME_FALSE);}}

/* k3720 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3721,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=C_i_check_string_2(((C_word*)t0)[2],lf[111]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3728,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3737,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posix-common.scm:488: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t4,((C_word*)t0)[2],lf[111]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3739,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posix-common.scm:490: asctime */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}}

/* loop */
static void C_fcall f_5841(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5841,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word)li159),tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[3])[1]))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5910,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word)li160),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5915,a[2]=((C_word*)t0)[7],a[3]=((C_word)li161),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1400: ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm:1406: fetch */
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* f_5844 in loop */
static void C_ccall f_5844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5844,4,t0,t1,t2,t3);}
t4=C_fixnum_difference(t2,((C_word*)((C_word*)t0)[2])[1]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5849,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t6=C_eqp(C_fix(0),t4);
if(C_truep(t6)){
t7=((C_word*)t0)[6];
t8=t5;
f_5849(2,t8,(C_truep(t7)?t7:lf[342]));}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5885,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm:1383: ##sys#make-string */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[66]+1)))(3,*((C_word*)lf[66]+1),t7,t4);}}

/* k5124 in group-information in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5082(t2,C_getgrnam(t1));}

/* close-input-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4656(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4656,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4660,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:829: ##sys#check-input-port */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[202]+1)))(5,*((C_word*)lf[202]+1),t3,t2,C_SCHEME_TRUE,lf[200]);}

/* terminal-size in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7006(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7006,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7010,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1733: ##sys#terminal-check */
f_6955(t3,lf[409],t2);}

/* k5857 in k5848 */
static void C_ccall f_5858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_lessp(((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[3])[1]);
/* posixunix.scm:1394: values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[5],t2);}

/* f_3708 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3708,4,t0,t1,t2,t3);}
t4=C_a_i_bytevector(&a,1,C_fix(3));
t5=stub507(t4,t2,t3);
/* posix-common.scm:482: ##sys#peek-c-string */
t6=*((C_word*)lf[0]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,C_fix(0));}

/* f_3643 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3643(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3643,3,t0,t1,t2);}
t3=C_a_i_bytevector(&a,1,C_fix(3));
t4=C_i_foreign_integer_argumentp(t2);
t5=stub476(t3,t4);
/* posix-common.scm:465: ##sys#peek-c-string */
t6=*((C_word*)lf[0]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,C_fix(0));}

/* f_3702 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3702(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3702,3,t0,t1,t2);}
t3=C_a_i_bytevector(&a,1,C_fix(3));
t4=stub501(t3,t2);
/* posix-common.scm:481: ##sys#peek-c-string */
t5=*((C_word*)lf[0]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,C_fix(0));}

/* k6092 in k6088 in k6024 in custom-output-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6094,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6096,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1472: set-port-name! */
t4=*((C_word*)lf[340]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[4]);}

/* k6088 in k6024 in custom-output-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_6090(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6090,NULL,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6094,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6098,a[2]=((C_word*)t0)[2],a[3]=((C_word)li168),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6103,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word)li169),tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6123,a[2]=((C_word*)t0)[2],a[3]=((C_word)li170),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1462: make-output-port */
t9=*((C_word*)lf[350]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t5,t6,t7,t8);}

/* seconds->string in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3652(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3652r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3652r(t0,t1,t2);}}

static void C_ccall f_3652r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3657,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t2))){
/* posix-common.scm:466: current-seconds */
t4=*((C_word*)lf[103]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=t3;
f_3657(2,t4,C_i_car(t2));}}

/* k3655 in seconds->string in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3657,2,t0,t1);}
t2=C_i_check_number_2(t1,lf[105]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3661,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posix-common.scm:468: ctime */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k3294 in k3288 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3295,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3297,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li32),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_3297(t5,((C_word*)t0)[6],t1);}

/* k6080 in loop in poke in k6024 in custom-output-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_difference(((C_word*)t0)[2],((C_word*)t0)[3]);
/* posixunix.scm:1437: poke */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6027(t3,((C_word*)t0)[5],t1,t2);}

/* loop in k3294 in k3288 */
static void C_fcall f_3297(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3297,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_i_cdr(((C_word*)t0)[2]);
/* posix-common.scm:382: conc-loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3267(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3312,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_i_car(t2);
/* posix-common.scm:383: irregex-match */
t5=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[6],t4);}}

/* process-fork in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7053(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_7053r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7053r(t0,t1,t2);}}

static void C_ccall f_7053r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7057,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1761: fork */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* f_7051 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7051,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,stub1808(C_SCHEME_UNDEFINED));}

/* k4687 in call-with-input-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4693,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word)li101),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4698,a[2]=t1,a[3]=((C_word)li102),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:845: ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],t2,t3);}

/* k7056 in process-fork in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7057,2,t0,t1);}
t2=C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm:1762: posix-error */
t3=lf[1];
f_2617(5,t3,((C_word*)t0)[2],lf[120],lf[416],lf[417]);}
else{
t3=C_i_pairp(((C_word*)t0)[3]);
t4=(C_truep(t3)?C_eqp(t1,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7077,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1759: g1816 */
t7=t5;
((C_proc2)C_fast_retrieve_proc(t7))(2,t7,t6);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}}}

/* k6300 in k6296 in setup in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_6301(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6301,NULL,2,t0,t1);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=(C_truep(t2)?C_fix((C_word)F_RDLCK):C_fix((C_word)F_WRLCK));
t4=C_flock_setup(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[354],((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]));}

/* call-with-input-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_4684r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4684r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4684r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4688,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t5,*((C_word*)lf[195]+1),t2,t4);}

/* set-signal-handler! in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3762(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3762,4,t0,t1,t2,t3);}
t4=C_i_check_exact_2(t2,lf[114]);
if(C_truep(t3)){
t5=t2;
t6=C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_i_vector_set(*((C_word*)lf[115]+1),t2,t3));}
else{
t5=C_establish_signal_handler(t2,C_SCHEME_FALSE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_vector_set(*((C_word*)lf[115]+1),t2,t3));}}

/* seconds->utc-time in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3622(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3622r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3622r(t0,t1,t2);}}

static void C_ccall f_3622r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3627,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t2))){
/* posix-common.scm:460: current-seconds */
t4=*((C_word*)lf[103]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_i_car(t2);
t5=C_i_check_number_2(t4,lf[104]);
/* posix-common.scm:462: ##sys#decode-seconds */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[102]+1)))(4,*((C_word*)lf[102]+1),t1,t4,C_SCHEME_TRUE);}}

/* f_6098 in k6088 in k6024 in custom-output-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6098(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6098,3,t0,t1,t2);}
/* posixunix.scm:1464: store */
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_fast_retrieve_proc(t3))(3,t3,t1,t2);}

/* k6095 in k6092 in k6088 in k6024 in custom-output-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k5884 */
static void C_ccall f_5885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_substring_copy(((C_word*)t0)[2],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[4],C_fix(0));
t3=C_slot(((C_word*)t0)[5],C_fix(5));
t4=C_fixnum_plus(t3,((C_word*)t0)[6]);
t5=C_i_set_i_slot(((C_word*)t0)[5],C_fix(5),t4);
if(C_truep(((C_word*)t0)[7])){
/* posixunix.scm:1389: ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[343]+1)))(4,*((C_word*)lf[343]+1),((C_word*)t0)[8],((C_word*)t0)[7],t1);}
else{
t6=t1;
t7=((C_word*)t0)[8];
f_5849(2,t7,t6);}}

/* k3625 in seconds->utc-time in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_check_number_2(t1,lf[104]);
/* posix-common.scm:462: ##sys#decode-seconds */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[102]+1)))(4,*((C_word*)lf[102]+1),((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k3738 in k3720 */
static void C_ccall f_3739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_block_size(t1);
t3=C_fixnum_difference(t2,C_fix(1));
/* posix-common.scm:492: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),((C_word*)t0)[2],t1,C_fix(0),t3);}
else{
/* posix-common.scm:493: ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[111],lf[113],((C_word*)t0)[3]);}}

/* k3736 in k3720 */
static void C_ccall f_3737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posix-common.scm:488: strftime */
t2=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k7862 */
static void C_ccall f_7863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1012: ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[447],lf[453],((C_word*)t0)[3]);}

/* k7043 in get-host-name in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7046,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
/* posixunix.scm:1752: posix-error */
t3=lf[1];
f_2617(5,t3,t2,lf[410],lf[414],lf[415]);}}

/* k7045 in k7043 in get-host-name in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* f_7869 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7869(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7869,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7872,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7883,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:743: port? */
t5=*((C_word*)lf[182]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* get-host-name in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7044,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1750: getit */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4609 in open-input-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4610,2,t0,t1);}
t2=open_binary_input_pipe(&a,1,t1);
/* posixunix.scm:809: check */
f_4568(((C_word*)t0)[3],lf[195],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* open-output-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4619(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_4619r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4619r(t0,t1,t2,t3);}}

static void C_ccall f_4619r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t4=C_i_check_string_2(t2,lf[199]);
t5=C_i_pairp(t3);
t6=(C_truep(t5)?C_slot(t3,C_fix(0)):lf[196]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4632,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=C_eqp(t6,lf[196]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4638,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:824: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t9,t2,lf[199]);}
else{
t9=C_eqp(t6,lf[197]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4647,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:825: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t10,t2,lf[199]);}
else{
/* posixunix.scm:798: ##sys#error */
t10=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,lf[198],t6);}}}

/* f_7852 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7852,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,stub1089(C_SCHEME_UNDEFINED));}

/* f_7034 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7034,2,t0,t1);}
t2=C_a_i_bytevector(&a,1,C_fix(3));
t3=stub1801(t2);
/* posixunix.scm:1746: ##sys#peek-c-string */
t4=*((C_word*)lf[0]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,C_fix(0));}

/* k4661 in k4659 in close-input-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* f_7855 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7855(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7855,3,t0,t1,t2);}
t3=C_setuid(t2);
if(C_truep(C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7863,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1011: ##sys#update-errno */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t4);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k7031 in k7028 in k7009 in terminal-size in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1737: ttysize */
t2=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* k4659 in close-input-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4660,2,t0,t1);}
t2=close_pipe(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4662,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm:832: posix-error */
t5=lf[1];
f_2617(6,t5,t3,lf[8],lf[200],lf[201],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* local-time->seconds in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3687(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3687,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3691,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posix-common.scm:474: check-time-vector */
f_3583(t3,lf[107],t2);}

/* f_3574 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3574,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3576,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp));}

/* f_3576 */
static void C_ccall f_3576(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3576,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k3690 in local-time->seconds in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3691,2,t0,t1);}
t2=C_a_mktime(&a,1,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3697,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posix-common.scm:476: fp= */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[110],t2);}

/* k4673 in close-output-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4674,2,t0,t1);}
t2=close_pipe(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4676,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm:839: posix-error */
t5=lf[1];
f_2617(6,t5,t3,lf[8],lf[203],lf[204],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k4675 in k4673 in close-output-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k7845 */
static void C_ccall f_7846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1021: ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[450],lf[451],((C_word*)t0)[3]);}

/* close-output-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4670(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4670,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4674,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:836: ##sys#check-output-port */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[205]+1)))(5,*((C_word*)lf[205]+1),t3,t2,C_SCHEME_TRUE,lf[203]);}

/* k3695 in k3690 in local-time->seconds in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posix-common.scm:477: ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[107],lf[108],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3581,2,t0,t1);}
t2=C_mutate((C_word*)lf[98]+1 /* (set! file-creation-mode ...) */,t1);
t3=C_mutate(&lf[99] /* (set! check-time-vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3583,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[101]+1 /* (set! seconds->local-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3601,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[104]+1 /* (set! seconds->utc-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3622,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3643,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp);
t7=C_mutate((C_word*)lf[105]+1 /* (set! seconds->string ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3652,a[2]=t6,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp));
t8=C_mutate((C_word*)lf[107]+1 /* (set! local-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3687,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3702,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3708,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp);
t11=C_mutate((C_word*)lf[111]+1 /* (set! time->string ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3714,a[2]=t10,a[3]=t9,a[4]=((C_word)li60),tmp=(C_word)a,a+=5,tmp));
t12=C_mutate((C_word*)lf[114]+1 /* (set! set-signal-handler! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3762,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3776,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7906,a[2]=((C_word)li273),tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:504: getter-with-setter */
t15=*((C_word*)lf[442]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,*((C_word*)lf[114]+1));}

/* check-time-vector in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_3583(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3583,NULL,3,t1,t2,t3);}
t4=C_i_check_vector_2(t3,t2);
t5=C_block_size(t3);
if(C_truep(C_fixnum_lessp(t5,C_fix(10)))){
/* posix-common.scm:454: ##sys#error */
t6=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,lf[100],t3);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3660 in k3655 in seconds->string in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_block_size(t1);
t3=C_fixnum_difference(t2,C_fix(1));
/* posix-common.scm:470: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),((C_word*)t0)[2],t1,C_fix(0),t3);}
else{
/* posix-common.scm:471: ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[105],lf[106],((C_word*)t0)[3]);}}

/* f_7838 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7838(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7838,3,t0,t1,t2);}
t3=C_seteuid(t2);
if(C_truep(C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7846,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1020: ##sys#update-errno */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t4);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* f_7835 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7835,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,stub1094(C_SCHEME_UNDEFINED));}

/* k4646 in open-output-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4647,2,t0,t1);}
t2=open_binary_output_pipe(&a,1,t1);
/* posixunix.scm:820: check */
f_4568(((C_word*)t0)[3],lf[199],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* current-process-id in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3778,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fudge(C_fix(33)));}

/* k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word ab[67],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3776,2,t0,t1);}
t2=C_mutate((C_word*)lf[116]+1 /* (set! signal-handler ...) */,t1);
t3=C_mutate((C_word*)lf[117]+1 /* (set! current-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3778,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[118]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3784,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[122]+1 /* (set! ##sys#file-nonblocking! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3847,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[123]+1 /* (set! ##sys#file-select-one ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3854,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[124]+1 /* (set! pipe/buf ...) */,C_fix((C_word)PIPE_BUF));
t8=C_mutate((C_word*)lf[125]+1 /* (set! fcntl/dupfd ...) */,C_fix((C_word)F_DUPFD));
t9=C_mutate((C_word*)lf[126]+1 /* (set! fcntl/getfd ...) */,C_fix((C_word)F_GETFD));
t10=C_mutate((C_word*)lf[127]+1 /* (set! fcntl/setfd ...) */,C_fix((C_word)F_SETFD));
t11=C_mutate((C_word*)lf[128]+1 /* (set! fcntl/getfl ...) */,C_fix((C_word)F_GETFL));
t12=C_mutate((C_word*)lf[129]+1 /* (set! fcntl/setfl ...) */,C_fix((C_word)F_SETFL));
t13=C_mutate((C_word*)lf[130]+1 /* (set! open/rdonly ...) */,C_fix((C_word)O_RDONLY));
t14=C_mutate((C_word*)lf[131]+1 /* (set! open/wronly ...) */,C_fix((C_word)O_WRONLY));
t15=C_mutate((C_word*)lf[132]+1 /* (set! open/rdwr ...) */,C_fix((C_word)O_RDWR));
t16=C_mutate((C_word*)lf[133]+1 /* (set! open/read ...) */,C_fix((C_word)O_RDONLY));
t17=C_mutate((C_word*)lf[134]+1 /* (set! open/write ...) */,C_fix((C_word)O_WRONLY));
t18=C_mutate((C_word*)lf[135]+1 /* (set! open/creat ...) */,C_fix((C_word)O_CREAT));
t19=C_mutate((C_word*)lf[136]+1 /* (set! open/append ...) */,C_fix((C_word)O_APPEND));
t20=C_mutate((C_word*)lf[137]+1 /* (set! open/excl ...) */,C_fix((C_word)O_EXCL));
t21=C_mutate((C_word*)lf[138]+1 /* (set! open/noctty ...) */,C_fix((C_word)O_NOCTTY));
t22=C_mutate((C_word*)lf[139]+1 /* (set! open/nonblock ...) */,C_fix((C_word)O_NONBLOCK));
t23=C_mutate((C_word*)lf[140]+1 /* (set! open/trunc ...) */,C_fix((C_word)O_TRUNC));
t24=C_mutate((C_word*)lf[141]+1 /* (set! open/sync ...) */,C_fix((C_word)O_FSYNC));
t25=C_mutate((C_word*)lf[142]+1 /* (set! open/fsync ...) */,C_fix((C_word)O_FSYNC));
t26=C_mutate((C_word*)lf[143]+1 /* (set! open/binary ...) */,C_fix((C_word)O_BINARY));
t27=C_mutate((C_word*)lf[144]+1 /* (set! open/text ...) */,C_fix((C_word)O_TEXT));
t28=C_mutate((C_word*)lf[145]+1 /* (set! perm/irusr ...) */,C_fix((C_word)S_IRUSR));
t29=C_mutate((C_word*)lf[146]+1 /* (set! perm/iwusr ...) */,C_fix((C_word)S_IWUSR));
t30=C_mutate((C_word*)lf[147]+1 /* (set! perm/ixusr ...) */,C_fix((C_word)S_IXUSR));
t31=C_mutate((C_word*)lf[148]+1 /* (set! perm/irgrp ...) */,C_fix((C_word)S_IRGRP));
t32=C_mutate((C_word*)lf[149]+1 /* (set! perm/iwgrp ...) */,C_fix((C_word)S_IWGRP));
t33=C_mutate((C_word*)lf[150]+1 /* (set! perm/ixgrp ...) */,C_fix((C_word)S_IXGRP));
t34=C_mutate((C_word*)lf[151]+1 /* (set! perm/iroth ...) */,C_fix((C_word)S_IROTH));
t35=C_mutate((C_word*)lf[152]+1 /* (set! perm/iwoth ...) */,C_fix((C_word)S_IWOTH));
t36=C_mutate((C_word*)lf[153]+1 /* (set! perm/ixoth ...) */,C_fix((C_word)S_IXOTH));
t37=C_mutate((C_word*)lf[154]+1 /* (set! perm/irwxu ...) */,C_fix((C_word)S_IRWXU));
t38=C_mutate((C_word*)lf[155]+1 /* (set! perm/irwxg ...) */,C_fix((C_word)S_IRWXG));
t39=C_mutate((C_word*)lf[156]+1 /* (set! perm/irwxo ...) */,C_fix((C_word)S_IRWXO));
t40=C_mutate((C_word*)lf[157]+1 /* (set! perm/isvtx ...) */,C_fix((C_word)S_ISVTX));
t41=C_mutate((C_word*)lf[158]+1 /* (set! perm/isuid ...) */,C_fix((C_word)S_ISUID));
t42=C_mutate((C_word*)lf[159]+1 /* (set! perm/isgid ...) */,C_fix((C_word)S_ISGID));
t43=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3897,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp);
t44=C_mutate((C_word*)lf[160]+1 /* (set! file-control ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3908,a[2]=t43,a[3]=((C_word)li69),tmp=(C_word)a,a+=4,tmp));
t45=C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRGRP),C_fix((C_word)S_IROTH));
t46=C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRWXU),t45);
t47=C_mutate((C_word*)lf[162]+1 /* (set! file-open ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3938,a[2]=t46,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp));
t48=C_mutate((C_word*)lf[164]+1 /* (set! file-close ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3968,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[166]+1 /* (set! file-read ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3984,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[169]+1 /* (set! file-write ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4021,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[172]+1 /* (set! file-mkstemp ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4054,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4081,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp);
t53=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4086,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp);
t54=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4094,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
t55=C_mutate((C_word*)lf[174]+1 /* (set! file-select ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4102,a[2]=t54,a[3]=t53,a[4]=t52,a[5]=((C_word)li86),tmp=(C_word)a,a+=6,tmp));
t56=C_mutate((C_word*)lf[176]+1 /* (set! seek/set ...) */,C_fix((C_word)SEEK_SET));
t57=C_mutate((C_word*)lf[177]+1 /* (set! seek/end ...) */,C_fix((C_word)SEEK_END));
t58=C_mutate((C_word*)lf[178]+1 /* (set! seek/cur ...) */,C_fix((C_word)SEEK_CUR));
t59=C_mutate((C_word*)lf[179]+1 /* (set! set-file-position! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4354,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t60=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4406,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t61=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7869,a[2]=((C_word)li272),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:741: getter-with-setter */
t62=*((C_word*)lf[442]+1);
((C_proc5)(void*)(*((C_word*)t62+1)))(5,t62,t60,t61,*((C_word*)lf[179]+1),lf[457]);}

/* k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3550,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[6];
t7=((C_word*)t0)[7];
t8=((C_word*)t0)[8];
t9=C_i_check_string_2(t3,lf[71]);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3361,a[2]=t1,a[3]=t5,a[4]=t11,a[5]=t2,a[6]=t6,a[7]=t8,a[8]=t3,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t7)){
if(C_truep(C_fixnump(t7))){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3530,a[2]=t11,a[3]=t7,a[4]=((C_word)li41),tmp=(C_word)a,a+=5,tmp);
t14=t12;
f_3361(t14,t13);}
else{
t13=t12;
f_3361(t13,t7);}}
else{
t13=t12;
f_3361(t13,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3521,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));}}

/* f_3555 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3555,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_3561 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3561,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_3567 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3567,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3569,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));}

/* f_3564 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3564,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* f_3558 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3558,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* process-wait in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3784(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_3784r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3784r(t0,t1,t2);}}

static void C_ccall f_3784r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(9);
t3=C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:C_i_car(t2));
t5=C_i_nullp(t2);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_i_cdr(t2));
t7=C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_FALSE:C_i_car(t6));
t9=C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:C_i_cdr(t6));
t11=(C_truep(t4)?t4:C_fix(-1));
t12=C_i_check_exact_2(t11,lf[118]);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3804,a[2]=t11,a[3]=t8,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3809,a[2]=t11,a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp);
/* posix-common.scm:520: ##sys#call-with-values */
C_call_with_values(4,0,t1,t13,t14);}

/* find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3536(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_3536r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3536r(t0,t1,t2,t3);}}

static void C_ccall f_3536r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3540,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3574,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:425: ##sys#get-keyword */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[93]+1)))(5,*((C_word*)lf[93]+1),t4,lf[97],t3,t5);}

/* f_3530 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3530(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3530,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fixnum_lessp(((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]));}

/* k7881 */
static void C_ccall f_7883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(7));
t3=C_eqp(t2,lf[51]);
if(C_truep(t3)){
t4=C_ftell(((C_word*)t0)[2]);
t5=((C_word*)t0)[3];
f_7872(2,t5,t4);}
else{
t4=((C_word*)t0)[3];
f_7872(2,t4,C_fix(-1));}}
else{
if(C_truep(C_fixnump(((C_word*)t0)[2]))){
t2=C_lseek(((C_word*)t0)[2],C_fix(0),C_fix((C_word)SEEK_CUR));
t3=((C_word*)t0)[3];
f_7872(2,t3,t2);}
else{
/* posixunix.scm:750: ##sys#signal-hook */
t2=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[185],lf[456],((C_word*)t0)[2]);}}}

/* f_3569 */
static void C_ccall f_3569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3569,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t2,t3));}

/* file-lock in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6358(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6358r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6358r(t0,t1,t2,t3);}}

static void C_ccall f_6358r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6362,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1509: setup */
f_6285(t4,t2,t3,lf[356]);}

/* poke in k6024 in custom-output-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_6027(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6027,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6033,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t5,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word)li166),tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_6033(2,t7,t1);}

/* k6024 in custom-output-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6025,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6027,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li167),tmp=(C_word)a,a+=7,tmp));
t7=C_fixnump(((C_word*)t0)[5]);
t8=(C_truep(t7)?((C_word*)t0)[5]:C_block_size(((C_word*)t0)[5]));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6090,a[2]=t5,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t10=C_eqp(C_fix(0),t8);
if(C_truep(t10)){
t11=t9;
f_6090(t11,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6130,a[2]=t3,a[3]=((C_word)li171),tmp=(C_word)a,a+=4,tmp));}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6142,a[2]=t9,a[3]=t8,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_fixnump(((C_word*)t0)[5]))){
/* posixunix.scm:1444: ##sys#make-string */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[66]+1)))(3,*((C_word*)lf[66]+1),t11,((C_word*)t0)[5]);}
else{
t12=t11;
f_6142(2,t12,((C_word*)t0)[5]);}}}

/* k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3561,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:425: ##sys#get-keyword */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[93]+1)))(5,*((C_word*)lf[93]+1),t2,lf[94],((C_word*)t0)[6],t3);}

/* k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3558,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:425: ##sys#get-keyword */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[93]+1)))(5,*((C_word*)lf[93]+1),t2,lf[72],((C_word*)t0)[7],t3);}

/* k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3567,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:425: ##sys#get-keyword */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[93]+1)))(5,*((C_word*)lf[93]+1),t2,lf[96],((C_word*)t0)[4],t3);}

/* k7873 in k7871 */
static void C_ccall f_7874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3564,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:425: ##sys#get-keyword */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[93]+1)))(5,*((C_word*)lf[93]+1),t2,lf[95],((C_word*)t0)[5],t3);}

/* k7871 */
static void C_ccall f_7872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7874,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_lessp(t1,C_fix(0)))){
/* posixunix.scm:752: posix-error */
t3=lf[1];
f_2617(6,t3,t2,lf[8],lf[185],lf[455],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* f_3510 in k3508 in k3505 in k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3510(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3510,3,t0,t1,t2);}
/* posix-common.scm:404: irregex-match */
t3=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3555,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:425: ##sys#get-keyword */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[93]+1)))(5,*((C_word*)lf[93]+1),t2,lf[73],((C_word*)t0)[8],t3);}

/* f_4698 in k4687 in call-with-input-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4698(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4698r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4698r(t0,t1,t2);}}

static void C_ccall f_4698r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4701,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:848: close-input-pipe */
t4=*((C_word*)lf[200]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* f_4693 in k4687 in call-with-input-pipe in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4693,2,t0,t1);}
/* posixunix.scm:846: proc */
t2=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[3]);}

/* ##sys#custom-output-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_6009r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6009r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6009r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(8);
t6=C_i_nullp(t5);
t7=(C_truep(t6)?C_SCHEME_FALSE:C_i_car(t5));
t8=C_i_nullp(t5);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t5));
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_fix(0):C_i_car(t9));
t12=C_i_nullp(t9);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t9));
t14=C_i_nullp(t13);
t15=(C_truep(t14)?*((C_word*)lf[330]+1):C_i_car(t13));
t16=C_i_nullp(t13);
t17=(C_truep(t16)?C_SCHEME_END_OF_LIST:C_i_cdr(t13));
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6025,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t11,a[6]=t1,a[7]=t15,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
/* posixunix.scm:1422: ##sys#file-nonblocking! */
t19=*((C_word*)lf[122]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t18,t4);}
else{
t19=t18;
f_6025(2,t19,C_SCHEME_UNDEFINED);}}

/* f_3521 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3521(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3521,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k6361 in file-lock in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_flock_lock(((C_word*)t0)[2]);
if(C_truep(C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm:1511: err */
f_6343(((C_word*)t0)[4],lf[357],t1,lf[356]);}
else{
t3=t1;
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6050 in loop in poke in k6024 in custom-output-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1431: poke */
t2=((C_word*)((C_word*)t0)[2])[1];
f_6027(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}

/* f_6398 in k6393 in file-test-lock in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6398(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6398,3,t0,t1,t2);}
t3=C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k6393 in file-test-lock in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6394,2,t0,t1);}
t2=C_flock_test(((C_word*)t0)[2]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6398,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1520: g1559 */
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[3],t2);}
else{
/* posixunix.scm:1523: err */
f_6343(((C_word*)t0)[3],lf[361],t1,lf[360]);}}

/* f_7113 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7113(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7113,5,t0,t1,t2,t3,t4);}
t5=C_i_foreign_fixnum_argumentp(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7121,a[2]=t4,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t7=C_i_foreign_string_argumentp(t3);
/* posixunix.scm:1774: ##sys#make-c-string */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t6,t7);}
else{
t7=C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,stub1846(C_SCHEME_UNDEFINED,t5,C_SCHEME_FALSE,t7));}}

/* f_7111 in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7111,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,stub1841(C_SCHEME_UNDEFINED));}

/* file-test-lock in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6390(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6390r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6390r(t0,t1,t2,t3);}}

static void C_ccall f_6390r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6394,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1521: setup */
f_6285(t4,t2,t3,lf[360]);}

/* k7099 */
static void C_ccall f_7101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_foreign_fixnum_argumentp(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,stub1834(C_SCHEME_UNDEFINED,((C_word*)t0)[4],t1,t2));}

/* f_7821 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7821(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7821,3,t0,t1,t2);}
t3=C_setgid(t2);
if(C_truep(C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7829,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1030: ##sys#update-errno */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t4);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k3330 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posix-common.scm:386: make-pathname */
t2=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k3505 in k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3507,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3509,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posix-common.scm:403: irregex */
t3=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_3363(t2,((C_word*)t0)[3]);}}

/* k7828 */
static void C_ccall f_7829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1031: ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[447],lf[448],((C_word*)t0)[3]);}

/* k3508 in k3505 in k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3509,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3363(t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3510,a[2]=t1,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp));}

/* k6377 in file-lock/blocking in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_flock_lockw(((C_word*)t0)[2]);
if(C_truep(C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm:1517: err */
f_6343(((C_word*)t0)[4],lf[359],t1,lf[358]);}
else{
t3=t1;
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3348 */
static void C_ccall f_3349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posix-common.scm:380: ##sys#glob->regexp */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[82]+1)))(3,*((C_word*)lf[82]+1),((C_word*)t0)[2],t1);}

/* file-lock/blocking in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6374(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6374r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6374r(t0,t1,t2,t3);}}

static void C_ccall f_6374r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6378,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1515: setup */
f_6285(t4,t2,t3,lf[358]);}

/* k7811 */
static void C_ccall f_7812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1040: ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[444],lf[445],((C_word*)t0)[3]);}

/* f_7818 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7818,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,stub1099(C_SCHEME_UNDEFINED));}

/* loop in poke in k6024 in custom-output-port in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_6033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6033,2,t0,t1);}
t2=C_write(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);
t3=C_eqp(C_fix(-1),t2);
if(C_truep(t3)){
t4=C_fix((C_word)errno);
t5=C_i_eqvp(t4,C_fix((C_word)EWOULDBLOCK));
t6=(C_truep(t5)?t5:C_i_eqvp(t4,C_fix((C_word)EAGAIN)));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6051,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm:1430: ##sys#thread-yield! */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[333]+1)))(2,*((C_word*)lf[333]+1),t7);}
else{
if(C_truep(C_i_eqvp(t4,C_fix((C_word)EINTR)))){
/* posixunix.scm:1433: ##sys#dispatch-interrupt */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[337]+1)))(3,*((C_word*)lf[337]+1),t1,((C_word*)((C_word*)t0)[6])[1]);}
else{
/* posixunix.scm:1435: posix-error */
t7=lf[1];
f_2617(7,t7,t1,((C_word*)t0)[7],lf[8],lf[348],((C_word*)t0)[2],((C_word*)t0)[8]);}}}
else{
if(C_truep(C_fixnum_lessp(t2,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6081,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm:1437: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),t4,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}}

/* f_3316 in k3311 in loop in k3294 in k3288 */
static void C_ccall f_3316(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3316,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3322,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3331,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posix-common.scm:386: irregex-match-substring */
t5=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_7801 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7801,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,stub1104(C_SCHEME_UNDEFINED));}

/* k3311 in loop in k3294 in k3288 */
static void C_ccall f_3312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3312,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li31),tmp=(C_word)a,a+=6,tmp);
/* posix-common.scm:378: g355 */
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[5],t1);}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* posix-common.scm:388: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3297(t4,((C_word*)t0)[5],t3);}}

/* f_7804 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7804(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7804,3,t0,t1,t2);}
t3=C_setegid(t2);
if(C_truep(C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7812,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1039: ##sys#update-errno */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t4);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* create-directory in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4408(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4408r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4408r(t0,t1,t2,t3);}}

static void C_ccall f_4408r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=C_i_check_string_2(t2,lf[186]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4417,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:767: ##sys#expand-home-path */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t7,t2);}

/* k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word ab[143],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4406,2,t0,t1);}
t2=C_mutate((C_word*)lf[185]+1 /* (set! file-position ...) */,t1);
t3=C_mutate((C_word*)lf[186]+1 /* (set! create-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4408,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[63]+1 /* (set! change-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4515,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[191]+1 /* (set! change-directory* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4535,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4568,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp);
t7=C_mutate((C_word*)lf[195]+1 /* (set! open-input-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4582,a[2]=t6,a[3]=((C_word)li97),tmp=(C_word)a,a+=4,tmp));
t8=C_mutate((C_word*)lf[199]+1 /* (set! open-output-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4619,a[2]=t6,a[3]=((C_word)li98),tmp=(C_word)a,a+=4,tmp));
t9=C_mutate((C_word*)lf[200]+1 /* (set! close-input-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4656,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[203]+1 /* (set! close-output-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4670,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[206]+1 /* (set! call-with-input-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4684,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[207]+1 /* (set! call-with-output-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4706,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[208]+1 /* (set! with-input-from-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4728,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[210]+1 /* (set! with-output-to-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4760,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[212]+1 /* (set! create-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4792,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[214]+1 /* (set! signal/term ...) */,C_fix((C_word)SIGTERM));
t17=C_mutate((C_word*)lf[215]+1 /* (set! signal/kill ...) */,C_fix((C_word)SIGKILL));
t18=C_mutate((C_word*)lf[216]+1 /* (set! signal/int ...) */,C_fix((C_word)SIGINT));
t19=C_mutate((C_word*)lf[217]+1 /* (set! signal/hup ...) */,C_fix((C_word)SIGHUP));
t20=C_mutate((C_word*)lf[218]+1 /* (set! signal/fpe ...) */,C_fix((C_word)SIGFPE));
t21=C_mutate((C_word*)lf[219]+1 /* (set! signal/ill ...) */,C_fix((C_word)SIGILL));
t22=C_mutate((C_word*)lf[220]+1 /* (set! signal/segv ...) */,C_fix((C_word)SIGSEGV));
t23=C_mutate((C_word*)lf[221]+1 /* (set! signal/abrt ...) */,C_fix((C_word)SIGABRT));
t24=C_mutate((C_word*)lf[222]+1 /* (set! signal/trap ...) */,C_fix((C_word)SIGTRAP));
t25=C_mutate((C_word*)lf[223]+1 /* (set! signal/quit ...) */,C_fix((C_word)SIGQUIT));
t26=C_mutate((C_word*)lf[224]+1 /* (set! signal/alrm ...) */,C_fix((C_word)SIGALRM));
t27=C_mutate((C_word*)lf[225]+1 /* (set! signal/vtalrm ...) */,C_fix((C_word)SIGVTALRM));
t28=C_mutate((C_word*)lf[226]+1 /* (set! signal/prof ...) */,C_fix((C_word)SIGPROF));
t29=C_mutate((C_word*)lf[227]+1 /* (set! signal/io ...) */,C_fix((C_word)SIGIO));
t30=C_mutate((C_word*)lf[228]+1 /* (set! signal/urg ...) */,C_fix((C_word)SIGURG));
t31=C_mutate((C_word*)lf[229]+1 /* (set! signal/chld ...) */,C_fix((C_word)SIGCHLD));
t32=C_mutate((C_word*)lf[230]+1 /* (set! signal/cont ...) */,C_fix((C_word)SIGCONT));
t33=C_mutate((C_word*)lf[231]+1 /* (set! signal/stop ...) */,C_fix((C_word)SIGSTOP));
t34=C_mutate((C_word*)lf[232]+1 /* (set! signal/tstp ...) */,C_fix((C_word)SIGTSTP));
t35=C_mutate((C_word*)lf[233]+1 /* (set! signal/pipe ...) */,C_fix((C_word)SIGPIPE));
t36=C_mutate((C_word*)lf[234]+1 /* (set! signal/xcpu ...) */,C_fix((C_word)SIGXCPU));
t37=C_mutate((C_word*)lf[235]+1 /* (set! signal/xfsz ...) */,C_fix((C_word)SIGXFSZ));
t38=C_mutate((C_word*)lf[236]+1 /* (set! signal/usr1 ...) */,C_fix((C_word)SIGUSR1));
t39=C_mutate((C_word*)lf[237]+1 /* (set! signal/usr2 ...) */,C_fix((C_word)SIGUSR2));
t40=C_mutate((C_word*)lf[238]+1 /* (set! signal/winch ...) */,C_fix((C_word)SIGWINCH));
t41=C_a_i_list(&a,25,*((C_word*)lf[214]+1),*((C_word*)lf[215]+1),*((C_word*)lf[216]+1),*((C_word*)lf[217]+1),*((C_word*)lf[218]+1),*((C_word*)lf[219]+1),*((C_word*)lf[220]+1),*((C_word*)lf[221]+1),*((C_word*)lf[222]+1),*((C_word*)lf[223]+1),*((C_word*)lf[224]+1),*((C_word*)lf[225]+1),*((C_word*)lf[226]+1),*((C_word*)lf[227]+1),*((C_word*)lf[228]+1),*((C_word*)lf[229]+1),*((C_word*)lf[230]+1),*((C_word*)lf[231]+1),*((C_word*)lf[232]+1),*((C_word*)lf[233]+1),*((C_word*)lf[234]+1),*((C_word*)lf[235]+1),*((C_word*)lf[236]+1),*((C_word*)lf[237]+1),*((C_word*)lf[238]+1));
t42=C_mutate((C_word*)lf[239]+1 /* (set! signals-list ...) */,t41);
t43=C_mutate((C_word*)lf[240]+1 /* (set! set-signal-mask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4837,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[242]+1 /* (set! signal-mask ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4880,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[243]+1 /* (set! signal-masked? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4908,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[244]+1 /* (set! signal-mask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4914,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[246]+1 /* (set! signal-unmask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4930,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[248]+1 /* (set! system-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4946,a[2]=((C_word)li126),tmp=(C_word)a,a+=3,tmp));
t49=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4980,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t50=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7852,a[2]=((C_word)li270),tmp=(C_word)a,a+=3,tmp);
t51=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7855,a[2]=((C_word)li271),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1007: getter-with-setter */
t52=*((C_word*)lf[442]+1);
((C_proc5)(void*)(*((C_word*)t52+1)))(5,t52,t49,t50,t51,lf[454]);}

/* k7150 in k7148 in process-execute in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7152,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7157,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t3,a[9]=((C_word)li224),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_7157(t5,((C_word*)t0)[8],((C_word*)t0)[9],C_fix(1));}

/* doloop1873 in k7150 in k7148 in process-execute in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_7157(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7157,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7166,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm:1785: setarg */
t5=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t3,C_SCHEME_FALSE,C_fix(0));}
else{
t4=C_i_car(t2);
t5=C_i_check_string_2(t4,lf[419]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7230,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_block_size(t4);
/* posixunix.scm:1804: setarg */
t8=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,t3,t4,t7);}}

/* k3324 in k3321 */
static void C_ccall f_3325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3325,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k3321 */
static void C_ccall f_3322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3325,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* posix-common.scm:387: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3297(t4,t2,t3);}

/* loop in k3368 in k3362 in k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_3371(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3371,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_slot(t2,C_fix(0));
t5=C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3388,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t5,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
/* posix-common.scm:412: directory? */
t7=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}}

/* k3386 in loop in k3368 in k3362 in k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3388,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3481,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* posix-common.scm:413: pathname-file */
t3=*((C_word*)lf[88]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* posix-common.scm:422: pproc */
t3=((C_word*)t0)[9];
((C_proc3)C_fast_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}}

/* k7169 in k7167 in k7165 in doloop1873 in k7150 in k7148 in process-execute in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in ... */
static void C_ccall f_7170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7170,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[2])?C_execve(t1):C_execvp(t1));
t3=C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7180,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:1799: freeargs */
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k7148 in process-execute in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7152,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=C_block_size(t1);
/* posixunix.scm:1781: setarg */
t4=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,C_fix(0),t1,t3);}

/* loop in k4432 in k4422 in k4416 in create-directory in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_4435(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4435,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4442,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4470,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:773: directory? */
t5=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
t4=t3;
f_4442(t4,C_SCHEME_FALSE);}}

/* k7165 in doloop1873 in k7150 in k7148 in process-execute in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_7166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7168,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_i_check_list_2(((C_word*)t0)[2],lf[419]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7195,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word)li223),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_7195(t7,t2,((C_word*)t0)[2],C_fix(0));}
else{
t3=t2;
f_7168(2,t3,C_SCHEME_UNDEFINED);}}

/* k4432 in k4422 in k4416 in create-directory in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4433,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4435,a[2]=t3,a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4435(t5,((C_word*)t0)[2],t1);}

/* k3368 in k3362 in k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_3369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3369,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3371,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word)li39),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_3371(t5,((C_word*)t0)[7],t1,((C_word*)t0)[8]);}

/* k4440 in loop in k4432 in k4422 in k4416 in create-directory in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_4442(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4442,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4464,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:774: pathname-directory */
t4=*((C_word*)lf[188]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* doloop1877 in k7165 in doloop1873 in k7150 in k7148 in process-execute in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 in ... */
static void C_fcall f_7195(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7195,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
/* posixunix.scm:1790: setenv */
t4=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,t3,C_SCHEME_FALSE,C_fix(0));}
else{
t4=C_i_car(t2);
t5=C_i_check_string_2(t4,lf[419]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7212,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_block_size(t4);
/* posixunix.scm:1793: setenv */
t8=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,t3,t4,t7);}}

/* f_4445 in k4443 in k4440 in loop in k4432 in k4422 in k4416 in create-directory in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4445,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4458,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:761: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t4,t3,t2);}

/* k4443 in k4440 in loop in k4432 in k4422 in k4416 in create-directory in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4445,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:775: g892 */
t3=t2;
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[186],((C_word*)t0)[3]);}

/* k7167 in k7165 in doloop1873 in k7150 in k7148 in process-execute in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 in ... */
static void C_ccall f_7168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7170,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7188,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1794: ##sys#expand-home-path */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t3,((C_word*)t0)[4]);}

/* k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_3361(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3361,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3363,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=C_i_stringp(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3507,a[2]=t2,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_3507(2,t5,t3);}
else{
/* posix-common.scm:402: irregex? */
t5=*((C_word*)lf[92]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[9]);}}

/* k3362 in k3360 in k3549 in k3547 in k3545 in k3543 in k3541 in k3539 in find-files in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_3363(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3363,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3499,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[8])){
/* posix-common.scm:406: make-pathname */
t4=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[9],lf[89]);}
else{
/* posix-common.scm:406: make-pathname */
t4=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[9],lf[90]);}}

/* k4416 in create-directory in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4419,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_block_size(t1);
t4=C_eqp(C_fix(0),t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4424,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_4424(2,t6,t4);}
else{
/* posixunix.scm:769: file-exists? */
t6=*((C_word*)lf[189]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t1);}}

/* k4418 in k4416 in create-directory in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* err in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_6343(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6343,NULL,4,t1,t2,t3,t4);}
t5=C_slot(t3,C_fix(1));
t6=C_slot(t3,C_fix(2));
t7=C_slot(t3,C_fix(3));
/* posixunix.scm:1506: posix-error */
t8=lf[1];
f_2617(8,t8,t1,lf[8],t4,t2,t5,t6,t7);}

/* k7181 in k7179 in k7169 in k7167 in k7165 in doloop1873 in k7150 in k7148 in process-execute in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in ... */
static void C_ccall f_7182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1801: posix-error */
t2=lf[1];
f_2617(6,t2,((C_word*)t0)[2],lf[120],lf[419],lf[420],((C_word*)t0)[3]);}

/* k7179 in k7169 in k7167 in k7165 in doloop1873 in k7150 in k7148 in process-execute in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in ... */
static void C_ccall f_7180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7182,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1800: freeenv */
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5376 in change-file-owner in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_chown(t1,((C_word*)t0)[2],((C_word*)t0)[3]);
if(C_truep(C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm:1206: posix-error */
t3=lf[1];
f_2617(8,t3,((C_word*)t0)[4],lf[8],lf[311],lf[312],((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4422 in k4416 in create-directory in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4424,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4433,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4472,a[2]=((C_word*)t0)[3],a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4477,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:771: ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4485,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:776: g910 */
t3=t2;
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],lf[186],((C_word*)t0)[3]);}}}

/* k5379 in change-file-owner in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1205: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],t1,lf[311]);}

/* check in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_fcall f_5382(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5382,NULL,4,t1,t2,t3,t4);}
t5=C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5397,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5400,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm:1215: ##sys#expand-home-path */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t7,t2);}

/* k7187 in k7167 in k7165 in doloop1873 in k7150 in k7148 in process-execute in k5468 in k5434 in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in ... */
static void C_ccall f_7188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1794: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],t1,lf[419]);}

/* f_4472 in k4422 in k4416 in create-directory in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4472,2,t0,t1);}
/* posixunix.scm:771: decompose-pathname */
t2=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k4469 in loop in k4432 in k4422 in k4416 in create-directory in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4442(t2,C_i_not(t1));}

/* f_4477 in k4422 in k4416 in create-directory in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4477,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
/* posixunix.scm:772: make-pathname */
t5=*((C_word*)lf[78]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,t4);}
else{
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k5350 in change-file-mode in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_chmod(t1,((C_word*)t0)[2]);
if(C_truep(C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm:1198: posix-error */
t3=lf[1];
f_2617(7,t3,((C_word*)t0)[3],lf[8],lf[309],lf[310],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* change-file-owner in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5356,5,t0,t1,t2,t3,t4);}
t5=C_i_check_string_2(t2,lf[311]);
t6=C_i_check_exact_2(t3,lf[311]);
t7=C_i_check_exact_2(t4,lf[311]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5377,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5380,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm:1205: ##sys#expand-home-path */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t9,t2);}

/* k5353 in change-file-mode in k4990 in k4986 in k4982 in k4978 in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_5354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm:1197: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],t1,lf[309]);}

/* f_4485 in k4422 in k4416 in create-directory in k4404 in k3774 in k3579 in k2692 in k2605 in k2603 in k2601 in k2599 in k2597 in k2595 */
static void C_ccall f_4485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4485,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4498,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm:761: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t4,t3,t2);}

/* k4457 */
static void C_ccall f_4458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mkdir(t1);
t3=C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* posixunix.scm:762: posix-error */
t4=lf[1];
f_2617(6,t4,((C_word*)t0)[2],lf[8],((C_word*)t0)[3],lf[187],((C_word*)t0)[4]);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[661] = {
{"f_4464:posixunix_2escm",(void*)f_4464},
{"f_6955:posixunix_2escm",(void*)f_6955},
{"f_4498:posixunix_2escm",(void*)f_4498},
{"f_6959:posixunix_2escm",(void*)f_6959},
{"f_7131:posixunix_2escm",(void*)f_7131},
{"f_7133:posixunix_2escm",(void*)f_7133},
{"f_6942:posixunix_2escm",(void*)f_6942},
{"f_6944:posixunix_2escm",(void*)f_6944},
{"f_4364:posixunix_2escm",(void*)f_4364},
{"f_7121:posixunix_2escm",(void*)f_7121},
{"f_6938:posixunix_2escm",(void*)f_6938},
{"f_4370:posixunix_2escm",(void*)f_4370},
{"f_4376:posixunix_2escm",(void*)f_4376},
{"f_5332:posixunix_2escm",(void*)f_5332},
{"f_6995:posixunix_2escm",(void*)f_6995},
{"f_6568:posixunix_2escm",(void*)f_6568},
{"f_6560:posixunix_2escm",(void*)f_6560},
{"f_6989:posixunix_2escm",(void*)f_6989},
{"f_6985:posixunix_2escm",(void*)f_6985},
{"f_4327:posixunix_2escm",(void*)f_4327},
{"f_6556:posixunix_2escm",(void*)f_6556},
{"f_6550:posixunix_2escm",(void*)f_6550},
{"f_6249:posixunix_2escm",(void*)f_6249},
{"f_6976:posixunix_2escm",(void*)f_6976},
{"f_4336:posixunix_2escm",(void*)f_4336},
{"f_6541:posixunix_2escm",(void*)f_6541},
{"f_6274:posixunix_2escm",(void*)f_6274},
{"f_2828:posixunix_2escm",(void*)f_2828},
{"f_2826:posixunix_2escm",(void*)f_2826},
{"f_6271:posixunix_2escm",(void*)f_6271},
{"f_6539:posixunix_2escm",(void*)f_6539},
{"f_6532:posixunix_2escm",(void*)f_6532},
{"f_6530:posixunix_2escm",(void*)f_6530},
{"f_4595:posixunix_2escm",(void*)f_4595},
{"f_2837:posixunix_2escm",(void*)f_2837},
{"f_2835:posixunix_2escm",(void*)f_2835},
{"f_4354:posixunix_2escm",(void*)f_4354},
{"f_4358:posixunix_2escm",(void*)f_4358},
{"f_6259:posixunix_2escm",(void*)f_6259},
{"f_4568:posixunix_2escm",(void*)f_4568},
{"f_6593:posixunix_2escm",(void*)f_6593},
{"f_6590:posixunix_2escm",(void*)f_6590},
{"f_6285:posixunix_2escm",(void*)f_6285},
{"f_6584:posixunix_2escm",(void*)f_6584},
{"f_4582:posixunix_2escm",(void*)f_4582},
{"f_4580:posixunix_2escm",(void*)f_4580},
{"f_3108:posixunix_2escm",(void*)f_3108},
{"f_6265:posixunix_2escm",(void*)f_6265},
{"f_4315:posixunix_2escm",(void*)f_4315},
{"f_3117:posixunix_2escm",(void*)f_3117},
{"f_6297:posixunix_2escm",(void*)f_6297},
{"f_4521:posixunix_2escm",(void*)f_4521},
{"f_4523:posixunix_2escm",(void*)f_4523},
{"f_4541:posixunix_2escm",(void*)f_4541},
{"f_4515:posixunix_2escm",(void*)f_4515},
{"f_6527:posixunix_2escm",(void*)f_6527},
{"f_5001:posixunix_2escm",(void*)f_5001},
{"f_5509:posixunix_2escm",(void*)f_5509},
{"f_5500:posixunix_2escm",(void*)f_5500},
{"f_2844:posixunix_2escm",(void*)f_2844},
{"f_2846:posixunix_2escm",(void*)f_2846},
{"f_5018:posixunix_2escm",(void*)f_5018},
{"f_5015:posixunix_2escm",(void*)f_5015},
{"f_6516:posixunix_2escm",(void*)f_6516},
{"f_5012:posixunix_2escm",(void*)f_5012},
{"f_6518:posixunix_2escm",(void*)f_6518},
{"f_2855:posixunix_2escm",(void*)f_2855},
{"f_2853:posixunix_2escm",(void*)f_2853},
{"f_3103:posixunix_2escm",(void*)f_3103},
{"f_4535:posixunix_2escm",(void*)f_4535},
{"f_4533:posixunix_2escm",(void*)f_4533},
{"f_2862:posixunix_2escm",(void*)f_2862},
{"f_2864:posixunix_2escm",(void*)f_2864},
{"f_5075:posixunix_2escm",(void*)f_5075},
{"f_3192:posixunix_2escm",(void*)f_3192},
{"f_2876:posixunix_2escm",(void*)f_2876},
{"f_2871:posixunix_2escm",(void*)f_2871},
{"f_5040:posixunix_2escm",(void*)f_5040},
{"f_5047:posixunix_2escm",(void*)f_5047},
{"f_5052:posixunix_2escm",(void*)f_5052},
{"f_5050:posixunix_2escm",(void*)f_5050},
{"f_3172:posixunix_2escm",(void*)f_3172},
{"f_5059:posixunix_2escm",(void*)f_5059},
{"f_2819:posixunix_2escm",(void*)f_2819},
{"f_2817:posixunix_2escm",(void*)f_2817},
{"f_5021:posixunix_2escm",(void*)f_5021},
{"f_2810:posixunix_2escm",(void*)f_2810},
{"f_5024:posixunix_2escm",(void*)f_5024},
{"f_3201:posixunix_2escm",(void*)f_3201},
{"f_3151:posixunix_2escm",(void*)f_3151},
{"f_3153:posixunix_2escm",(void*)f_3153},
{"f_3155:posixunix_2escm",(void*)f_3155},
{"f_7093:posixunix_2escm",(void*)f_7093},
{"f_5082:posixunix_2escm",(void*)f_5082},
{"f_3158:posixunix_2escm",(void*)f_3158},
{"f_5096:posixunix_2escm",(void*)f_5096},
{"f_5093:posixunix_2escm",(void*)f_5093},
{"f_3137:posixunix_2escm",(void*)f_3137},
{"f_5099:posixunix_2escm",(void*)f_5099},
{"f_3231:posixunix_2escm",(void*)f_3231},
{"f_5557:posixunix_2escm",(void*)f_5557},
{"f_5559:posixunix_2escm",(void*)f_5559},
{"f_3186:posixunix_2escm",(void*)f_3186},
{"f_5291:posixunix_2escm",(void*)f_5291},
{"f_3182:posixunix_2escm",(void*)f_3182},
{"f_5062:posixunix_2escm",(void*)f_5062},
{"f_5724:posixunix_2escm",(void*)f_5724},
{"f_5722:posixunix_2escm",(void*)f_5722},
{"f_5730:posixunix_2escm",(void*)f_5730},
{"f_3938:posixunix_2escm",(void*)f_3938},
{"f_2883:posixunix_2escm",(void*)f_2883},
{"f_5715:posixunix_2escm",(void*)f_5715},
{"f_3141:posixunix_2escm",(void*)f_3141},
{"f_5719:posixunix_2escm",(void*)f_5719},
{"f_5717:posixunix_2escm",(void*)f_5717},
{"f_3281:posixunix_2escm",(void*)f_3281},
{"f_3286:posixunix_2escm",(void*)f_3286},
{"f_3289:posixunix_2escm",(void*)f_3289},
{"f_5769:posixunix_2escm",(void*)f_5769},
{"f_5761:posixunix_2escm",(void*)f_5761},
{"f_5032:posixunix_2escm",(void*)f_5032},
{"f_5764:posixunix_2escm",(void*)f_5764},
{"f_5776:posixunix_2escm",(void*)f_5776},
{"f_5778:posixunix_2escm",(void*)f_5778},
{"f_3261:posixunix_2escm",(void*)f_3261},
{"f_3951:posixunix_2escm",(void*)f_3951},
{"f_3267:posixunix_2escm",(void*)f_3267},
{"f_3953:posixunix_2escm",(void*)f_3953},
{"f_5749:posixunix_2escm",(void*)f_5749},
{"f_5741:posixunix_2escm",(void*)f_5741},
{"f_2708:posixunix_2escm",(void*)f_2708},
{"f_2706:posixunix_2escm",(void*)f_2706},
{"f_2700:posixunix_2escm",(void*)f_2700},
{"f_2702:posixunix_2escm",(void*)f_2702},
{"f_3984:posixunix_2escm",(void*)f_3984},
{"f_7746:posixunix_2escm",(void*)f_7746},
{"f_5539:posixunix_2escm",(void*)f_5539},
{"f_2718:posixunix_2escm",(void*)f_2718},
{"f_2714:posixunix_2escm",(void*)f_2714},
{"f_2712:posixunix_2escm",(void*)f_2712},
{"f_6415:posixunix_2escm",(void*)f_6415},
{"f_7739:posixunix_2escm",(void*)f_7739},
{"f_3908:posixunix_2escm",(void*)f_3908},
{"f_7734:posixunix_2escm",(void*)f_7734},
{"f_7767:posixunix_2escm",(void*)f_7767},
{"f_3962:posixunix_2escm",(void*)f_3962},
{"f_5517:posixunix_2escm",(void*)f_5517},
{"f_3919:posixunix_2escm",(void*)f_3919},
{"f_3481:posixunix_2escm",(void*)f_3481},
{"f_7762:posixunix_2escm",(void*)f_7762},
{"f_3487:posixunix_2escm",(void*)f_3487},
{"f_5526:posixunix_2escm",(void*)f_5526},
{"f_5522:posixunix_2escm",(void*)f_5522},
{"f_3968:posixunix_2escm",(void*)f_3968},
{"f_3942:posixunix_2escm",(void*)f_3942},
{"f_5579:posixunix_2escm",(void*)f_5579},
{"f_6766:posixunix_2escm",(void*)f_6766},
{"f_3466:posixunix_2escm",(void*)f_3466},
{"f_7782:posixunix_2escm",(void*)f_7782},
{"f_3469:posixunix_2escm",(void*)f_3469},
{"f_2600:posixunix_2escm",(void*)f_2600},
{"f_2602:posixunix_2escm",(void*)f_2602},
{"f_5583:posixunix_2escm",(void*)f_5583},
{"f_7777:posixunix_2escm",(void*)f_7777},
{"f_5587:posixunix_2escm",(void*)f_5587},
{"f_5584:posixunix_2escm",(void*)f_5584},
{"f_6759:posixunix_2escm",(void*)f_6759},
{"f_6752:posixunix_2escm",(void*)f_6752},
{"f_3475:posixunix_2escm",(void*)f_3475},
{"f_7772:posixunix_2escm",(void*)f_7772},
{"f_6446:posixunix_2escm",(void*)f_6446},
{"f_2608:posixunix_2escm",(void*)f_2608},
{"f_2604:posixunix_2escm",(void*)f_2604},
{"f_6746:posixunix_2escm",(void*)f_6746},
{"f_3443:posixunix_2escm",(void*)f_3443},
{"f_2606:posixunix_2escm",(void*)f_2606},
{"f_3446:posixunix_2escm",(void*)f_3446},
{"f_6740:posixunix_2escm",(void*)f_6740},
{"f_3449:posixunix_2escm",(void*)f_3449},
{"f_2621:posixunix_2escm",(void*)f_2621},
{"f_2617:posixunix_2escm",(void*)f_2617},
{"f_6734:posixunix_2escm",(void*)f_6734},
{"f_3457:posixunix_2escm",(void*)f_3457},
{"f_3455:posixunix_2escm",(void*)f_3455},
{"f_2598:posixunix_2escm",(void*)f_2598},
{"f_7795:posixunix_2escm",(void*)f_7795},
{"f_2596:posixunix_2escm",(void*)f_2596},
{"f_2630:posixunix_2escm",(void*)f_2630},
{"f_2627:posixunix_2escm",(void*)f_2627},
{"f_3421:posixunix_2escm",(void*)f_3421},
{"f_3994:posixunix_2escm",(void*)f_3994},
{"f_3992:posixunix_2escm",(void*)f_3992},
{"f_7403:posixunix_2escm",(void*)f_7403},
{"f_2637:posixunix_2escm",(void*)f_2637},
{"f_2633:posixunix_2escm",(void*)f_2633},
{"f_7405:posixunix_2escm",(void*)f_7405},
{"f_3430:posixunix_2escm",(void*)f_3430},
{"f_3432:posixunix_2escm",(void*)f_3432},
{"f_3437:posixunix_2escm",(void*)f_3437},
{"f_6483:posixunix_2escm",(void*)f_6483},
{"f_6461:posixunix_2escm",(void*)f_6461},
{"f_3996:posixunix_2escm",(void*)f_3996},
{"f_2660:posixunix_2escm",(void*)f_2660},
{"f_3409:posixunix_2escm",(void*)f_3409},
{"f_6476:posixunix_2escm",(void*)f_6476},
{"f_2742:posixunix_2escm",(void*)f_2742},
{"f_6775:posixunix_2escm",(void*)f_6775},
{"f_3412:posixunix_2escm",(void*)f_3412},
{"f_6777:posixunix_2escm",(void*)f_6777},
{"f_6464:posixunix_2escm",(void*)f_6464},
{"f_4108:posixunix_2escm",(void*)f_4108},
{"f_4106:posixunix_2escm",(void*)f_4106},
{"f_4102:posixunix_2escm",(void*)f_4102},
{"f_7419:posixunix_2escm",(void*)f_7419},
{"f_2669:posixunix_2escm",(void*)f_2669},
{"f_2666:posixunix_2escm",(void*)f_2666},
{"f_4115:posixunix_2escm",(void*)f_4115},
{"f_4110:posixunix_2escm",(void*)f_4110},
{"f_2726:posixunix_2escm",(void*)f_2726},
{"f_2724:posixunix_2escm",(void*)f_2724},
{"f_2674:posixunix_2escm",(void*)f_2674},
{"f_2720:posixunix_2escm",(void*)f_2720},
{"f_2681:posixunix_2escm",(void*)f_2681},
{"f_7424:posixunix_2escm",(void*)f_7424},
{"f_2696:posixunix_2escm",(void*)f_2696},
{"f_2694:posixunix_2escm",(void*)f_2694},
{"f_7450:posixunix_2escm",(void*)f_7450},
{"f_7454:posixunix_2escm",(void*)f_7454},
{"f_6725:posixunix_2escm",(void*)f_6725},
{"f_7487:posixunix_2escm",(void*)f_7487},
{"f_6713:posixunix_2escm",(void*)f_6713},
{"f_4161:posixunix_2escm",(void*)f_4161},
{"f_7437:posixunix_2escm",(void*)f_7437},
{"f_6701:posixunix_2escm",(void*)f_6701},
{"f_4171:posixunix_2escm",(void*)f_4171},
{"f_5397:posixunix_2escm",(void*)f_5397},
{"f_4177:posixunix_2escm",(void*)f_4177},
{"f_7463:posixunix_2escm",(void*)f_7463},
{"f_7462:posixunix_2escm",(void*)f_7462},
{"f_4188:posixunix_2escm",(void*)f_4188},
{"f_5271:posixunix_2escm",(void*)f_5271},
{"f_4186:posixunix_2escm",(void*)f_4186},
{"f_7493:posixunix_2escm",(void*)f_7493},
{"f_6440:posixunix_2escm",(void*)f_6440},
{"f_7495:posixunix_2escm",(void*)f_7495},
{"f_7491:posixunix_2escm",(void*)f_7491},
{"f_4197:posixunix_2escm",(void*)f_4197},
{"f_5285:posixunix_2escm",(void*)f_5285},
{"f_4120:posixunix_2escm",(void*)f_4120},
{"f_4122:posixunix_2escm",(void*)f_4122},
{"f_7475:posixunix_2escm",(void*)f_7475},
{"f_7471:posixunix_2escm",(void*)f_7471},
{"f_5390:posixunix_2escm",(void*)f_5390},
{"f_4158:posixunix_2escm",(void*)f_4158},
{"f_4908:posixunix_2escm",(void*)f_4908},
{"f_5915:posixunix_2escm",(void*)f_5915},
{"f_5910:posixunix_2escm",(void*)f_5910},
{"f_5213:posixunix_2escm",(void*)f_5213},
{"f_4914:posixunix_2escm",(void*)f_4914},
{"f_5924:posixunix_2escm",(void*)f_5924},
{"f_5228:posixunix_2escm",(void*)f_5228},
{"f_5208:posixunix_2escm",(void*)f_5208},
{"f_7445:posixunix_2escm",(void*)f_7445},
{"f_5204:posixunix_2escm",(void*)f_5204},
{"f_5256:posixunix_2escm",(void*)f_5256},
{"f_5261:posixunix_2escm",(void*)f_5261},
{"f_4965:posixunix_2escm",(void*)f_4965},
{"f_4962:posixunix_2escm",(void*)f_4962},
{"f_4968:posixunix_2escm",(void*)f_4968},
{"f_5935:posixunix_2escm",(void*)f_5935},
{"f_6665:posixunix_2escm",(void*)f_6665},
{"f_4973:posixunix_2escm",(void*)f_4973},
{"f_5943:posixunix_2escm",(void*)f_5943},
{"f_4988:posixunix_2escm",(void*)f_4988},
{"f_6653:posixunix_2escm",(void*)f_6653},
{"f_4984:posixunix_2escm",(void*)f_4984},
{"f_6651:posixunix_2escm",(void*)f_6651},
{"f_4980:posixunix_2escm",(void*)f_4980},
{"f_6649:posixunix_2escm",(void*)f_6649},
{"f_6645:posixunix_2escm",(void*)f_6645},
{"f_6647:posixunix_2escm",(void*)f_6647},
{"f_6641:posixunix_2escm",(void*)f_6641},
{"f_4992:posixunix_2escm",(void*)f_4992},
{"f_4994:posixunix_2escm",(void*)f_4994},
{"f_7533:posixunix_2escm",(void*)f_7533},
{"f_4293:posixunix_2escm",(void*)f_4293},
{"f_7549:posixunix_2escm",(void*)f_7549},
{"f_7563:posixunix_2escm",(void*)f_7563},
{"f_4930:posixunix_2escm",(void*)f_4930},
{"f_7536:posixunix_2escm",(void*)f_7536},
{"f_2924:posixunix_2escm",(void*)f_2924},
{"f_2926:posixunix_2escm",(void*)f_2926},
{"f_4272:posixunix_2escm",(void*)f_4272},
{"f_7554:posixunix_2escm",(void*)f_7554},
{"f_6695:posixunix_2escm",(void*)f_6695},
{"f_7569:posixunix_2escm",(void*)f_7569},
{"f_4946:posixunix_2escm",(void*)f_4946},
{"f_7566:posixunix_2escm",(void*)f_7566},
{"f_2937:posixunix_2escm",(void*)f_2937},
{"f_2939:posixunix_2escm",(void*)f_2939},
{"f_4284:posixunix_2escm",(void*)f_4284},
{"f_6683:posixunix_2escm",(void*)f_6683},
{"f_4956:posixunix_2escm",(void*)f_4956},
{"f_4959:posixunix_2escm",(void*)f_4959},
{"f_4950:posixunix_2escm",(void*)f_4950},
{"f_3002:posixunix_2escm",(void*)f_3002},
{"f_3004:posixunix_2escm",(void*)f_3004},
{"f_7572:posixunix_2escm",(void*)f_7572},
{"f_7575:posixunix_2escm",(void*)f_7575},
{"f_7588:posixunix_2escm",(void*)f_7588},
{"f_3019:posixunix_2escm",(void*)f_3019},
{"f_7578:posixunix_2escm",(void*)f_7578},
{"f_4231:posixunix_2escm",(void*)f_4231},
{"f_4233:posixunix_2escm",(void*)f_4233},
{"f_7590:posixunix_2escm",(void*)f_7590},
{"f_7594:posixunix_2escm",(void*)f_7594},
{"toplevel:posixunix_2escm",(void*)C_posix_toplevel},
{"f_4242:posixunix_2escm",(void*)f_4242},
{"f_7543:posixunix_2escm",(void*)f_7543},
{"f_4216:posixunix_2escm",(void*)f_4216},
{"f_4222:posixunix_2escm",(void*)f_4222},
{"f_2952:posixunix_2escm",(void*)f_2952},
{"f_2956:posixunix_2escm",(void*)f_2956},
{"f_2950:posixunix_2escm",(void*)f_2950},
{"f_5408:posixunix_2escm",(void*)f_5408},
{"f_5400:posixunix_2escm",(void*)f_5400},
{"f_5402:posixunix_2escm",(void*)f_5402},
{"f_6617:posixunix_2escm",(void*)f_6617},
{"f_4054:posixunix_2escm",(void*)f_4054},
{"f_4060:posixunix_2escm",(void*)f_4060},
{"f_3083:posixunix_2escm",(void*)f_3083},
{"f_4064:posixunix_2escm",(void*)f_4064},
{"f_3082:posixunix_2escm",(void*)f_3082},
{"f_7509:posixunix_2escm",(void*)f_7509},
{"f_7914:posixunix_2escm",(void*)f_7914},
{"f_4033:posixunix_2escm",(void*)f_4033},
{"f_7522:posixunix_2escm",(void*)f_7522},
{"f_7523:posixunix_2escm",(void*)f_7523},
{"f_2912:posixunix_2escm",(void*)f_2912},
{"f_7526:posixunix_2escm",(void*)f_7526},
{"f_3092:posixunix_2escm",(void*)f_3092},
{"f_3098:posixunix_2escm",(void*)f_3098},
{"f_7906:posixunix_2escm",(void*)f_7906},
{"f_2968:posixunix_2escm",(void*)f_2968},
{"f_7513:posixunix_2escm",(void*)f_7513},
{"f_3063:posixunix_2escm",(void*)f_3063},
{"f_7511:posixunix_2escm",(void*)f_7511},
{"f_7934:posixunix_2escm",(void*)f_7934},
{"f_2976:posixunix_2escm",(void*)f_2976},
{"f_4094:posixunix_2escm",(void*)f_4094},
{"f_7519:posixunix_2escm",(void*)f_7519},
{"f_3077:posixunix_2escm",(void*)f_3077},
{"f_5494:posixunix_2escm",(void*)f_5494},
{"f_7939:posixunix_2escm",(void*)f_7939},
{"f_7953:posixunix_2escm",(void*)f_7953},
{"f_4070:posixunix_2escm",(void*)f_4070},
{"f_3052:posixunix_2escm",(void*)f_3052},
{"f_3059:posixunix_2escm",(void*)f_3059},
{"f_7942:posixunix_2escm",(void*)f_7942},
{"f_7944:posixunix_2escm",(void*)f_7944},
{"f_4081:posixunix_2escm",(void*)f_4081},
{"f_4086:posixunix_2escm",(void*)f_4086},
{"f_7974:posixunix_2escm",(void*)f_7974},
{"f_7948:posixunix_2escm",(void*)f_7948},
{"f_5457:posixunix_2escm",(void*)f_5457},
{"f_3032:posixunix_2escm",(void*)f_3032},
{"f_7501:posixunix_2escm",(void*)f_7501},
{"f_7504:posixunix_2escm",(void*)f_7504},
{"f_3034:posixunix_2escm",(void*)f_3034},
{"f_7506:posixunix_2escm",(void*)f_7506},
{"f_7962:posixunix_2escm",(void*)f_7962},
{"f_5460:posixunix_2escm",(void*)f_5460},
{"f_5463:posixunix_2escm",(void*)f_5463},
{"f_5466:posixunix_2escm",(void*)f_5466},
{"f_5469:posixunix_2escm",(void*)f_5469},
{"f_2996:posixunix_2escm",(void*)f_2996},
{"f_2991:posixunix_2escm",(void*)f_2991},
{"f_5611:posixunix_2escm",(void*)f_5611},
{"f_5618:posixunix_2escm",(void*)f_5618},
{"f_5629:posixunix_2escm",(void*)f_5629},
{"f_5679:posixunix_2escm",(void*)f_5679},
{"f_4021:posixunix_2escm",(void*)f_4021},
{"f_5601:posixunix_2escm",(void*)f_5601},
{"f_4027:posixunix_2escm",(void*)f_4027},
{"f_4029:posixunix_2escm",(void*)f_4029},
{"f_4720:posixunix_2escm",(void*)f_4720},
{"f_4728:posixunix_2escm",(void*)f_4728},
{"f_4723:posixunix_2escm",(void*)f_4723},
{"f_4732:posixunix_2escm",(void*)f_4732},
{"f_4737:posixunix_2escm",(void*)f_4737},
{"f_4869:posixunix_2escm",(void*)f_4869},
{"f_4860:posixunix_2escm",(void*)f_4860},
{"f_3847:posixunix_2escm",(void*)f_3847},
{"f_3854:posixunix_2escm",(void*)f_3854},
{"f_4837:posixunix_2escm",(void*)f_4837},
{"f_4842:posixunix_2escm",(void*)f_4842},
{"f_4848:posixunix_2escm",(void*)f_4848},
{"f_5649:posixunix_2escm",(void*)f_5649},
{"f_5647:posixunix_2escm",(void*)f_5647},
{"f_7212:posixunix_2escm",(void*)f_7212},
{"f_5436:posixunix_2escm",(void*)f_5436},
{"f_5438:posixunix_2escm",(void*)f_5438},
{"f_3804:posixunix_2escm",(void*)f_3804},
{"f_3809:posixunix_2escm",(void*)f_3809},
{"f_5414:posixunix_2escm",(void*)f_5414},
{"f_6111:posixunix_2escm",(void*)f_6111},
{"f_5424:posixunix_2escm",(void*)f_5424},
{"f_4886:posixunix_2escm",(void*)f_4886},
{"f_5420:posixunix_2escm",(void*)f_5420},
{"f_6103:posixunix_2escm",(void*)f_6103},
{"f_4880:posixunix_2escm",(void*)f_4880},
{"f_5429:posixunix_2escm",(void*)f_5429},
{"f_5686:posixunix_2escm",(void*)f_5686},
{"f_5681:posixunix_2escm",(void*)f_5681},
{"f_3493:posixunix_2escm",(void*)f_3493},
{"f_5470:posixunix_2escm",(void*)f_5470},
{"f_3499:posixunix_2escm",(void*)f_3499},
{"f_6167:posixunix_2escm",(void*)f_6167},
{"f_5480:posixunix_2escm",(void*)f_5480},
{"f_6859:posixunix_2escm",(void*)f_6859},
{"f_4742:posixunix_2escm",(void*)f_4742},
{"f_6854:posixunix_2escm",(void*)f_6854},
{"f_4747:posixunix_2escm",(void*)f_4747},
{"f_6158:posixunix_2escm",(void*)f_6158},
{"f_4755:posixunix_2escm",(void*)f_4755},
{"f_6846:posixunix_2escm",(void*)f_6846},
{"f_6841:posixunix_2escm",(void*)f_6841},
{"f_4750:posixunix_2escm",(void*)f_4750},
{"f_6142:posixunix_2escm",(void*)f_6142},
{"f_6143:posixunix_2escm",(void*)f_6143},
{"f_6835:posixunix_2escm",(void*)f_6835},
{"f_4764:posixunix_2escm",(void*)f_4764},
{"f_7317:posixunix_2escm",(void*)f_7317},
{"f_4769:posixunix_2escm",(void*)f_4769},
{"f_6831:posixunix_2escm",(void*)f_6831},
{"f_4760:posixunix_2escm",(void*)f_4760},
{"f_7612:posixunix_2escm",(void*)f_7612},
{"f_7310:posixunix_2escm",(void*)f_7310},
{"f_6130:posixunix_2escm",(void*)f_6130},
{"f_4774:posixunix_2escm",(void*)f_4774},
{"f_4779:posixunix_2escm",(void*)f_4779},
{"f_7286:posixunix_2escm",(void*)f_7286},
{"f_7603:posixunix_2escm",(void*)f_7603},
{"f_4701:posixunix_2escm",(void*)f_4701},
{"f_6896:posixunix_2escm",(void*)f_6896},
{"f_4706:posixunix_2escm",(void*)f_4706},
{"f_7270:posixunix_2escm",(void*)f_7270},
{"f_3897:posixunix_2escm",(void*)f_3897},
{"f_6885:posixunix_2escm",(void*)f_6885},
{"f_6883:posixunix_2escm",(void*)f_6883},
{"f_4710:posixunix_2escm",(void*)f_4710},
{"f_6888:posixunix_2escm",(void*)f_6888},
{"f_4715:posixunix_2escm",(void*)f_4715},
{"f_6872:posixunix_2escm",(void*)f_6872},
{"f_6879:posixunix_2escm",(void*)f_6879},
{"f_7306:posixunix_2escm",(void*)f_7306},
{"f_7230:posixunix_2escm",(void*)f_7230},
{"f_5114:posixunix_2escm",(void*)f_5114},
{"f_7627:posixunix_2escm",(void*)f_7627},
{"f_7625:posixunix_2escm",(void*)f_7625},
{"f_7321:posixunix_2escm",(void*)f_7321},
{"f_7399:posixunix_2escm",(void*)f_7399},
{"f_7695:posixunix_2escm",(void*)f_7695},
{"f_7391:posixunix_2escm",(void*)f_7391},
{"f_7349:posixunix_2escm",(void*)f_7349},
{"f_6802:posixunix_2escm",(void*)f_6802},
{"f_6800:posixunix_2escm",(void*)f_6800},
{"f_7340:posixunix_2escm",(void*)f_7340},
{"f_6123:posixunix_2escm",(void*)f_6123},
{"f_7344:posixunix_2escm",(void*)f_7344},
{"f_5105:posixunix_2escm",(void*)f_5105},
{"f_6817:posixunix_2escm",(void*)f_6817},
{"f_5101:posixunix_2escm",(void*)f_5101},
{"f_4787:posixunix_2escm",(void*)f_4787},
{"f_4782:posixunix_2escm",(void*)f_4782},
{"f_5153:posixunix_2escm",(void*)f_5153},
{"f_5151:posixunix_2escm",(void*)f_5151},
{"f_5155:posixunix_2escm",(void*)f_5155},
{"f_4796:posixunix_2escm",(void*)f_4796},
{"f_4792:posixunix_2escm",(void*)f_4792},
{"f_7361:posixunix_2escm",(void*)f_7361},
{"f_5160:posixunix_2escm",(void*)f_5160},
{"f_7651:posixunix_2escm",(void*)f_7651},
{"f_7649:posixunix_2escm",(void*)f_7649},
{"f_7645:posixunix_2escm",(void*)f_7645},
{"f_5147:posixunix_2escm",(void*)f_5147},
{"f_7382:posixunix_2escm",(void*)f_7382},
{"f_7379:posixunix_2escm",(void*)f_7379},
{"f_7632:posixunix_2escm",(void*)f_7632},
{"f_5199:posixunix_2escm",(void*)f_5199},
{"f_6820:posixunix_2escm",(void*)f_6820},
{"f_5174:posixunix_2escm",(void*)f_5174},
{"f_7077:posixunix_2escm",(void*)f_7077},
{"f_7078:posixunix_2escm",(void*)f_7078},
{"f_5182:posixunix_2escm",(void*)f_5182},
{"f_4632:posixunix_2escm",(void*)f_4632},
{"f_4638:posixunix_2escm",(void*)f_4638},
{"f_5836:posixunix_2escm",(void*)f_5836},
{"f_4601:posixunix_2escm",(void*)f_4601},
{"f_7666:posixunix_2escm",(void*)f_7666},
{"f_7359:posixunix_2escm",(void*)f_7359},
{"f_5819:posixunix_2escm",(void*)f_5819},
{"f_7355:posixunix_2escm",(void*)f_7355},
{"f_3606:posixunix_2escm",(void*)f_3606},
{"f_3601:posixunix_2escm",(void*)f_3601},
{"f_7025:posixunix_2escm",(void*)f_7025},
{"f_7029:posixunix_2escm",(void*)f_7029},
{"f_3714:posixunix_2escm",(void*)f_3714},
{"f_3728:posixunix_2escm",(void*)f_3728},
{"f_7010:posixunix_2escm",(void*)f_7010},
{"f_5849:posixunix_2escm",(void*)f_5849},
{"f_3721:posixunix_2escm",(void*)f_3721},
{"f_5841:posixunix_2escm",(void*)f_5841},
{"f_5844:posixunix_2escm",(void*)f_5844},
{"f_5125:posixunix_2escm",(void*)f_5125},
{"f_4656:posixunix_2escm",(void*)f_4656},
{"f_7006:posixunix_2escm",(void*)f_7006},
{"f_5858:posixunix_2escm",(void*)f_5858},
{"f_3708:posixunix_2escm",(void*)f_3708},
{"f_3643:posixunix_2escm",(void*)f_3643},
{"f_3702:posixunix_2escm",(void*)f_3702},
{"f_6094:posixunix_2escm",(void*)f_6094},
{"f_6090:posixunix_2escm",(void*)f_6090},
{"f_3652:posixunix_2escm",(void*)f_3652},
{"f_3657:posixunix_2escm",(void*)f_3657},
{"f_3295:posixunix_2escm",(void*)f_3295},
{"f_6081:posixunix_2escm",(void*)f_6081},
{"f_3297:posixunix_2escm",(void*)f_3297},
{"f_7053:posixunix_2escm",(void*)f_7053},
{"f_7051:posixunix_2escm",(void*)f_7051},
{"f_4688:posixunix_2escm",(void*)f_4688},
{"f_7057:posixunix_2escm",(void*)f_7057},
{"f_6301:posixunix_2escm",(void*)f_6301},
{"f_4684:posixunix_2escm",(void*)f_4684},
{"f_3762:posixunix_2escm",(void*)f_3762},
{"f_3622:posixunix_2escm",(void*)f_3622},
{"f_6098:posixunix_2escm",(void*)f_6098},
{"f_6096:posixunix_2escm",(void*)f_6096},
{"f_5885:posixunix_2escm",(void*)f_5885},
{"f_3627:posixunix_2escm",(void*)f_3627},
{"f_3739:posixunix_2escm",(void*)f_3739},
{"f_3737:posixunix_2escm",(void*)f_3737},
{"f_7863:posixunix_2escm",(void*)f_7863},
{"f_7044:posixunix_2escm",(void*)f_7044},
{"f_7046:posixunix_2escm",(void*)f_7046},
{"f_7869:posixunix_2escm",(void*)f_7869},
{"f_7040:posixunix_2escm",(void*)f_7040},
{"f_4610:posixunix_2escm",(void*)f_4610},
{"f_4619:posixunix_2escm",(void*)f_4619},
{"f_7852:posixunix_2escm",(void*)f_7852},
{"f_7034:posixunix_2escm",(void*)f_7034},
{"f_4662:posixunix_2escm",(void*)f_4662},
{"f_7855:posixunix_2escm",(void*)f_7855},
{"f_7032:posixunix_2escm",(void*)f_7032},
{"f_4660:posixunix_2escm",(void*)f_4660},
{"f_3687:posixunix_2escm",(void*)f_3687},
{"f_3574:posixunix_2escm",(void*)f_3574},
{"f_3576:posixunix_2escm",(void*)f_3576},
{"f_3691:posixunix_2escm",(void*)f_3691},
{"f_4674:posixunix_2escm",(void*)f_4674},
{"f_4676:posixunix_2escm",(void*)f_4676},
{"f_7846:posixunix_2escm",(void*)f_7846},
{"f_4670:posixunix_2escm",(void*)f_4670},
{"f_3697:posixunix_2escm",(void*)f_3697},
{"f_3581:posixunix_2escm",(void*)f_3581},
{"f_3583:posixunix_2escm",(void*)f_3583},
{"f_3661:posixunix_2escm",(void*)f_3661},
{"f_7838:posixunix_2escm",(void*)f_7838},
{"f_7835:posixunix_2escm",(void*)f_7835},
{"f_4647:posixunix_2escm",(void*)f_4647},
{"f_3778:posixunix_2escm",(void*)f_3778},
{"f_3776:posixunix_2escm",(void*)f_3776},
{"f_3550:posixunix_2escm",(void*)f_3550},
{"f_3555:posixunix_2escm",(void*)f_3555},
{"f_3561:posixunix_2escm",(void*)f_3561},
{"f_3567:posixunix_2escm",(void*)f_3567},
{"f_3564:posixunix_2escm",(void*)f_3564},
{"f_3558:posixunix_2escm",(void*)f_3558},
{"f_3784:posixunix_2escm",(void*)f_3784},
{"f_3536:posixunix_2escm",(void*)f_3536},
{"f_3530:posixunix_2escm",(void*)f_3530},
{"f_7883:posixunix_2escm",(void*)f_7883},
{"f_3569:posixunix_2escm",(void*)f_3569},
{"f_6358:posixunix_2escm",(void*)f_6358},
{"f_6027:posixunix_2escm",(void*)f_6027},
{"f_6025:posixunix_2escm",(void*)f_6025},
{"f_3544:posixunix_2escm",(void*)f_3544},
{"f_3546:posixunix_2escm",(void*)f_3546},
{"f_3540:posixunix_2escm",(void*)f_3540},
{"f_7874:posixunix_2escm",(void*)f_7874},
{"f_3542:posixunix_2escm",(void*)f_3542},
{"f_7872:posixunix_2escm",(void*)f_7872},
{"f_3510:posixunix_2escm",(void*)f_3510},
{"f_3548:posixunix_2escm",(void*)f_3548},
{"f_4698:posixunix_2escm",(void*)f_4698},
{"f_4693:posixunix_2escm",(void*)f_4693},
{"f_6009:posixunix_2escm",(void*)f_6009},
{"f_3521:posixunix_2escm",(void*)f_3521},
{"f_6362:posixunix_2escm",(void*)f_6362},
{"f_6051:posixunix_2escm",(void*)f_6051},
{"f_6398:posixunix_2escm",(void*)f_6398},
{"f_6394:posixunix_2escm",(void*)f_6394},
{"f_7113:posixunix_2escm",(void*)f_7113},
{"f_7111:posixunix_2escm",(void*)f_7111},
{"f_6390:posixunix_2escm",(void*)f_6390},
{"f_7101:posixunix_2escm",(void*)f_7101},
{"f_7821:posixunix_2escm",(void*)f_7821},
{"f_3331:posixunix_2escm",(void*)f_3331},
{"f_3507:posixunix_2escm",(void*)f_3507},
{"f_7829:posixunix_2escm",(void*)f_7829},
{"f_3509:posixunix_2escm",(void*)f_3509},
{"f_6378:posixunix_2escm",(void*)f_6378},
{"f_3349:posixunix_2escm",(void*)f_3349},
{"f_6374:posixunix_2escm",(void*)f_6374},
{"f_7812:posixunix_2escm",(void*)f_7812},
{"f_7818:posixunix_2escm",(void*)f_7818},
{"f_6033:posixunix_2escm",(void*)f_6033},
{"f_3316:posixunix_2escm",(void*)f_3316},
{"f_7801:posixunix_2escm",(void*)f_7801},
{"f_3312:posixunix_2escm",(void*)f_3312},
{"f_7804:posixunix_2escm",(void*)f_7804},
{"f_4408:posixunix_2escm",(void*)f_4408},
{"f_4406:posixunix_2escm",(void*)f_4406},
{"f_7152:posixunix_2escm",(void*)f_7152},
{"f_7157:posixunix_2escm",(void*)f_7157},
{"f_3325:posixunix_2escm",(void*)f_3325},
{"f_3322:posixunix_2escm",(void*)f_3322},
{"f_3371:posixunix_2escm",(void*)f_3371},
{"f_3388:posixunix_2escm",(void*)f_3388},
{"f_7170:posixunix_2escm",(void*)f_7170},
{"f_7149:posixunix_2escm",(void*)f_7149},
{"f_4435:posixunix_2escm",(void*)f_4435},
{"f_7166:posixunix_2escm",(void*)f_7166},
{"f_4433:posixunix_2escm",(void*)f_4433},
{"f_3369:posixunix_2escm",(void*)f_3369},
{"f_4442:posixunix_2escm",(void*)f_4442},
{"f_7195:posixunix_2escm",(void*)f_7195},
{"f_4445:posixunix_2escm",(void*)f_4445},
{"f_4444:posixunix_2escm",(void*)f_4444},
{"f_7168:posixunix_2escm",(void*)f_7168},
{"f_3361:posixunix_2escm",(void*)f_3361},
{"f_3363:posixunix_2escm",(void*)f_3363},
{"f_4417:posixunix_2escm",(void*)f_4417},
{"f_4419:posixunix_2escm",(void*)f_4419},
{"f_6343:posixunix_2escm",(void*)f_6343},
{"f_7182:posixunix_2escm",(void*)f_7182},
{"f_7180:posixunix_2escm",(void*)f_7180},
{"f_5377:posixunix_2escm",(void*)f_5377},
{"f_4424:posixunix_2escm",(void*)f_4424},
{"f_5380:posixunix_2escm",(void*)f_5380},
{"f_5382:posixunix_2escm",(void*)f_5382},
{"f_7188:posixunix_2escm",(void*)f_7188},
{"f_4472:posixunix_2escm",(void*)f_4472},
{"f_4470:posixunix_2escm",(void*)f_4470},
{"f_4477:posixunix_2escm",(void*)f_4477},
{"f_5351:posixunix_2escm",(void*)f_5351},
{"f_5356:posixunix_2escm",(void*)f_5356},
{"f_5354:posixunix_2escm",(void*)f_5354},
{"f_4485:posixunix_2escm",(void*)f_4485},
{"f_4458:posixunix_2escm",(void*)f_4458},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  for-each		7
o|eliminated procedure checks: 275 
o|specializations:
o|  1 (negative? fixnum)
o|  4 (##sys#check-list (or pair list) *)
o|  6 (cdr pair)
o|  1 (string-ref string fixnum)
o|  4 (make-string fixnum)
o|  11 (eqv? * (not float))
o|  14 (car pair)
o|dropping redundant toplevel assignment: process 
o|dropping redundant toplevel assignment: process* 
o|safe globals: (file-stat ##sys#stat ##sys#posix-error posix-error) 
o|Removed `not' forms: 7 
o|inlining procedure: k2638 
o|inlining procedure: k2638 
o|inlining procedure: k2653 
o|inlining procedure: k2653 
o|inlining procedure: k2737 
o|inlining procedure: k2749 
o|inlining procedure: k2749 
o|inlining procedure: k2761 
o|inlining procedure: k2761 
o|inlining procedure: k2773 
o|inlining procedure: k2773 
o|inlining procedure: k2737 
o|inlining procedure: k2882 
o|contracted procedure: k2897 
o|inlining procedure: k2894 
o|inlining procedure: k2894 
o|substituted constant variable: a2907 
o|inlining procedure: k2882 
o|inlining procedure: k2915 
o|inlining procedure: k2915 
o|inlining procedure: k2957 
o|inlining procedure: k2957 
o|inlining procedure: k2975 
o|inlining procedure: k2975 
o|inlining procedure: k3003 
o|inlining procedure: k3003 
o|inlining procedure: k3025 
o|inlining procedure: k3025 
o|substituted constant variable: a3044 
o|inlining procedure: k3064 
o|inlining procedure: k3064 
o|inlining procedure: k3085 
o|propagated global variable: g2752768003 delete-file 
o|inlining procedure: k3085 
o|inlining procedure: k3078 
o|inlining procedure: k3111 
o|inlining procedure: k3111 
o|inlining procedure: k3078 
o|inlining procedure: k3159 
o|inlining procedure: k3159 
o|inlining procedure: k3175 
o|inlining procedure: k3175 
o|inlining procedure: k3207 
o|inlining procedure: k3207 
o|substituted constant variable: a3228 
o|substituted constant variable: a3232 
o|inlining procedure: k3270 
o|inlining procedure: k3270 
o|inlining procedure: k3300 
o|inlining procedure: k3300 
o|inlining procedure: k3344 
o|inlining procedure: k3344 
o|inlining procedure: k3351 
o|inlining procedure: k3351 
o|contracted procedure: "(posix-common.scm:431) find-files" 
o|inlining procedure: k3374 
o|inlining procedure: k3374 
o|inlining procedure: k3389 
o|inlining procedure: k3389 
o|inlining procedure: k3408 
o|inlining procedure: k3408 
o|inlining procedure: k3416 
o|inlining procedure: k3445 
o|inlining procedure: k3445 
o|inlining procedure: k3416 
o|inlining procedure: k3465 
o|inlining procedure: k3465 
o|inlining procedure: k3482 
o|inlining procedure: k3482 
o|inlining procedure: k3501 
o|inlining procedure: k3501 
o|contracted procedure: k3518 
o|inlining procedure: k3524 
o|inlining procedure: k3524 
o|inlining procedure: k3588 
o|inlining procedure: k3588 
o|inlining procedure: k3662 
o|inlining procedure: k3662 
o|inlining procedure: k3692 
o|inlining procedure: k3692 
o|inlining procedure: k3722 
o|inlining procedure: k3722 
o|inlining procedure: k3811 
o|inlining procedure: k3811 
o|inlining procedure: k3920 
o|inlining procedure: k3920 
o|inlining procedure: k3952 
o|inlining procedure: k3952 
o|inlining procedure: k3973 
o|inlining procedure: k3973 
o|inlining procedure: k3995 
o|inlining procedure: k3995 
o|inlining procedure: k4032 
o|inlining procedure: k4032 
o|inlining procedure: k4123 
o|inlining procedure: k4123 
o|inlining procedure: k4145 
o|inlining procedure: k4145 
o|inlining procedure: k4160 
o|inlining procedure: k4173 
o|inlining procedure: k4173 
o|inlining procedure: k4191 
o|inlining procedure: k4191 
o|inlining procedure: k4160 
o|inlining procedure: k4207 
o|inlining procedure: k4218 
o|inlining procedure: k4218 
o|inlining procedure: k4207 
o|inlining procedure: k4236 
o|inlining procedure: k4236 
o|inlining procedure: k4260 
o|inlining procedure: k4260 
o|inlining procedure: k4287 
o|inlining procedure: k4287 
o|inlining procedure: k4303 
o|inlining procedure: k4303 
o|inlining procedure: k4330 
o|inlining procedure: k4330 
o|inlining procedure: k4365 
o|inlining procedure: k4365 
o|inlining procedure: k4377 
o|inlining procedure: k4377 
o|inlining procedure: k4386 
o|inlining procedure: k4386 
o|inlining procedure: k4418 
o|inlining procedure: k4418 
o|inlining procedure: k4447 
o|inlining procedure: k4447 
o|inlining procedure: k4438 
o|inlining procedure: k4438 
o|inlining procedure: k4479 
o|inlining procedure: k4479 
o|inlining procedure: k4487 
o|inlining procedure: k4487 
o|inlining procedure: k4522 
o|inlining procedure: k4522 
o|inlining procedure: k4540 
o|inlining procedure: k4540 
o|inlining procedure: k4553 
o|inlining procedure: k4553 
o|inlining procedure: k4571 
o|inlining procedure: k4571 
o|inlining procedure: k4593 
o|inlining procedure: k4593 
o|inlining procedure: "(posixunix.scm:815) badmode926" 
o|substituted constant variable: a4615 
o|substituted constant variable: a4617 
o|inlining procedure: k4630 
o|inlining procedure: k4630 
o|inlining procedure: "(posixunix.scm:826) badmode926" 
o|substituted constant variable: a4652 
o|substituted constant variable: a4654 
o|inlining procedure: k4661 
o|inlining procedure: k4661 
o|inlining procedure: k4675 
o|inlining procedure: k4675 
o|inlining procedure: k4795 
o|inlining procedure: k4795 
o|inlining procedure: k4849 
o|inlining procedure: k4849 
o|inlining procedure: k4863 
o|inlining procedure: k4863 
o|inlining procedure: k4889 
o|inlining procedure: k4889 
o|inlining procedure: k4902 
o|inlining procedure: k4902 
o|inlining procedure: k4919 
o|inlining procedure: k4919 
o|inlining procedure: k4935 
o|inlining procedure: k4935 
o|inlining procedure: k5002 
o|inlining procedure: k5002 
o|inlining procedure: k5083 
o|inlining procedure: k5106 
o|inlining procedure: k5106 
o|contracted procedure: "(posixunix.scm:1094) group-member" 
o|inlining procedure: k5083 
o|inlining procedure: k5163 
o|inlining procedure: k5163 
o|contracted procedure: "(posixunix.scm:1117) _get-groups" 
o|inlining procedure: "(posixunix.scm:1115) _ensure-groups" 
o|inlining procedure: k5216 
o|inlining procedure: k5216 
o|inlining procedure: "(posixunix.scm:1126) _ensure-groups" 
o|inlining procedure: k5278 
o|inlining procedure: k5278 
o|inlining procedure: k5339 
o|inlining procedure: k5339 
o|inlining procedure: k5365 
o|inlining procedure: k5365 
o|inlining procedure: k5389 
o|inlining procedure: k5389 
o|inlining procedure: k5423 
o|inlining procedure: k5423 
o|inlining procedure: k5445 
o|inlining procedure: k5445 
o|inlining procedure: k5481 
o|inlining procedure: k5481 
o|inlining procedure: k5524 
o|inlining procedure: k5524 
o|inlining procedure: k5546 
o|inlining procedure: k5546 
o|inlining procedure: k5588 
o|inlining procedure: k5588 
o|inlining procedure: k5613 
o|inlining procedure: k5613 
o|inlining procedure: k5620 
o|inlining procedure: k5632 
o|inlining procedure: k5653 
o|inlining procedure: k5653 
o|inlining procedure: k5632 
o|inlining procedure: k5674 
o|inlining procedure: k5674 
o|inlining procedure: k5692 
o|inlining procedure: k5692 
o|inlining procedure: k5620 
o|inlining procedure: k5734 
o|inlining procedure: k5734 
o|inlining procedure: k5743 
o|inlining procedure: k5743 
o|inlining procedure: k5781 
o|inlining procedure: k5781 
o|inlining procedure: k5820 
o|inlining procedure: k5820 
o|inlining procedure: k5851 
o|inlining procedure: k5851 
o|inlining procedure: k5881 
o|inlining procedure: k5881 
o|inlining procedure: k5888 
o|inlining procedure: k5888 
o|inlining procedure: k5900 
o|inlining procedure: k5917 
o|inlining procedure: k5917 
o|inlining procedure: k5900 
o|inlining procedure: k5937 
o|inlining procedure: k5937 
o|inlining procedure: k6036 
o|inlining procedure: k6055 
o|inlining procedure: k6055 
o|inlining procedure: k6036 
o|inlining procedure: k6105 
o|inlining procedure: k6105 
o|inlining procedure: k6133 
o|inlining procedure: k6133 
o|inlining procedure: k6146 
o|inlining procedure: k6161 
o|inlining procedure: k6161 
o|inlining procedure: k6146 
o|inlining procedure: k6254 
o|inlining procedure: k6254 
o|inlining procedure: k6264 
o|inlining procedure: k6264 
o|inlining procedure: k6363 
o|inlining procedure: k6363 
o|inlining procedure: k6379 
o|inlining procedure: k6379 
o|inlining procedure: k6400 
o|inlining procedure: k6400 
o|inlining procedure: k6395 
o|inlining procedure: k6395 
o|inlining procedure: k6426 
o|inlining procedure: k6426 
o|inlining procedure: k6449 
o|inlining procedure: k6449 
o|inlining procedure: k6484 
o|inlining procedure: k6484 
o|inlining procedure: k6496 
o|inlining procedure: k6496 
o|substituted constant variable: a6509 
o|substituted constant variable: a6511 
o|substituted constant variable: a6513 
o|inlining procedure: k6561 
o|inlining procedure: k6571 
o|inlining procedure: k6571 
o|inlining procedure: k6561 
o|inlining procedure: k6652 
o|inlining procedure: k6652 
o|contracted procedure: k6676 
o|inlining procedure: k6702 
o|inlining procedure: k6702 
o|inlining procedure: k6760 
o|inlining procedure: k6760 
o|inlining procedure: k6836 
o|inlining procedure: k6836 
o|inlining procedure: k6865 
o|inlining procedure: k6865 
o|inlining procedure: k6891 
o|inlining procedure: k6891 
o|inlining procedure: k6901 
o|inlining procedure: k6901 
o|inlining procedure: k6912 
o|inlining procedure: k6912 
o|substituted constant variable: a6928 
o|substituted constant variable: a6930 
o|substituted constant variable: a6932 
o|inlining procedure: k6945 
o|inlining procedure: k6945 
o|inlining procedure: k6960 
o|inlining procedure: k6960 
o|inlining procedure: k7011 
o|inlining procedure: k7011 
o|inlining procedure: k7045 
o|inlining procedure: k7045 
o|inlining procedure: k7058 
o|inlining procedure: k7058 
o|inlining procedure: k7160 
o|inlining procedure: k7198 
o|inlining procedure: k7198 
o|inlining procedure: k7160 
o|inlining procedure: k7276 
o|inlining procedure: k7276 
o|inlining procedure: k7294 
o|inlining procedure: k7294 
o|inlining procedure: k7326 
o|inlining procedure: k7326 
o|inlining procedure: k7345 
o|inlining procedure: k7345 
o|inlining procedure: k7362 
o|inlining procedure: k7362 
o|inlining procedure: k7393 
o|inlining procedure: k7393 
o|inlining procedure: k7409 
o|inlining procedure: k7426 
o|inlining procedure: k7426 
o|inlining procedure: k7409 
o|inlining procedure: k7439 
o|inlining procedure: k7439 
o|inlining procedure: k7456 
o|inlining procedure: k7456 
o|inlining procedure: k7465 
o|inlining procedure: k7465 
o|inlining procedure: k7477 
o|inlining procedure: k7477 
o|inlining procedure: k7527 
o|inlining procedure: k7527 
o|inlining procedure: k7537 
o|inlining procedure: k7537 
o|inlining procedure: k7606 
o|inlining procedure: k7606 
o|inlining procedure: k7737 
o|inlining procedure: k7737 
o|inlining procedure: k7751 
o|inlining procedure: k7751 
o|inlining procedure: k7771 
o|inlining procedure: k7771 
o|inlining procedure: k7788 
o|inlining procedure: k7788 
o|inlining procedure: k7806 
o|inlining procedure: k7806 
o|inlining procedure: k7823 
o|inlining procedure: k7823 
o|inlining procedure: k7840 
o|inlining procedure: k7840 
o|inlining procedure: k7857 
o|inlining procedure: k7857 
o|inlining procedure: k7873 
o|inlining procedure: k7873 
o|inlining procedure: k7884 
o|inlining procedure: k7884 
o|inlining procedure: k7893 
o|inlining procedure: k7893 
o|inlining procedure: k7921 
o|inlining procedure: k7921 
o|inlining procedure: k7951 
o|inlining procedure: k7951 
o|inlining procedure: k7963 
o|inlining procedure: k7963 
o|replaced variables: 704 
o|removed binding forms: 334 
o|substituted constant variable: r26397976 
o|substituted constant variable: r27507980 
o|substituted constant variable: r27627982 
o|substituted constant variable: r27747984 
o|substituted constant variable: r27387986 
o|inlining procedure: k2882 
o|substituted constant variable: r28957989 
o|inlining procedure: k2882 
o|inlining procedure: k2882 
o|inlining procedure: k3085 
o|inlining procedure: k3085 
o|propagated global variable: g2752768382 delete-file 
o|converted assignments to bindings: (rmdir257) 
o|substituted constant variable: r31768017 
o|substituted constant variable: f_32698021 
o|substituted constant variable: r33458027 
o|substituted constant variable: r33458027 
o|substituted constant variable: r33528031 
o|substituted constant variable: r33528031 
o|substituted constant variable: a35008047 
o|substituted constant variable: a35008048 
o|substituted constant variable: loc371 
o|substituted constant variable: a41448079 
o|substituted constant variable: a41448080 
o|inlining procedure: k4160 
o|substituted constant variable: a41598086 
o|substituted constant variable: r43788104 
o|substituted constant variable: f_45528122 
o|removed side-effect free assignment to unused variable: badmode926 
o|inlining procedure: k4593 
o|inlining procedure: k4630 
o|substituted constant variable: r50038168 
o|substituted constant variable: r51078171 
o|substituted constant variable: r50848172 
o|removed side-effect free assignment to unused variable: _ensure-groups 
o|substituted constant variable: f_51628173 
o|substituted constant variable: r55258203 
o|substituted constant variable: r55258203 
o|substituted constant variable: f_56128209 
o|inlining procedure: k5685 
o|inlining procedure: k5685 
o|inlining procedure: k5748 
o|substituted constant variable: r58828232 
o|substituted constant variable: f_59368239 
o|inlining procedure: k6110 
o|inlining procedure: k6264 
o|substituted constant variable: f_63998261 
o|substituted constant variable: r64858269 
o|substituted constant variable: r65628276 
o|substituted constant variable: a68648292 
o|substituted constant variable: a69008296 
o|folded constant expression: (fx< (quote -1) (quote 0)) 
o|substituted constant variable: r69468299 
o|inlining procedure: k7294 
o|inlining procedure: k7294 
o|substituted constant variable: r73468320 
o|substituted constant variable: f_74388330 
o|substituted constant variable: f_74558332 
o|substituted constant variable: f_74768336 
o|substituted constant variable: r75288338 
o|substituted constant variable: r75388340 
o|substituted constant variable: r77388345 
o|substituted constant variable: r77388345 
o|converted assignments to bindings: (check1255) 
o|substituted constant variable: r78858364 
o|substituted constant variable: r79528371 
o|substituted constant variable: r79528371 
o|simplifications: ((let . 2)) 
o|replaced variables: 31 
o|removed binding forms: 708 
o|substituted constant variable: a28818375 
o|substituted constant variable: a28818376 
o|substituted constant variable: a28818377 
o|inlining procedure: k3210 
o|inlining procedure: k3768 
o|inlining procedure: k3768 
o|inlining procedure: k4006 
o|inlining procedure: k4006 
o|inlining procedure: k4047 
o|inlining procedure: k4047 
o|inlining procedure: k5187 
o|inlining procedure: k5189 
o|inlining procedure: k5246 
o|inlining procedure: k5259 
o|inlining procedure: k5498 
o|inlining procedure: k6666 
o|inlining procedure: k6666 
o|inlining procedure: k6686 
o|inlining procedure: k7704 
o|replaced variables: 3 
o|removed binding forms: 92 
o|substituted constant variable: tmp3193218498 
o|substituted constant variable: tmp3193218498 
o|substituted constant variable: a37678509 
o|substituted constant variable: r40078512 
o|substituted constant variable: r40488514 
o|substituted constant variable: r52608538 
o|substituted constant variable: r54998542 
o|substituted constant variable: r66678558 
o|substituted constant variable: r66878559 
o|simplifications: ((let . 5)) 
o|removed binding forms: 14 
o|removed conditional forms: 5 
o|removed binding forms: 8 
o|simplifications: ((if . 78) (##core#call . 641)) 
o|  call simplifications:
o|    bitwise-ior	2
o|    <
o|    vector-ref	2
o|    make-vector
o|    ##sys#structure?
o|    ##sys#foreign-pointer-argument	4
o|    char=?
o|    fxior	2
o|    ##sys#check-structure	3
o|    ##sys#make-structure	3
o|    ##sys#setislot	3
o|    ##sys#foreign-string-argument	7
o|    length
o|    fx>=	4
o|    list	5
o|    values	18
o|    ##sys#fudge
o|    vector-set!	3
o|    fx-	11
o|    ##sys#foreign-integer-argument	6
o|    ##sys#check-number	8
o|    ##sys#check-vector
o|    ##sys#size	16
o|    member
o|    fx+	20
o|    ##sys#call-with-values	12
o|    string-ref
o|    fx>
o|    not	10
o|    cons	12
o|    ##sys#check-string	35
o|    ##sys#check-list	9
o|    fx=	30
o|    zero?
o|    ##sys#slot	40
o|    ##sys#check-exact	39
o|    ##sys#null-pointer?	4
o|    pair?	24
o|    eq?	41
o|    cdr	24
o|    ##sys#eqv?	13
o|    null?	65
o|    car	47
o|    vector	2
o|    fixnum?	15
o|    string?	3
o|    fx<	49
o|    apply	9
o|    ##sys#foreign-fixnum-argument	30
o|contracted procedure: k2615 
o|contracted procedure: k2641 
o|contracted procedure: k2650 
o|contracted procedure: k2656 
o|contracted procedure: k2685 
o|contracted procedure: k2677 
o|contracted procedure: k2803 
o|contracted procedure: k2729 
o|contracted procedure: k2797 
o|contracted procedure: k2731 
o|contracted procedure: k2791 
o|contracted procedure: k2733 
o|contracted procedure: k2785 
o|contracted procedure: k2735 
o|contracted procedure: k2746 
o|contracted procedure: k2752 
o|contracted procedure: k2758 
o|contracted procedure: k2764 
o|contracted procedure: k2770 
o|contracted procedure: k2776 
o|contracted procedure: k2782 
o|contracted procedure: k2884 
o|contracted procedure: k2891 
o|contracted procedure: k2917 
o|contracted procedure: k2929 
o|contracted procedure: k2942 
o|contracted procedure: k2993 
o|contracted procedure: k2960 
o|contracted procedure: k2972 
o|contracted procedure: k2977 
o|contracted procedure: k2999 
o|contracted procedure: k3005 
o|contracted procedure: k3011 
o|contracted procedure: k3014 
o|contracted procedure: k3016 
o|contracted procedure: k3045 
o|contracted procedure: k3022 
o|contracted procedure: k3130 
o|contracted procedure: k3055 
o|contracted procedure: k3067 
o|contracted procedure: k3074 
o|contracted procedure: k3099 
o|contracted procedure: k3113 
o|contracted procedure: k3122 
o|contracted procedure: k3125 
o|contracted procedure: k3245 
o|contracted procedure: k3142 
o|contracted procedure: k3239 
o|contracted procedure: k3144 
o|contracted procedure: k3233 
o|contracted procedure: k3146 
o|contracted procedure: k3148 
o|contracted procedure: k3162 
o|contracted procedure: k3178 
o|contracted procedure: k3183 
o|contracted procedure: k3202 
o|contracted procedure: k3205 
o|contracted procedure: k3218 
o|contracted procedure: k3210 
o|contracted procedure: k3224 
o|contracted procedure: k3251 
o|contracted procedure: k3272 
o|contracted procedure: k3275 
o|contracted procedure: k3302 
o|contracted procedure: k3309 
o|contracted procedure: k3327 
o|contracted procedure: k3341 
o|contracted procedure: k3358 
o|contracted procedure: k3376 
o|contracted procedure: k3379 
o|contracted procedure: k3381 
o|contracted procedure: k3392 
o|contracted procedure: k3401 
o|contracted procedure: k3426 
o|contracted procedure: k3503 
o|contracted procedure: k3527 
o|contracted procedure: k3586 
o|contracted procedure: k3598 
o|contracted procedure: k3591 
o|contracted procedure: k3607 
o|contracted procedure: k3612 
o|contracted procedure: k3628 
o|contracted procedure: k3633 
o|contracted procedure: k3650 
o|contracted procedure: k3658 
o|contracted procedure: k3672 
o|contracted procedure: k3669 
o|contracted procedure: k3677 
o|contracted procedure: k3755 
o|contracted procedure: k3717 
o|contracted procedure: k3725 
o|contracted procedure: k3750 
o|contracted procedure: k3747 
o|contracted procedure: k3765 
o|contracted procedure: k3840 
o|contracted procedure: k3787 
o|contracted procedure: k3834 
o|contracted procedure: k3789 
o|contracted procedure: k3828 
o|contracted procedure: k3791 
o|contracted procedure: k3822 
o|contracted procedure: k3793 
o|contracted procedure: k3795 
o|contracted procedure: k3798 
o|contracted procedure: k3813 
o|contracted procedure: k3851 
o|contracted procedure: k3858 
o|contracted procedure: k3900 
o|contracted procedure: k3903 
o|contracted procedure: k3906 
o|contracted procedure: k3929 
o|contracted procedure: k3911 
o|contracted procedure: k3914 
o|contracted procedure: k3916 
o|contracted procedure: k3923 
o|contracted procedure: k7903 
o|contracted procedure: k3936 
o|contracted procedure: k3943 
o|contracted procedure: k3945 
o|contracted procedure: k3947 
o|contracted procedure: k3954 
o|contracted procedure: k3963 
o|contracted procedure: k3971 
o|contracted procedure: k3976 
o|contracted procedure: k3987 
o|contracted procedure: k3989 
o|contracted procedure: k4000 
o|contracted procedure: k4012 
o|contracted procedure: k4024 
o|contracted procedure: k4030 
o|contracted procedure: k4034 
o|contracted procedure: k4040 
o|contracted procedure: k4057 
o|contracted procedure: k4061 
o|contracted procedure: k4072 
o|contracted procedure: k4074 
o|contracted procedure: k4084 
o|contracted procedure: k4089 
o|contracted procedure: k4092 
o|contracted procedure: k4097 
o|contracted procedure: k4100 
o|contracted procedure: k4111 
o|contracted procedure: k4116 
o|contracted procedure: k4126 
o|contracted procedure: k4135 
o|contracted procedure: k4150 
o|contracted procedure: k4142 
o|contracted procedure: k4147 
o|contracted procedure: k4165 
o|contracted procedure: k4179 
o|contracted procedure: k4182 
o|contracted procedure: k4193 
o|contracted procedure: k4202 
o|contracted procedure: k4205 
o|contracted procedure: k4210 
o|contracted procedure: k4224 
o|contracted procedure: k4227 
o|contracted procedure: k4238 
o|contracted procedure: k4247 
o|contracted procedure: k4250 
o|contracted procedure: k4252 
o|contracted procedure: k4255 
o|contracted procedure: k4258 
o|contracted procedure: k4263 
o|contracted procedure: k4270 
o|contracted procedure: k4274 
o|contracted procedure: k4289 
o|contracted procedure: k4298 
o|contracted procedure: k4301 
o|contracted procedure: k4306 
o|contracted procedure: k4313 
o|contracted procedure: k4317 
o|contracted procedure: k4332 
o|contracted procedure: k4341 
o|contracted procedure: k4344 
o|contracted procedure: k4346 
o|contracted procedure: k4359 
o|contracted procedure: k4361 
o|contracted procedure: k4384 
o|contracted procedure: k4380 
o|contracted procedure: k4389 
o|contracted procedure: k4399 
o|contracted procedure: k4508 
o|contracted procedure: k4411 
o|contracted procedure: k4414 
o|contracted procedure: k4506 
o|contracted procedure: k4420 
o|contracted procedure: k4449 
o|contracted procedure: k4489 
o|contracted procedure: k4518 
o|contracted procedure: k4524 
o|contracted procedure: k4538 
o|contracted procedure: k4542 
o|contracted procedure: k4555 
o|contracted procedure: k4573 
o|contracted procedure: k4585 
o|contracted procedure: k4596 
o|contracted procedure: k4605 
o|contracted procedure: k4622 
o|contracted procedure: k4633 
o|contracted procedure: k4642 
o|contracted procedure: k4663 
o|contracted procedure: k4677 
o|contracted procedure: k4800 
o|contracted procedure: k4833 
o|contracted procedure: k4840 
o|contracted procedure: k4844 
o|contracted procedure: k4852 
o|contracted procedure: k4865 
o|contracted procedure: k4874 
o|contracted procedure: k4877 
o|contracted procedure: k4891 
o|contracted procedure: k4894 
o|contracted procedure: k4902 
o|contracted procedure: k4911 
o|contracted procedure: k4917 
o|contracted procedure: k4922 
o|contracted procedure: k4933 
o|contracted procedure: k4938 
o|contracted procedure: k4969 
o|contracted procedure: k5033 
o|contracted procedure: k4997 
o|contracted procedure: k5005 
o|contracted procedure: k5025 
o|contracted procedure: k5028 
o|contracted procedure: k5126 
o|contracted procedure: k5078 
o|contracted procedure: k5086 
o|contracted procedure: k5116 
o|contracted procedure: k5072 
o|contracted procedure: k5118 
o|contracted procedure: k5121 
o|contracted procedure: k5165 
o|contracted procedure: k5176 
o|contracted procedure: k5137 
o|contracted procedure: k5178 
o|contracted procedure: k51448179 
o|contracted procedure: k5195 
o|contracted procedure: k5218 
o|contracted procedure: k5224 
o|contracted procedure: k5233 
o|contracted procedure: k5235 
o|contracted procedure: k5241 
o|contracted procedure: k5244 
o|contracted procedure: k5253 
o|contracted procedure: k51448186 
o|contracted procedure: k5263 
o|contracted procedure: k5269 
o|contracted procedure: k52638541 
o|contracted procedure: k5274 
o|contracted procedure: k5276 
o|contracted procedure: k5281 
o|contracted procedure: k5335 
o|contracted procedure: k5337 
o|contracted procedure: k5342 
o|contracted procedure: k5359 
o|contracted procedure: k5361 
o|contracted procedure: k5363 
o|contracted procedure: k5368 
o|contracted procedure: k5385 
o|contracted procedure: k5387 
o|contracted procedure: k5425 
o|contracted procedure: k5441 
o|contracted procedure: k5443 
o|contracted procedure: k5448 
o|contracted procedure: k5510 
o|contracted procedure: k5473 
o|contracted procedure: k5476 
o|contracted procedure: k5484 
o|contracted procedure: k5531 
o|contracted procedure: k5537 
o|contracted procedure: k5542 
o|contracted procedure: k5544 
o|contracted procedure: k5549 
o|contracted procedure: k6002 
o|contracted procedure: k5562 
o|contracted procedure: k5996 
o|contracted procedure: k5564 
o|contracted procedure: k5990 
o|contracted procedure: k5566 
o|contracted procedure: k5984 
o|contracted procedure: k5568 
o|contracted procedure: k5978 
o|contracted procedure: k5570 
o|contracted procedure: k5972 
o|contracted procedure: k5572 
o|contracted procedure: k5966 
o|contracted procedure: k5574 
o|contracted procedure: k5960 
o|contracted procedure: k5576 
o|contracted procedure: k5951 
o|contracted procedure: k5580 
o|contracted procedure: k5591 
o|contracted procedure: k5597 
o|contracted procedure: k5615 
o|contracted procedure: k5622 
o|contracted procedure: k5635 
o|contracted procedure: k5641 
o|contracted procedure: k5643 
o|contracted procedure: k5656 
o|contracted procedure: k5671 
o|contracted procedure: k5689 
o|contracted procedure: k5695 
o|contracted procedure: k5697 
o|contracted procedure: k5726 
o|contracted procedure: k5732 
o|contracted procedure: k5745 
o|contracted procedure: k5753 
o|contracted procedure: k5783 
o|contracted procedure: k5789 
o|contracted procedure: k5792 
o|contracted procedure: k5815 
o|contracted procedure: k5794 
o|contracted procedure: k5797 
o|contracted procedure: k5800 
o|contracted procedure: k5807 
o|contracted procedure: k5810 
o|contracted procedure: k5813 
o|contracted procedure: k5823 
o|contracted procedure: k5833 
o|contracted procedure: k5846 
o|contracted procedure: k5854 
o|contracted procedure: k5863 
o|contracted procedure: k5876 
o|contracted procedure: k5873 
o|contracted procedure: k5865 
o|contracted procedure: k5867 
o|contracted procedure: k5878 
o|contracted procedure: k5898 
o|contracted procedure: k5895 
o|contracted procedure: k5886 
o|contracted procedure: k5903 
o|contracted procedure: k5928 
o|contracted procedure: k5939 
o|contracted procedure: k5945 
o|contracted procedure: k6242 
o|contracted procedure: k6012 
o|contracted procedure: k6236 
o|contracted procedure: k6014 
o|contracted procedure: k6230 
o|contracted procedure: k6016 
o|contracted procedure: k6224 
o|contracted procedure: k6018 
o|contracted procedure: k6218 
o|contracted procedure: k6020 
o|contracted procedure: k6212 
o|contracted procedure: k6022 
o|contracted procedure: k6039 
o|contracted procedure: k6045 
o|contracted procedure: k6047 
o|contracted procedure: k6058 
o|contracted procedure: k6073 
o|contracted procedure: k6083 
o|contracted procedure: k6203 
o|contracted procedure: k6086 
o|contracted procedure: k6107 
o|contracted procedure: k6115 
o|contracted procedure: k6127 
o|contracted procedure: k6139 
o|contracted procedure: k6152 
o|contracted procedure: k6155 
o|contracted procedure: k6163 
o|contracted procedure: k6175 
o|contracted procedure: k6182 
o|contracted procedure: k6185 
o|contracted procedure: k6191 
o|contracted procedure: k6197 
o|contracted procedure: k6252 
o|contracted procedure: k6266 
o|contracted procedure: k6278 
o|contracted procedure: k6336 
o|contracted procedure: k6288 
o|contracted procedure: k6330 
o|contracted procedure: k6290 
o|contracted procedure: k6324 
o|contracted procedure: k6292 
o|contracted procedure: k6318 
o|contracted procedure: k6294 
o|contracted procedure: k6298 
o|contracted procedure: k6308 
o|contracted procedure: k6303 
o|contracted procedure: k6311 
o|contracted procedure: k6349 
o|contracted procedure: k6352 
o|contracted procedure: k6355 
o|contracted procedure: k6366 
o|contracted procedure: k6382 
o|contracted procedure: k6402 
o|contracted procedure: k6418 
o|contracted procedure: k6421 
o|contracted procedure: k6424 
o|contracted procedure: k6437 
o|contracted procedure: k6429 
o|contracted procedure: k6443 
o|contracted procedure: k6447 
o|contracted procedure: k6452 
o|contracted procedure: k6465 
o|contracted procedure: k6473 
o|contracted procedure: k6479 
o|contracted procedure: k6487 
o|contracted procedure: k6493 
o|contracted procedure: k6499 
o|contracted procedure: k6521 
o|contracted procedure: k6523 
o|contracted procedure: k6535 
o|contracted procedure: k6548 
o|contracted procedure: k6573 
o|contracted procedure: k6580 
o|contracted procedure: k6586 
o|contracted procedure: k6595 
o|contracted procedure: k6598 
o|contracted procedure: k6604 
o|contracted procedure: k6620 
o|contracted procedure: k6624 
o|contracted procedure: k6627 
o|contracted procedure: k6630 
o|contracted procedure: k6633 
o|contracted procedure: k6636 
o|contracted procedure: k6657 
o|contracted procedure: k6672 
o|contracted procedure: k6686 
o|contracted procedure: k6690 
o|contracted procedure: k66908562 
o|contracted procedure: k6698 
o|contracted procedure: k6705 
o|contracted procedure: k6715 
o|contracted procedure: k6717 
o|contracted procedure: k6728 
o|contracted procedure: k6793 
o|contracted procedure: k6755 
o|contracted procedure: k6763 
o|contracted procedure: k6788 
o|contracted procedure: k6785 
o|contracted procedure: k6824 
o|contracted procedure: k6805 
o|contracted procedure: k6808 
o|contracted procedure: k6810 
o|contracted procedure: k6822 
o|substituted constant variable: g8764 
o|substituted constant variable: g8764 
o|substituted constant variable: g8764 
o|substituted constant variable: g8764 
o|substituted constant variable: g8764 
o|substituted constant variable: g8764 
o|substituted constant variable: g8764 
o|substituted constant variable: g8764 
o|substituted constant variable: g8764 
o|substituted constant variable: g8764 
o|contracted procedure: k6857 
o|contracted procedure: k6867 
o|contracted procedure: k6876 
o|contracted procedure: k6889 
o|contracted procedure: k6907 
o|contracted procedure: k6903 
o|contracted procedure: k6909 
o|contracted procedure: k6915 
o|contracted procedure: k6921 
o|contracted procedure: k6933 
o|contracted procedure: k6948 
o|contracted procedure: k6973 
o|contracted procedure: k6969 
o|contracted procedure: k6963 
o|contracted procedure: k6983 
o|contracted procedure: k6998 
o|contracted procedure: k7001 
o|contracted procedure: k7004 
o|contracted procedure: k7014 
o|contracted procedure: k7061 
o|contracted procedure: k7086 
o|contracted procedure: k7070 
o|contracted procedure: k7073 
o|contracted procedure: k7081 
o|contracted procedure: k7096 
o|contracted procedure: k7103 
o|contracted procedure: k7109 
o|contracted procedure: k7116 
o|contracted procedure: k7123 
o|contracted procedure: k7129 
o|contracted procedure: k7263 
o|contracted procedure: k7136 
o|contracted procedure: k7257 
o|contracted procedure: k7138 
o|contracted procedure: k7251 
o|contracted procedure: k7140 
o|contracted procedure: k7245 
o|contracted procedure: k7142 
o|contracted procedure: k7144 
o|contracted procedure: k7146 
o|contracted procedure: k7162 
o|contracted procedure: k7171 
o|contracted procedure: k7176 
o|contracted procedure: k7189 
o|contracted procedure: k7200 
o|contracted procedure: k7206 
o|contracted procedure: k7208 
o|contracted procedure: k7219 
o|contracted procedure: k7222 
o|contracted procedure: k7224 
o|contracted procedure: k7226 
o|contracted procedure: k7237 
o|contracted procedure: k7240 
o|contracted procedure: k7243 
o|contracted procedure: k7274 
o|contracted procedure: k7299 
o|contracted procedure: k7279 
o|contracted procedure: k7314 
o|contracted procedure: k7322 
o|contracted procedure: k7324 
o|contracted procedure: k7329 
o|contracted procedure: k7335 
o|contracted procedure: k7365 
o|contracted procedure: k7386 
o|contracted procedure: k7395 
o|contracted procedure: k7407 
o|contracted procedure: k7431 
o|contracted procedure: k7412 
o|contracted procedure: k7458 
o|contracted procedure: k7467 
o|contracted procedure: k7483 
o|contracted procedure: k7580 
o|contracted procedure: k7583 
o|contracted procedure: k7586 
o|contracted procedure: k7556 
o|contracted procedure: k7592 
o|contracted procedure: k7608 
o|contracted procedure: k7617 
o|contracted procedure: k7620 
o|contracted procedure: k7622 
o|contracted procedure: k7688 
o|contracted procedure: k7654 
o|contracted procedure: k7682 
o|contracted procedure: k7656 
o|contracted procedure: k7676 
o|contracted procedure: k7658 
o|contracted procedure: k7670 
o|contracted procedure: k7660 
o|contracted procedure: k7727 
o|contracted procedure: k7698 
o|contracted procedure: k7721 
o|contracted procedure: k7700 
o|contracted procedure: k7715 
o|contracted procedure: k7702 
o|contracted procedure: k7709 
o|contracted procedure: k7704 
o|contracted procedure: k7744 
o|contracted procedure: k7749 
o|contracted procedure: k7754 
o|contracted procedure: k7764 
o|contracted procedure: k7769 
o|contracted procedure: k7773 
o|contracted procedure: k7784 
o|contracted procedure: k7786 
o|contracted procedure: k7791 
o|contracted procedure: k7808 
o|contracted procedure: k7825 
o|contracted procedure: k7842 
o|contracted procedure: k7859 
o|contracted procedure: k7875 
o|contracted procedure: k7891 
o|contracted procedure: k7887 
o|contracted procedure: k7896 
o|contracted procedure: k7908 
o|contracted procedure: k7927 
o|contracted procedure: k7916 
o|contracted procedure: k7919 
o|contracted procedure: k7936 
o|contracted procedure: k7946 
o|contracted procedure: k7958 
o|contracted procedure: k7966 
o|simplifications: ((if . 1) (let . 115)) 
o|removed binding forms: 559 
o|inlining procedure: k3604 
o|inlining procedure: k3625 
o|inlining procedure: "(posixunix.scm:808) mode925" 
o|inlining procedure: "(posixunix.scm:819) mode925" 
o|inlining procedure: k7099 
o|inlining procedure: k7119 
o|replaced variables: 11 
o|removed binding forms: 1 
o|removed side-effect free assignment to unused variable: mode925 
o|substituted constant variable: r71008876 
o|substituted constant variable: r71208878 
o|replaced variables: 6 
o|removed binding forms: 7 
o|converted assignments to bindings: (check927) 
o|simplifications: ((let . 1)) 
o|removed binding forms: 8 
o|contracted procedure: k4587 
o|contracted procedure: k4624 
o|removed binding forms: 2 
o|replaced variables: 6 
o|removed binding forms: 4 
o|customizable procedures: (for-each-loop20382056 spawn1978 k7358 k7320 doloop18731874 doloop18771878 ##sys#terminal-check k6884 k6894 k6700 k6646 scan1605 loop1602 k6445 setup1523 err1524 k6300 k6257 loop1496 k6088 poke1473 loop1412 k5774 loop1394 check1255 doloop11791180 loop1171 k5081 loop1152 k5000 loop1069 for-each-loop10481060 check927 k4440 loop889 k4357 k4105 for-each-loop749762 for-each-loop777790 k4121 for-each-loop808819 for-each-loop829840 k4028 k3941 check-time-vector k3360 k3362 loop385 loop348 conc-loop329 k3185 k3190 loop308 for-each-loop264280 rmdir257 k3001 mode180 check181 ##sys#stat) 
o|calls to known targets: 254 
o|unused rest argument: _378 f_3530 
o|unused rest argument: _377 f_3521 
o|unused rest argument: _418 f_3576 
o|identified direct recursive calls: f_4886 2 
o|identified direct recursive calls: f_5160 1 
o|identified direct recursive calls: f_5213 1 
o|identified direct recursive calls: f_5778 1 
o|identified direct recursive calls: f_6158 1 
o|identified direct recursive calls: f_6568 1 
o|fast box initializations: 30 
o|fast global references: 68 
o|fast global assignments: 4 
o|dropping unused closure argument: f_6955 
o|dropping unused closure argument: f_4568 
o|dropping unused closure argument: f_6285 
o|dropping unused closure argument: f_2876 
o|dropping unused closure argument: f_2633 
o|dropping unused closure argument: f_2912 
o|dropping unused closure argument: f_3059 
o|dropping unused closure argument: f_3583 
o|dropping unused closure argument: f_6343 
o|dropping unused closure argument: f_5382 
*/
/* end of file */
