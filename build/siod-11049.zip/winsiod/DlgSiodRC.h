//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DlgHusk.rc
//
#define IDD_DLGHUSK                     1
#define IDC_LISTBOX                     100
#define IDI_DLGHUSK                     101
#define IDC_POINTER                     104
#define IDC_NODROP                      106
#define IDR_MENU1                       107
#define GenericAppMenu                  107
#define IDC_BUTTON_LOAD                 1002
#define IDC_EDIT_MODULE_FILENAME        1003
#define IDC_BUTTON_BROWSE               1004
#define IDC_BUTTON_PAGEDEMO             1005
#define IDC_BUTTON_FRESH_SIOD           1005
#define IDC_BUTTON_COPY                 1006
#define IDC_EDIT_LISTENER               1007
#define ID_FILE_EXIT                    40001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
